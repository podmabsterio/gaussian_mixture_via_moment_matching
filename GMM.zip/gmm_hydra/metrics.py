"""
metrics.py  —  Evaluation metrics for the GMM estimator.

Paper reference: §2 of conf_CU (Метрики качества).

Four metrics
────────────
TestLL   Test log-likelihood  (higher is better)
JS       Jensen–Shannon divergence between p and p̂  (lower is better)
PD       Parametric distance via optimal matching  (lower is better)
CRR      Component recovery rate  (higher is better, ∈ [0, 1])

Main entry point
────────────────
``evaluate_all_metrics(model, true_params, …)`` computes all four at once
and returns them in a plain dict for backward compatibility with the
experiment runner.
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment


# ─── 1. Test Log-Likelihood ───────────────────────────────────────────────────

def test_log_likelihood(
    model_predict_fn,
    X_test: np.ndarray,
) -> float:
    """
    Test log-likelihood  TestLL = (1/N) Σ_n log p̂(x_n),  x_n ~ p_true.

    Parameters
    ----------
    model_predict_fn : callable X → p̂(X), shape (n,)
    X_test           : (N, d) test points drawn from the true distribution

    Returns
    -------
    TestLL : float  (higher → better fit)
    """
    density = np.clip(model_predict_fn(X_test), 1e-300, None)
    return float(np.mean(np.log(density)))


# ─── 2. Jensen–Shannon Divergence ────────────────────────────────────────────

def jensen_shannon_divergence(
    true_predict_fn,
    model_predict_fn,
    true_sample_fn,
    model_sample_fn,
    n_samples: int = 10_000,
    seed=None,
) -> float:
    """
    Monte-Carlo estimate of the Jensen–Shannon divergence JS(p ‖ p̂).

    JS(p ‖ p̂) = ½ E_{x~p}  [log p(x)  − log m(x)]
               + ½ E_{x~p̂} [log p̂(x) − log m(x)]

    where  m(x) = ½(p(x) + p̂(x)).

    Parameters
    ----------
    true_predict_fn  : X → p(X)
    model_predict_fn : X → p̂(X)
    true_sample_fn   : n → X ~ p
    model_sample_fn  : n → X ~ p̂
    n_samples        : Monte-Carlo sample size per term
    seed             : reproducibility

    Returns
    -------
    JS : float ∈ [0, log 2]  (lower → better)
    """
    # ── term 1: E_{x~p}[log p(x) − log m(x)] ─────────────────────────────
    X_true       = true_sample_fn(n_samples)
    p_true       = np.clip(true_predict_fn(X_true), 1e-300, None)
    p_hat_at_p   = np.clip(model_predict_fn(X_true), 1e-300, None)
    m_at_p       = 0.5 * (p_true + p_hat_at_p)
    term1        = float(np.mean(np.log(p_true) - np.log(m_at_p)))

    # ── term 2: E_{x~p̂}[log p̂(x) − log m(x)] ───────────────────────────
    X_hat        = model_sample_fn(n_samples)
    p_hat        = np.clip(model_predict_fn(X_hat), 1e-300, None)
    p_true_at_ph = np.clip(true_predict_fn(X_hat), 1e-300, None)
    m_at_ph      = 0.5 * (p_true_at_ph + p_hat)
    term2        = float(np.mean(np.log(p_hat) - np.log(m_at_ph)))

    return float(max(0.5 * term1 + 0.5 * term2, 0.0))


# ─── 3. Parametric Distance ───────────────────────────────────────────────────

def parametric_distance(
    true_mu: np.ndarray,
    true_m: np.ndarray,
    true_sigma: np.ndarray,
    est_mu: np.ndarray,
    est_m: np.ndarray,
    est_sigma: np.ndarray,
    D: int,
    lambda_w: float = 1.0,
) -> tuple[float, list[tuple[int, int]]]:
    """
    Parametric distance between true and estimated components.

    Optimal matching via the Hungarian algorithm, then weighted cost sum:

        PD = Σ_i w_i · c_{i, π(i)}

    Component cost (W₂² between two isotropic Gaussians + weight mismatch):

        c_{ij} = ||µ_i − µ̂_j||²  +  D·(σ_i − σ̂_j)²  +  λ_w·(w_i − ŵ_j)²

    Parameters
    ----------
    true_mu, true_m, true_sigma : true parameters
    est_mu, est_m, est_sigma    : estimated parameters
    D                           : ambient dimension (for σ scaling)
    lambda_w                    : weight for the mixing-weight mismatch term

    Returns
    -------
    pd       : float  (lower → better)
    matching : list of (i_true, j_est) pairs from the optimal matching
    """
    K_true = len(true_mu)
    K_est  = len(est_mu)
    K_max  = max(K_true, K_est)
    _LARGE = 1e6   # penalty for unmatched (dummy) assignments

    cost = np.full((K_max, K_max), _LARGE)
    for i in range(K_true):
        for j in range(K_est):
            center_sq = float(np.sum((true_m[i] - est_m[j]) ** 2))
            sigma_sq  = D * (true_sigma[i] - est_sigma[j]) ** 2
            weight_sq = lambda_w * (true_mu[i] - est_mu[j]) ** 2
            cost[i, j] = center_sq + sigma_sq + weight_sq

    row_ind, col_ind = linear_sum_assignment(cost)
    matching         = list(zip(row_ind.tolist(), col_ind.tolist()))

    # BUG FIX (caught by review): this used to also require `j < K_est`,
    # which silently DROPPED the _LARGE penalty for any true component
    # matched to a dummy (non-existent) estimated component -- exactly
    # the case when the model has collapsed to fewer active components
    # than K_true (K_est < K_true after the active_threshold filter in
    # evaluate_all_metrics). Concretely: 3 true components, only 1
    # estimated component survives -> this used to report PD=0.59 (looks
    # like a near-perfect fit) instead of a cost reflecting that 2 of 3
    # true components have literally no estimate at all. cost[i,j] is
    # already correctly _LARGE for i<K_true, j>=K_est (dummy columns) --
    # the fix is simply to stop excluding those terms from the sum. Only
    # i>=K_true (dummy TRUE rows, when K_est>K_true) should still be
    # excluded, since there's no true_mu[i] to weight by.
    pd = sum(
        true_mu[i] * cost[i, j]
        for i, j in matching
        if i < K_true
    )
    return float(pd), matching


# ─── 4. Component Recovery Rate ──────────────────────────────────────────────

def component_recovery_rate(
    true_mu: np.ndarray,
    true_m: np.ndarray,
    true_sigma: np.ndarray,
    est_mu: np.ndarray,
    est_m: np.ndarray,
    est_sigma: np.ndarray,
    matching: list[tuple[int, int]],
    tau_mu: float    = 0.2,
    tau_sigma: float = 0.2,
    tau_w: float     = 0.1,
) -> float:
    """
    Fraction of true components recovered by the estimate.

    Component i is recovered if ALL three conditions hold:

        ||µ_i − µ̂_{π(i)}||      ≤ τ_µ · σ_i √D   (centre error, normalised)
        |σ_i − σ̂_{π(i)}| / σ_i  ≤ τ_σ             (relative σ error)
        |w_i − ŵ_{π(i)}|         ≤ τ_w             (weight error)

    Parameters
    ----------
    true_mu, true_m, true_sigma : true parameters
    est_mu, est_m, est_sigma    : estimated parameters
    matching  : list of (i_true, j_est) from ``parametric_distance``
    tau_mu    : centre-error threshold in units of σ_i √D
    tau_sigma : relative σ-error threshold
    tau_w     : weight-error threshold

    Returns
    -------
    CRR : float ∈ [0, 1]  (higher → better)
    """
    K_true  = len(true_mu)
    D       = true_m.shape[1]
    n_ok    = 0

    for i, j in matching:
        if i >= K_true or j >= len(est_mu):
            continue   # dummy pair from padding

        centre_err  = float(np.linalg.norm(true_m[i] - est_m[j]))
        centre_thr  = tau_mu * true_sigma[i] * np.sqrt(D)
        sigma_rel   = abs(true_sigma[i] - est_sigma[j]) / true_sigma[i]
        weight_err  = abs(true_mu[i] - est_mu[j])

        if (centre_err <= centre_thr
                and sigma_rel  <= tau_sigma
                and weight_err <= tau_w):
            n_ok += 1

    return float(n_ok / K_true) if K_true > 0 else 0.0


def weight_recovery_error(
    true_mu: np.ndarray,
    est_mu: np.ndarray,
    matching: list[tuple[int, int]],
) -> float:
    """
    Mean absolute error in recovered mixture weights over matched
    TRUE-to-ESTIMATED pairs (dummy/padding pairs from `parametric_distance`'s
    Hungarian matching excluded).

    This isolates PURE weight-recovery quality -- unlike PD, which bundles
    position, sigma, AND weight error into one scalar, and unlike CRR's
    weight_err check (which only reports pass/fail against tau_w, not the
    actual magnitude). Directly targets the question: does going through
    the simplex -> free-parameter (c) reparametrisation, and back via the
    (1+sigma^2/s_o^2)^(d/2) correction, distort the recovered class
    proportions?

    Returns
    -------
    mean |true_mu[i] - est_mu[j]| over matched (non-dummy) pairs, or NaN if
    no real pair was matched at all (e.g. total collapse, K_active=0).
    """
    errs = [abs(true_mu[i] - est_mu[j]) for i, j in matching
             if i < len(true_mu) and j < len(est_mu)]
    return float(np.mean(errs)) if errs else float('nan')


# ─── Combined evaluator ───────────────────────────────────────────────────────

def evaluate_all_metrics(
    model,
    true_params: dict,
    true_sample_fn,
    true_predict_fn,
    n_test: int       = 5_000,
    n_js: int         = 10_000,
    active_threshold: float = 1e-3,
    seed=None,
) -> dict:
    """
    Compute all evaluation metrics for a fitted model.

    Parameters
    ----------
    model            : fitted GMMIsotropic (must have ``predict_proba`` and ``sample``)
    true_params      : dict with keys 'mu', 'm', 'sigma'
    true_sample_fn   : n → X ~ p_true
    true_predict_fn  : X → p_true(X)
    n_test           : sample size for TestLL
    n_js             : Monte-Carlo size for JS
    active_threshold : components with µ_k < threshold are treated as dead
    seed             : reproducibility

    Returns
    -------
    metrics : dict with keys 'TestLL', 'JS', 'PD', 'CRR', 'WeightErr', 'K_active'
    """
    rng    = np.random.default_rng(seed)
    X_test = true_sample_fn(n_test)

    # 1. TestLL ────────────────────────────────────────────────────────────────
    tll = test_log_likelihood(model.predict_proba, X_test)

    # 2. JS ────────────────────────────────────────────────────────────────────
    js = jensen_shannon_divergence(
        true_predict_fn  = true_predict_fn,
        model_predict_fn = model.predict_proba,
        true_sample_fn   = true_sample_fn,
        model_sample_fn  = lambda n: model.sample(n, seed=int(rng.integers(1_000_000_000))),
        n_samples        = n_js,
        seed             = int(rng.integers(1_000_000_000)),
    )

    # 3–5. PD + CRR + WeightErr (on active components only) ────────────────────
    active = model.mu > active_threshold
    est_mu    = model.mu[active]
    est_m     = model.m[active]
    est_sigma = model.sigma[active]
    if est_mu.sum() > 0:
        est_mu = est_mu / est_mu.sum()   # renormalise after removing dead components

    pd, matching = parametric_distance(
        true_params['mu'], true_params['m'], true_params['sigma'],
        est_mu, est_m, est_sigma,
        D=model.d,
    )
    crr = component_recovery_rate(
        true_params['mu'], true_params['m'], true_params['sigma'],
        est_mu, est_m, est_sigma,
        matching=matching,
    )
    weight_err = weight_recovery_error(true_params['mu'], est_mu, matching)

    return {
        'TestLL':    tll,
        'JS':        js,
        'PD':        pd,
        'CRR':       crr,
        'WeightErr': weight_err,
        'K_active':  int(active.sum()),
    }


# ─── Self-checks ───────────────────────────────────────────────────────────────

def _check_parametric_distance_collapse_guard():
    """
    Regression guard for a real bug found by review: parametric_distance's
    final sum used to require BOTH i<K_true and j<K_est, which silently
    DROPPED the _LARGE penalty for any true component matched to a dummy
    (non-existent) estimated component -- exactly what happens when the
    fitted model has fewer active components than K_true (a real, reachable
    state via evaluate_all_metrics' active_threshold filtering, e.g. under
    aggressive entropy-penalty pruning). Concretely this used to report
    PD=0.59 for a case where 2 of 3 true components had no estimate AT ALL,
    instead of a cost reflecting near-total failure.
    """
    rng = np.random.default_rng(0)
    true_mu = np.array([1/3, 1/3, 1/3])
    true_m = rng.normal(size=(3, 2)) * 5
    true_sigma = np.array([0.5, 0.5, 0.5])

    # collapsed case: only 1 of 3 true components has any real estimate
    est_mu, est_m, est_sigma = np.array([1.0]), np.array([[0.0, 0.0]]), np.array([1.0])
    pd_collapsed, _ = parametric_distance(true_mu, true_m, true_sigma,
                                           est_mu, est_m, est_sigma, D=2)
    assert pd_collapsed > 1e5, (
        f"parametric_distance under-penalised a collapsed fit: got {pd_collapsed}, "
        f"expected > 1e5 (2 of 3 true components have no real estimate)")

    # sanity: normal well-matched case (K_est==K_true) must stay small,
    # unaffected by the fix (no dummy pairs exist here)
    est_mu2, est_m2, est_sigma2 = true_mu.copy(), true_m + 0.05, true_sigma.copy()
    pd_matched, _ = parametric_distance(true_mu, true_m, true_sigma,
                                         est_mu2, est_m2, est_sigma2, D=2)
    assert pd_matched < 0.1, (
        f"parametric_distance regressed on a well-matched case: got {pd_matched}, expected < 0.1")

    print("[parametric_distance-collapse-guard] OK: collapsed fits are correctly "
          f"penalised (PD={pd_collapsed:.1f}), well-matched fits stay small (PD={pd_matched:.4f}).")


def _check_weight_recovery_error():
    """weight_recovery_error must isolate weight error, ignoring position/sigma entirely."""
    true_mu = np.array([0.2, 0.3, 0.5])
    matching = [(0, 0), (1, 1), (2, 2)]

    # perfect weight recovery
    est_mu_perfect = np.array([0.2, 0.3, 0.5])
    err = weight_recovery_error(true_mu, est_mu_perfect, matching)
    assert abs(err) < 1e-12, f"expected ~0 error for perfect recovery, got {err}"

    # known, deliberate weight error
    est_mu_off = np.array([0.3, 0.3, 0.4])   # errs: 0.1, 0.0, 0.1 -> mean 0.0667
    err2 = weight_recovery_error(true_mu, est_mu_off, matching)
    assert abs(err2 - (0.1 + 0.0 + 0.1) / 3) < 1e-12, f"wrong error value: {err2}"

    # total collapse: no real pairs matched -> NaN, not a silently-wrong number
    err3 = weight_recovery_error(true_mu, np.array([1.0]), [(0, 5), (1, 5), (2, 5)])
    assert np.isnan(err3), f"expected NaN when no real pair is matched, got {err3}"

    print("[weight-recovery-error] OK: isolates weight error correctly, "
          "NaN (not a misleading number) when nothing real is matched.")


if __name__ == '__main__':
    _check_parametric_distance_collapse_guard()
    _check_weight_recovery_error()
