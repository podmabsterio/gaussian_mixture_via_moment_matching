"""
model_sklearn.py — classic EM baseline (sklearn.mixture.GaussianMixture),
wrapped to the SAME interface GMMDimensionFree3 exposes, so it drops into
the same Hydra harness / metrics.py evaluation unchanged.

Required interface (what pipeline.py / metrics.py actually call):
    model.fit(X, maxiter_inner=..., seed=...)   -> self
    model.predict_proba(X)                       -> density (n,), NOT
                                                     sklearn's own meaning
                                                     of predict_proba
                                                     (per-component
                                                     posterior weights) --
                                                     this is the total
                                                     mixture density.
    model.sample(n, seed=...)                    -> X (n, d)
    model.mu, model.m, model.sigma, model.K, model.d

`sigma` is a single scalar per component (isotropic), to stay compatible
with metrics.py's parametric_distance / component_recovery_rate, which
assume isotropic ground truth. For covariance_type != 'spherical' this is
an APPROXIMATION: sqrt(trace(cov_k)/d), i.e. the average per-axis
variance -- fine for a summary number, but the actual likelihood
(predict_proba) always uses sklearn's real fitted covariance, never this
approximation.
"""
from __future__ import annotations

import numpy as np
from sklearn.mixture import GaussianMixture


class SklearnGMMBaseline:
    def __init__(
        self,
        K: int,
        covariance_type: str = 'spherical',
        n_init: int = 3,
        max_iter: int = 200,
        reg_covar: float = 1e-6,
        sigma_floor: float = 1e-3,
        link_mode: str = 'sklearn_em',   # informational only (see conf/model/sklearn_em*.yaml);
                                          # pipeline.py reads cfg.model.link_mode for every model type
    ):
        self.K = K
        self.covariance_type = covariance_type
        self.n_init = n_init
        self.max_iter = max_iter
        self.reg_covar = reg_covar
        self.sigma_floor = sigma_floor
        self.link_mode = link_mode

        self._skl = None
        self.d = None
        self.mu = self.m = self.sigma = None

    def fit(self, X, maxiter_inner=None, seed=None):
        # `maxiter_inner` is accepted only for interface parity with
        # GMMDimensionFree3.fit (pipeline.py calls both the same way) --
        # unused here. sklearn's own EM-iteration knob is `max_iter`, set
        # at construction time instead, since sklearn has no per-call
        # override for it.
        n, d = X.shape
        self.d = d
        self._skl = GaussianMixture(
            n_components=self.K,
            covariance_type=self.covariance_type,
            n_init=self.n_init,
            max_iter=self.max_iter,
            reg_covar=self.reg_covar,
            random_state=seed,
        ).fit(X)

        self.mu = self._skl.weights_.copy()
        self.m = self._skl.means_.copy()
        self.sigma = self._isotropic_sigma(self._skl.covariances_, d)
        return self

    def _isotropic_sigma(self, cov, d):
        ct = self.covariance_type
        floor2 = self.sigma_floor ** 2
        if ct == 'spherical':
            return np.sqrt(np.clip(cov, floor2, None))
        if ct == 'diag':
            return np.sqrt(np.clip(cov.mean(axis=1), floor2, None))
        if ct == 'full':
            return np.sqrt(np.clip(np.trace(cov, axis1=1, axis2=2) / d, floor2, None))
        if ct == 'tied':
            s = np.sqrt(max(np.trace(cov) / d, floor2))
            return np.full(self.K, s)
        raise ValueError(f"unknown covariance_type: {ct!r}")

    def predict_proba(self, X):
        # score_samples() returns the TOTAL log mixture density (what we
        # want) -- do not confuse with sklearn's own .predict_proba(),
        # which means per-component posterior responsibility, a different
        # quantity entirely.
        return np.exp(self._skl.score_samples(X))

    def sample(self, n, seed=None):
        # Deliberately NOT delegated to sklearn's own .sample(): that
        # reuses the estimator's random_state fixed at construction time,
        # so repeated calls return IDENTICAL samples regardless of the
        # `seed` passed here. metrics.py's JS-divergence estimate calls
        # this with a FRESH seed every time (see evaluate_all_metrics), so
        # sampling is done manually from the fitted parameters instead.
        rng = np.random.default_rng(seed)
        p = self.mu / self.mu.sum()
        labels = rng.choice(self.K, size=n, p=p)
        X = np.zeros((n, self.d))
        cov = self._skl.covariances_
        for k in range(self.K):
            mask = labels == k
            nk = int(mask.sum())
            if nk == 0:
                continue
            if self.covariance_type in ('spherical', 'diag'):
                X[mask] = rng.normal(loc=self.m[k], scale=np.sqrt(cov[k]), size=(nk, self.d))
            elif self.covariance_type == 'full':
                X[mask] = rng.multivariate_normal(self.m[k], cov[k], size=nk)
            elif self.covariance_type == 'tied':
                X[mask] = rng.multivariate_normal(self.m[k], cov, size=nk)
        return X

    def __repr__(self):
        return (f"SklearnGMMBaseline(K={self.K}, "
                f"covariance_type={self.covariance_type!r}, fitted={self._skl is not None})")


# ─── Self-checks ───────────────────────────────────────────────────────────────

def _check_sample_reseedable():
    """
    Regression guard for the specific bug this wrapper's sample() avoids:
    sklearn's own GaussianMixture.sample() reuses the estimator's
    random_state fixed at construction time, so calling it repeatedly with
    a fresh `seed` argument (as metrics.py's JS-divergence estimate does)
    would silently return IDENTICAL samples every time. Our sample()
    re-seeds from scratch each call instead.
    """
    rng = np.random.default_rng(0)
    X = np.concatenate([rng.normal(-3, 0.5, size=(200, 2)), rng.normal(3, 0.5, size=(200, 2))])
    model = SklearnGMMBaseline(K=2, covariance_type='spherical', n_init=1)
    model.fit(X, seed=0)

    same_seed_1 = model.sample(50, seed=1)
    same_seed_2 = model.sample(50, seed=1)
    diff_seed = model.sample(50, seed=2)
    assert np.allclose(same_seed_1, same_seed_2), "same seed must reproduce identical samples"
    assert not np.allclose(same_seed_1, diff_seed), \
        "different seeds must give different samples (this is exactly the bug being guarded against)"
    print("[sklearn-sample-reseedable] OK: same seed reproducible, different seeds genuinely differ.")


def _check_predict_proba_vs_scipy():
    """predict_proba (spherical) must match an independent scipy reference."""
    from scipy.stats import multivariate_normal
    rng = np.random.default_rng(1)
    X = np.concatenate([rng.normal(-3, 0.5, size=(300, 2)), rng.normal(3, 0.7, size=(300, 2))])
    model = SklearnGMMBaseline(K=2, covariance_type='spherical', n_init=3).fit(X, seed=0)

    Xq = rng.normal(size=(10, 2))
    ref = sum(model.mu[k] * multivariate_normal(mean=model.m[k], cov=model.sigma[k] ** 2 * np.eye(2)).pdf(Xq)
              for k in range(2))
    got = model.predict_proba(Xq)
    max_err = np.max(np.abs(ref - got))
    assert max_err < 1e-8, f"predict_proba mismatch vs scipy: {max_err}"
    print(f"[sklearn-predict-proba-vs-scipy] OK: max abs diff = {max_err:.2e}")


def _check_all_covariance_types():
    """Every covariance_type must fit, predict, and sample without error."""
    rng = np.random.default_rng(2)
    X = rng.normal(size=(300, 4))
    for ct in ('spherical', 'diag', 'full', 'tied'):
        model = SklearnGMMBaseline(K=3, covariance_type=ct, n_init=1).fit(X, seed=0)
        p = model.predict_proba(X[:20])
        assert np.all(np.isfinite(p)) and np.all(p > 0), f"{ct}: bad predict_proba"
        Xs = model.sample(50, seed=0)
        assert Xs.shape == (50, 4), f"{ct}: bad sample shape"
        assert model.sigma.shape == (3,), f"{ct}: sigma not (K,) shaped: {model.sigma.shape}"
    print("[sklearn-all-covariance-types] OK: spherical/diag/full/tied all fit, predict, and sample cleanly.")


if __name__ == '__main__':
    _check_sample_reseedable()
    _check_predict_proba_vs_scipy()
    _check_all_covariance_types()
