"""
model_df3.py — Dimension-Free procedure, Sections 1.2-1.4 of Spokoiny,
"Gaussian Mixture Model" (June 20, 2026).

Key formula (1.12), single free logit c_k per component (NO per-scale c_{k,s}):

  psi_j(theta) = sum_k exp{ c_k + kappa(1-s_o^2/s_j^2) sigma_k^2
                             - ||m_k-x_j||^2/(2(sigma_k^2+s_j^2)) }
                 * <m_k-x_j, u_j> / (sigma_k^2/s_j^2 + 1)

  kappa = d/(2 s_o^2),  s_o = min(S)   (1.10)

The dimension-dependent amplitude correction across scales is folded
DIRECTLY into the exponent via the kappa-quadratic term — this is a
LINEARIZED approximation of the exact -{d/2} log(1+sigma^2/s^2) term
(valid for sigma/s = O(d^{-1/2}), see Section 1.3's derivation), NOT an
exact hard link. No separate weight-recovery QP is needed or used: c_k
IS the parameter, throughout. `link_mode='exact'` swaps in the exact
log-ratio instead of this linearisation, isolating that one modelling
choice from everything else (identical outer/inner procedure either way).

Outer procedure (Section 1.4.2), a proximal / trust-region scheme:
  1. init test points (x_j, u_j, s_j) per 1.4.1's recipe:
       - x_j: perturbed subset of {X_i} (probability p0, default 1.0)
       - u_j: uniform on the unit sphere
       - s_j: 3 growing bandwidth levels chosen by bisection on the
         effective-local-volume h(s) (Prop. 3), targeting N_1=n/(2K),
         N_2=n/(sqrt(2)K), N_3=n/K; each test point gets one s_j drawn
         uniformly at random from this 3-element set S.
  2. m0 := starting guess (KMeans here; paper allows "any external solver")
  3. repeat: compute Z (fixed given current test points), solve the FULL
     inner problem argmin_theta { L(theta) + pen(c) + (lambda_m/2)||m-m0||^2 }
     via L-BFGS-B, then update m0 := m_tilde (the new anchor) and shrink
     lambda_m, optionally resampling test points near the new estimate.
     The entropy penalty pen(c) is ANNEALED IN (see lambda_ent_start_outer
     below) rather than applied at constant strength from the first outer
     iteration -- applying it immediately was found to catastrophically
     over-collapse components before the fit-loss had any chance to
     converge on real structure first (see the weight-collapse-threshold
     discussion this project has been tracking).

Loss is Euclidean: L(theta) = 1/2 ||Z - psi(theta)||^2.

Every analytic gradient is checked against finite differences, and the
moment formula's sign convention against Monte Carlo, in the __main__ block.

NOT YET IMPLEMENTED (deferred on purpose): Section 2.2's "effective
dimension" M for the anisotropic/manifold-adapted amplitude correction.
Everything in this file is currently isotropic-only (M=d implicitly,
everywhere). Planned as a separate, later addition once the isotropic
story here is confirmed solid.
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import minimize, brentq
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
from sklearn.cluster import KMeans

EPS = 1e-12


# ─── Effective-volume bandwidth selection (bisection) ─────────────────────────

def effective_volume(X, xi, s):
    """ h(s) = (1/J) sum_j sum_i exp(-||X_i-xi_j||^2/(2s^2)) """
    d2 = cdist(X, xi, metric='sqeuclidean')
    return np.exp(-d2 / (2 * s ** 2)).sum() / xi.shape[0]


def bisect_bandwidth(X, xi, N_target, lo=1e-3, hi=None):
    n = X.shape[0]
    N_target = min(N_target, 0.95 * n)   # h(s) -> n as s->inf (Prop. 3); a target
                                          # above n is infeasible and would send
                                          # the bracket-widening loop below to inf
    if hi is None:
        hi = 10.0 * X.std()
    f = lambda s: effective_volume(X, xi, s) - N_target
    flo, fhi = f(lo), f(hi)
    n_expand = 0
    while flo > 0 and n_expand < 50:
        lo /= 10; flo = f(lo); n_expand += 1
    n_expand = 0
    while fhi < 0 and n_expand < 50:
        hi *= 10; fhi = f(hi); n_expand += 1
    # MINOR FIX (caught by review): on genuinely degenerate input (e.g. all
    # points identical / zero variance), h(s) is CONSTANT at n for every
    # s > 0 (every pairwise distance is exactly 0, so the bandwidth has no
    # effect), so no bracket for the bisection can ever exist -- flo stays
    # positive no matter how far lo shrinks. This used to surface as
    # scipy's generic "f(a) and f(b) must have different signs" from
    # brentq, which doesn't point at the actual cause. Not a correctness
    # bug (the code correctly refuses to proceed on garbage input rather
    # than silently returning something), just an unhelpful error message.
    if flo > 0 or fhi < 0:
        raise ValueError(
            "bisect_bandwidth: could not bracket a bandwidth achieving "
            f"N_target={N_target:.3g} (h(lo)={flo + N_target:.3g}, "
            f"h(hi)={fhi + N_target:.3g} after bracket widening). This "
            "usually means the data is (near-)degenerate -- e.g. all "
            "points identical / effectively zero variance -- so the "
            "effective volume h(s) doesn't vary with the bandwidth s."
        )
    return brentq(f, lo, hi, xtol=1e-6)


# ─── Test-point initialization (Section 1.4.1) ────────────────────────────────

def init_test_points(X, K, p0=1.0, sigma0=None, seed=None, max_J=400, bandwidth_mult=1.0):
    """
    Returns (xi, U, s_of_j, S) — xi:(J,d), U:(J,d) unit directions,
    s_of_j:(J,) each test point's assigned bandwidth, S: the 3 discrete levels.

    NOTE: paper's default p0=1.0 (every data point becomes a test centre).
    We cap J at `max_J` for tractability in repeated experiments — flagged
    explicitly since it deviates from the literal default for compute
    reasons, not a modelling choice.

    bandwidth_mult: multiplies the target N_1,N_2,N_3 (paper's defaults
    n/(2K), n/(sqrt(2)K), n/K). Since h(s) is strictly increasing in s
    (Prop. 3), a LARGER target N gives a LARGER bandwidth.
    """
    rng = np.random.default_rng(seed)
    n, d = X.shape

    if sigma0 is None:
        # rough guess of "typical observation noise": per-cluster KMeans std
        # BUG FIX (caught by review): the fallback for empty/singleton
        # clusters used X.std() -- the std of the ENTIRE flattened data
        # array (all dimensions and points pooled together). On data whose
        # components sit at different locations along different dimensions,
        # this pools points that are far apart under different means,
        # inflating the estimate by an order of magnitude or more (measured
        # ~19x on a synthetic 3-dimension-offset example) relative to the
        # true-branch's per-dimension-variance style estimate. Empirically
        # this fallback fires in ~88% of trials under the paper's own
        # recommended usage (K deliberately over-specified relative to n,
        # entropy penalty expected to prune the rest) -- not a rare corner
        # case. Fixed to use the same per-dimension-variance scale, just
        # computed over the whole dataset instead of the (empty) cluster.
        _whole_data_scale = float(np.sqrt(np.var(X, axis=0).mean()))
        km0 = KMeans(n_clusters=K, n_init=3, random_state=seed).fit(X)
        sigma0 = float(np.mean([
            np.sqrt(np.var(X[km0.labels_ == k], axis=0).mean())
            if (km0.labels_ == k).sum() > 1 else _whole_data_scale
            for k in range(K)
        ]))

    J_target = min(max_J, max(int(p0 * n), 10 * K))
    idx = rng.choice(n, size=J_target, replace=False)
    xi = X[idx] + rng.normal(scale=sigma0, size=(J_target, d))

    U = rng.normal(size=(J_target, d))
    U /= np.linalg.norm(U, axis=1, keepdims=True)

    N1 = bandwidth_mult * n / (2 * K)
    N2 = bandwidth_mult * n / (np.sqrt(2) * K)
    N3 = bandwidth_mult * n / K
    # bisection needs a reference set of centres; use a subsample for speed
    ref_idx = rng.choice(n, size=min(n, 300), replace=False)
    s1 = bisect_bandwidth(X, X[ref_idx], N1)
    s2 = bisect_bandwidth(X, X[ref_idx], N2)
    s3 = bisect_bandwidth(X, X[ref_idx], N3)
    S = np.array(sorted([s1, s2, s3]))

    s_of_j = rng.choice(S, size=J_target)
    return xi, U, s_of_j, S


def empirical_moment(X, xi, U, s_of_j, batch_size=4000):
    """ Z_j = (1/n) sum_i <X_i-xi_j,u_j> exp(-||X_i-xi_j||^2/(2 s_j^2)) —
        grouped by the (few) distinct s values for vectorised computation. """
    n = X.shape[0]
    J = xi.shape[0]
    Z = np.zeros(J)
    for s_val in np.unique(s_of_j):
        mask = s_of_j == s_val
        xi_g, U_g = xi[mask], U[mask]
        out = np.zeros(mask.sum())
        for start in range(0, n, batch_size):
            Xb = X[start:start + batch_size]
            diff = Xb[:, None, :] - xi_g[None, :, :]
            d2 = (diff ** 2).sum(-1)
            kern = np.exp(-d2 / (2 * s_val ** 2))
            proj = (diff * U_g[None, :, :]).sum(-1)
            out += (proj * kern).sum(0)
        Z[mask] = out / n
    return Z


# ─── Core forward + analytic gradient (formula 1.12) ──────────────────────────

def _pack(m, sigma, c):
    return np.concatenate([m.ravel(), sigma.ravel(), c.ravel()])


def _unpack(theta, K, d):
    i = K * d
    m = theta[:i].reshape(K, d)
    sigma = theta[i:i + K]
    c = theta[i + K:i + 2 * K]
    return m, sigma, c


def _loss_and_grad(theta, K, d, xi, U, s_of_j, Z, s_o,
                    lambda_ent, lambda_m, m0, link_mode='kappa',
                    lambda_overlap=0.0, lambda_repel=0.0, repel_scale=None):
    """
    link_mode='kappa'  : linearised amplitude correction (paper's formula 1.12,
                         a single free c_k, approximate across scales).
    link_mode='exact'  : EXACT amplitude correction (no linearisation) —
                         same single free c_k per component, but the
                         cross-scale correction term uses the exact
                         log-ratio instead of its first-order Taylor
                         expansion. Isolates the kappa-linearisation choice
                         from the outer-iteration procedure, which is
                         IDENTICAL in both modes.

    kappa = d/(2*s_o^2) is computed HERE from d and s_o (not passed in
    separately) -- merged fix: passing it as an independent argument meant
    it could get out of sync with the d/s_o actually used elsewhere in the
    same call, a needless footgun since it's a pure function of the two.

    lambda_overlap: weight of an EXPERIMENTAL pairwise-overlap penalty
        pen = lambda_overlap * sum_{i<j} mu_i mu_j BC(f_i,f_j)
    using the isotropic-Gaussian Bhattacharyya coefficient:
        BC_ij = (2 sigma_i sigma_j / (sigma_i^2+sigma_j^2))^{d/2}
                 exp(-||m_i-m_j||^2 / (4(sigma_i^2+sigma_j^2)))
    Explored as an alternative/companion to the weight-entropy penalty.
    Gradient is routed ONLY through c (stop-gradient through m, sigma) --
    the full gradient has two "cheating" backdoors (moving the pair apart
    in position, or inflating sigma to cheaply boost effective weight in
    the mu-normalisation) that reduce the penalty without actually pruning
    anything. Even after blocking both, this was found to correctly
    identify duplicate/overlapping pairs but stall on a SYMMETRY-BREAKING
    problem: near-identical duplicates get near-identical penalty
    gradients, so both shrink together rather than one collapsing while
    the other absorbs its mass. Kept as available (default 0.0, off) --
    an honest partial result, not a solved mechanism.

    lambda_repel, repel_scale: a DIFFERENT, purely geometric identifiability
    mechanism -- a Gaussian repulsion penalty directly on component centres,
    independent of weight or sigma:
        pen = lambda_repel * sum_{i<j} exp(-||m_i-m_j||^2 / (2*repel_scale^2))
    Hypothesis was that pushing redundant components apart in space would
    let the ordinary fit-loss (not this penalty) drive their weight to ~0
    on its own, sidestepping the overlap penalty's symmetry-breaking
    problem since repulsion never goes through mu at all. Empirically
    found NOT to reliably do this on its own -- kept available (default
    0.0, off) for reference / further attempts, gradient-checked below
    regardless since it's a genuine full gradient of an added term.
    """
    kappa = d / (2 * s_o ** 2)
    m, sigma, c = _unpack(theta, K, d)

    r = m[:, None, :] - xi[None, :, :]                # (K,J,d)  r_kj = m_k - xi_j
    dist2 = (r ** 2).sum(-1)                            # (K,J)
    D = (sigma ** 2)[:, None] + s_of_j[None, :] ** 2     # (K,J)
    proj = (r * U[None, :, :]).sum(-1)                   # (K,J)

    sigma2 = (sigma ** 2)[:, None]                        # (K,1)
    g_factor = 1.0 / (sigma2 / (s_of_j[None, :] ** 2) + 1.0)  # (K,J)
    E = np.exp(-dist2 / (2 * D))

    if link_mode == 'kappa':
        kappa_j = kappa * (1.0 - (s_o ** 2) / (s_of_j ** 2))     # (J,)
        amp_corr = kappa_j[None, :] * sigma2                       # (K,J)
        # d(amp_corr)/dsigma_k = 2*kappa_j*sigma_k
        damp_dsigma = 2.0 * kappa_j[None, :] * sigma[:, None]      # (K,J)
    elif link_mode == 'exact':
        amp_corr = 0.5 * d * (np.log1p(sigma2 / s_o ** 2)
                              - np.log1p(sigma2 / (s_of_j[None, :] ** 2)))  # (K,J)
        # d(amp_corr)/dsigma_k = d*sigma_k*[1/(s_o^2+sigma_k^2) - 1/(s_j^2+sigma_k^2)]
        damp_dsigma = d * sigma[:, None] * (
            1.0 / (s_o ** 2 + sigma2) - 1.0 / (s_of_j[None, :] ** 2 + sigma2))
    else:
        raise ValueError("link_mode must be 'kappa' or 'exact'")

    amp_exponent = c[:, None] + amp_corr                  # (K,J)
    W = np.exp(amp_exponent) * g_factor * E                # (K,J)

    A = W * proj                                           # (K,J)
    psi = A.sum(0)                                          # (J,)

    res = psi - Z
    loss = 0.5 * np.dot(res, res)
    total_loss = loss

    # entropy-like penalty directly on c (Section 1.2/1.4.2)
    pi = np.exp(c - c.max())
    pi /= pi.sum()
    ent = -np.sum(pi * np.log(pi + EPS))
    total_loss += lambda_ent * ent

    # ---- pairwise overlap penalty (Bhattacharyya coefficient) [experimental] ----
    grad_m_overlap = np.zeros_like(m)
    grad_sigma_overlap = np.zeros_like(sigma)
    grad_c_overlap = np.zeros_like(c)
    if lambda_overlap > 0:
        # normalised weights consistent with the mu property (log-domain for
        # stability): e^{c_k} = mu_k (1+sigma_k^2/s_o^2)^{-d/2} at the
        # reference scale s_o, so log_w_k = c_k + (d/2)log1p(sigma_k^2/s_o^2)
        log_w = c + 0.5 * d * np.log1p((sigma ** 2) / (s_o ** 2))
        w_un = np.exp(log_w - log_w.max())
        mu = w_un / w_un.sum()

        diff_pair = m[:, None, :] - m[None, :, :]                 # (K,K,d)  m_i - m_j
        dist2_pair = (diff_pair ** 2).sum(-1)                      # (K,K)
        V = sigma[:, None] ** 2 + sigma[None, :] ** 2              # (K,K)  sigma_i^2+sigma_j^2
        rho = 2 * sigma[:, None] * sigma[None, :] / V              # (K,K)
        log_BC = 0.5 * d * np.log(rho + EPS) - dist2_pair / (4 * V)
        BC = np.exp(log_BC)
        np.fill_diagonal(BC, 0.0)   # exclude self-overlap (i=j)

        mu_outer = mu[:, None] * mu[None, :]                        # (K,K)
        S_overlap = 0.5 * np.sum(mu_outer * BC)                     # sum_{i<j} mu_i mu_j BC_ij
        total_loss += lambda_overlap * S_overlap

        # dS/dmu_k = sum_{j!=k} mu_j BC_kj =: g_k
        g_ov = (mu[None, :] * BC).sum(1)                            # (K,)
        g_bar = np.dot(g_ov, mu)
        # chain rule through the softmax-like normalisation of mu:
        # d(mu_k)/d(log_w_i) = mu_k(delta_ki - mu_i)
        dS_dlogw = mu * (g_ov - g_bar)                              # (K,)
        grad_c_overlap = lambda_overlap * dS_dlogw

        # STOP-GRADIENT through BOTH m and sigma -- see docstring above for
        # why (two "cheating" backdoors that don't actually prune anything).
        # Left commented (not deleted) so both backdoors are easy to
        # restore individually if revisiting this experiment:
        #
        # dlogw_dsigma = d * sigma / (s_o ** 2 + sigma ** 2)
        # grad_sigma_overlap = lambda_overlap * dS_dlogw * dlogw_dsigma
        # term1 = 0.5 * d * (1.0 / sigma[:, None] - 2 * sigma[:, None] / V)
        # term2 = sigma[:, None] * dist2_pair / (2 * V ** 2)
        # dBC_dsigma_i = BC * (term1 + term2)
        # grad_sigma_overlap += lambda_overlap * (mu_outer * dBC_dsigma_i).sum(1)
        # dBC_dm_i = -BC[:, :, None] * diff_pair / (2 * V[:, :, None])
        # grad_m_overlap = lambda_overlap * (mu_outer[:, :, None] * dBC_dm_i).sum(1)

    # ---- pairwise repulsion penalty (pure geometry, no weight coupling) [experimental] ----
    grad_m_repel = np.zeros_like(m)
    if lambda_repel > 0:
        rs = repel_scale if repel_scale is not None else s_o
        diff_r = m[:, None, :] - m[None, :, :]                     # (K,K,d)  m_i - m_j
        dist2_r = (diff_r ** 2).sum(-1)                             # (K,K)
        f_r = np.exp(-dist2_r / (2 * rs ** 2))
        np.fill_diagonal(f_r, 0.0)                                   # exclude self-term (i=j)
        total_loss += lambda_repel * 0.5 * np.sum(f_r)               # sum_{i<j} f_r_ij

        # d(pen)/dm_i = -lambda_repel * sum_{j!=i} f_r_ij * (m_i-m_j) / rs^2
        grad_m_repel = -lambda_repel * (f_r[:, :, None] * diff_r).sum(1) / rs ** 2

    # proximal ridge toward the CURRENT outer-iteration anchor m0
    total_loss += 0.5 * lambda_m * np.sum((m - m0) ** 2)

    # ---- backprop ----
    dL_dA = res[None, :]                                  # (1,J) broadcasts to (K,J)

    grad_m = (dL_dA[:, :, None] * (W[:, :, None] * U[None, :, :]
              - (W * proj / D)[:, :, None] * r)).sum(1)
    grad_m += lambda_m * (m - m0)
    grad_m += grad_m_overlap
    grad_m += grad_m_repel

    # d ln(W)/d sigma_k = damp_dsigma/W_amplitude_part - 2/D*sigma + dist2/D^2*sigma
    #   (the last two terms are IDENTICAL in both modes -- g_factor and E's
    #    own sigma-dependence never involved the linearisation choice)
    dlnW_dsigma = damp_dsigma - 2.0 * sigma[:, None] / D + sigma[:, None] * dist2 / D ** 2
    dA_dsigma = W * proj * dlnW_dsigma
    grad_sigma = (dL_dA * dA_dsigma).sum(1)
    grad_sigma += grad_sigma_overlap

    # dA_kj/dc_k = A_kj  (direct, c_k is a free unconstrained parameter here)
    grad_c = (dL_dA * A).sum(1)
    grad_c += grad_c_overlap

    # entropy-penalty gradient (applied to c/pi)
    H = -np.log(pi + EPS)
    grad_c += lambda_ent * pi * (H - ent)

    return total_loss, _pack(grad_m, grad_sigma, grad_c)


# ─── Public model, implementing the FULL outer/inner procedure (1.4.2) ───────

class GMMDimensionFree3:
    def __init__(self, K, p0=1.0, max_J=400, lambda_ent=0.0, lambda_ent_start_outer=None,
                 lambda_overlap=0.0, lambda_repel=0.0, repel_scale=None,
                 lambda_m_init=1.0, lambda_m_decay=0.5, sigma_floor=1e-2,
                 sigma_ceil=None, n_outer=6, resample=True, link_mode='kappa',
                 bandwidth_mult=1.0):
        self.K = K
        self.p0 = p0
        self.max_J = max_J
        self.lambda_ent = lambda_ent
        # MERGED: entropy-penalty annealing. Default: only the LAST outer
        # iteration ramps entropy in at full strength -- applying it at
        # constant strength from outer=0 was found to catastrophically
        # over-collapse components before the fit-loss had converged on
        # real structure (directly relevant to this project's
        # weight-collapse-threshold investigation).
        self.lambda_ent_start_outer = (
            lambda_ent_start_outer if lambda_ent_start_outer is not None else max(n_outer - 1, 0))
        self.lambda_overlap = lambda_overlap  # experimental Bhattacharyya overlap penalty (default off)
        self.lambda_repel = lambda_repel      # experimental geometric repulsion penalty (default off)
        self.repel_scale = repel_scale        # None -> defaults to s_o at fit time
        self.lambda_m_init = lambda_m_init
        self.lambda_m_decay = lambda_m_decay
        self.sigma_floor = sigma_floor
        self.sigma_ceil = sigma_ceil          # MERGED: optional upper bound, guards against
                                               # sigma -> inf "component death"; None = unbounded (unchanged default)
        self.n_outer = n_outer
        self.resample = resample
        self.link_mode = link_mode  # 'kappa' (paper's 1.12) or 'exact' (no linearisation)
        self.bandwidth_mult = bandwidth_mult

        self.m = None
        self.sigma = None
        self.c = None
        self.d = None
        self.S_ = None
        self.history_ = []

    def fit(self, X, maxiter_inner=300, seed=None, init_m=None, init_sigma=None):
        """
        init_m, init_sigma: MERGED -- optional overrides bypassing the
        internal KMeans initializer entirely, for testing robustness to
        deliberately corrupted starting points.
        """
        rng = np.random.default_rng(seed)
        n, d = X.shape
        self.d = d
        K = self.K
        self.history_ = []   # MERGED FIX: reset across repeated fit() calls on the
                              # same instance -- this used to keep ACCUMULATING
                              # across calls (e.g. multi-restart re-fitting the same
                              # object), silently mixing histories from different fits.

        # MERGED: compute the starting guess FIRST (previously this ran a
        # second, redundant internal KMeans inside init_test_points just to
        # estimate a jitter scale -- now that estimate is reused for both
        # purposes, halving the KMeans calls per fit).
        if init_m is not None:
            m0 = init_m.copy()
            sigma_init = init_sigma.copy() if init_sigma is not None else np.full(K, X.std())
            sigma_init = np.maximum(sigma_init, self.sigma_floor * 2)
        else:
            km = KMeans(n_clusters=K, n_init=4, random_state=seed).fit(X)
            labels = km.labels_
            m0 = km.cluster_centers_ + rng.normal(scale=0.05, size=(K, d))
            # BUG FIX (caught by review): same X.std() fallback issue as in
            # init_test_points -- see the comment there. Same fix: fall back
            # to the whole-dataset per-dimension-variance estimate, not the
            # pooled flatten, which fires in the majority of
            # over-specified-K/small-n runs (the paper's own recommended
            # usage pattern) and can badly mis-scale the L-BFGS-B starting
            # point for that component.
            _whole_data_scale = float(np.sqrt(np.var(X, axis=0).mean()))
            sigma_init = np.array([
                max(np.sqrt(np.var(X[labels == k], axis=0).mean()), self.sigma_floor * 2)
                if (labels == k).sum() > 1 else max(_whole_data_scale, self.sigma_floor * 2)
                for k in range(K)
            ])
        c_init = np.zeros(K)

        xi, U, s_of_j, S = init_test_points(X, K, p0=self.p0, sigma0=float(np.median(sigma_init)),
                                             seed=seed, max_J=self.max_J,
                                             bandwidth_mult=self.bandwidth_mult)
        s_o = float(S.min())
        self.S_ = S

        theta = _pack(m0.copy(), sigma_init, c_init)
        lambda_m = self.lambda_m_init

        # MERGED: bounds computed once (sigma_ceil support), not recomputed
        # identically every outer iteration.
        bounds = ([(None, None)] * (K * d) + [(self.sigma_floor, self.sigma_ceil)] * K
                  + [(None, None)] * K)

        for outer in range(self.n_outer):
            Z = empirical_moment(X, xi, U, s_of_j)

            # MERGED: entropy/overlap/repel penalty annealing -- see
            # lambda_ent_start_outer's docstring in __init__.
            if outer < self.lambda_ent_start_outer:
                lambda_ent_eff = 0.0
                lambda_overlap_eff = 0.0
                lambda_repel_eff = 0.0
            else:
                span = max(self.n_outer - self.lambda_ent_start_outer, 1)
                frac = (outer - self.lambda_ent_start_outer + 1) / span
                lambda_ent_eff = self.lambda_ent * min(frac, 1.0)
                lambda_overlap_eff = self.lambda_overlap * min(frac, 1.0)
                lambda_repel_eff = self.lambda_repel * min(frac, 1.0)

            res = minimize(
                _loss_and_grad, theta,
                args=(K, d, xi, U, s_of_j, Z, s_o, lambda_ent_eff, lambda_m, m0,
                      self.link_mode, lambda_overlap_eff, lambda_repel_eff,
                      self.repel_scale if self.repel_scale is not None else s_o),
                jac=True, method='L-BFGS-B', bounds=bounds,
                options={'maxiter': maxiter_inner},
            )
            theta = res.x
            m_hat, sigma_hat, c_hat = _unpack(theta, K, d)
            self.history_.append(float(res.fun))

            m0 = m_hat.copy()             # update proximal anchor
            lambda_m *= self.lambda_m_decay

            if self.resample and outer < self.n_outer - 1:
                # BUG FIX (caught by review): resample seed used to be
                # (seed or 0) + outer + 1 -- when seed=None (the default,
                # meant to give a genuinely random run each call, e.g. for
                # multi-restart diversity), `seed or 0` collapses to 0
                # regardless, making this resample_seed IDENTICAL (1,2,3,...)
                # across every "random" call. Only the very first outer
                # iteration's KMeans/rng actually varied; every later
                # refinement step used byte-identical test points across
                # restarts, undermining exactly what multi-restart is for.
                # Fixed by drawing from `rng`, which already correctly
                # incorporates OS entropy when seed=None, while remaining
                # fully reproducible when an explicit seed is passed (same
                # seed -> same rng -> same draw sequence).
                resample_seed = int(rng.integers(0, 2**31 - 1))
                xi, U, s_of_j, S = init_test_points(
                    X, K, p0=self.p0, sigma0=float(np.median(sigma_hat)),
                    seed=resample_seed, max_J=self.max_J,
                    bandwidth_mult=self.bandwidth_mult)
                s_o = float(S.min())
                self.S_ = S

        self.m, self.sigma, self.c = m_hat, sigma_hat, c_hat
        return self

    # ---- weight recovery for interpretation / prediction only -------------
    # c_k is NOT exactly log(mu_k) once multiple scales are linearised in
    # (recall the entropy penalty operates on softmax(c), an APPROXIMATE
    # proxy for mu -- see module docstring). For prediction we don't need mu
    # explicitly: psi_j(theta) only needs (m,sigma,c). But for reporting /
    # comparison against a ground-truth mu we recover it via the same closed
    # form used to build c in the first place, evaluated at s_o (reference
    # bandwidth, kappa-correction term vanishes there since s_j=s_o -> kappa_j=0):
    #
    #   e^{c_k} = mu_k (1+sigma_k^2/s_o^2)^{-d/2}   =>   mu_k ∝ e^{c_k}(1+sigma_k^2/s_o^2)^{d/2}
    #
    # BUG FOUND AND FIXED (caught by review): this (1+sigma_k^2/s_o^2)^{d/2}
    # factor was MISSING below (mu was computed as softmax(c) directly). It
    # is invisible whenever all components share the same sigma (the factor
    # is then a common constant that cancels on normalisation) -- so none of
    # the prior stability / link-mode conclusions on homogeneous-sigma data
    # are affected. With heterogeneous sigma, omitting it biases mu by up to
    # ~30% in a quick test (d=10, sigma in [0.5,2.5]).
    @property
    def mu(self):
        if self.c is None:
            return None
        s_o = float(self.S_.min())  # reference bandwidth of the LAST outer iteration
        log_correction = 0.5 * self.d * np.log1p((self.sigma ** 2) / (s_o ** 2))
        log_w = self.c + log_correction
        w = np.exp(log_w - log_w.max())   # numerically stable for large d
        return w / w.sum()

    # exp(700) ~ 1e304, just under float64 max (~1.8e308). Above this the
    # true density itself is not representable as a finite float64 (this
    # only happens for a test point essentially coincident with a
    # collapsed, near-zero-sigma component) -- we saturate rather than
    # return inf/nan, since that's the log-density value TestLL actually
    # needs downstream, not the linear-space density itself.
    _MAX_LOG_DENSITY = 700.0

    def predict_proba(self, X):
        # BUG FIX (caught by review): computing norm = (2pi)^(-d/2) * sigma^(-d)
        # directly in linear space overflows to inf for d roughly >= 200 at
        # sigma_floor=1e-2 -- BEFORE it gets multiplied by the compensating
        # exp(-0.5*dist2/sigma^2) term, which for a typical test point at
        # that d would have rescued it to a representable ~1e276. The old
        # code produced inf (d~200-500) or nan (d~1000, from inf*0) even
        # though the true density was finite. Fixed by summing everything
        # in log-space FIRST via logsumexp, only exponentiating once at
        # the very end -- this defers overflow until the actual
        # mathematical density value exceeds float64 range, rather than
        # an artifact of evaluation order.
        dists = cdist(X, self.m, metric='sqeuclidean')
        prec = 1.0 / (self.sigma ** 2 + 1e-15)
        log_norm = -0.5 * self.d * np.log(2.0 * np.pi) - self.d * np.log(self.sigma)
        log_mu = np.log(np.clip(self.mu, 1e-300, None))
        log_density_k = log_mu[None, :] + log_norm[None, :] - 0.5 * dists * prec[None, :]
        log_density = logsumexp(log_density_k, axis=1)
        log_density = np.minimum(log_density, self._MAX_LOG_DENSITY)
        return np.exp(log_density)

    def log_likelihood(self, X):
        density = np.clip(self.predict_proba(X), 1e-300, None)
        return float(np.mean(np.log(density)))

    def sample(self, n, seed=None):
        rng = np.random.default_rng(seed)
        components = rng.choice(self.K, size=n, p=self.mu)
        X = np.zeros((n, self.d))
        for k in range(self.K):
            mask = components == k
            nk = mask.sum()
            if nk > 0:
                X[mask] = rng.normal(loc=self.m[k], scale=self.sigma[k], size=(nk, self.d))
        return X

    def __repr__(self):
        return f"GMMDimensionFree3(K={self.K}, fitted={self.m is not None})"


# ─── Self-checks ───────────────────────────────────────────────────────────────

def _check_moment_formula():
    """
    MC check of the A_kj implementation, INCLUDING the kappa-correction term.

    IMPORTANT CALIBRATION FINDING (from building this file): testing at the
    paper's own suggested working point s^2 ≍ d*sigma^2 (Section 1.3) gives
    sigma/s_o ≈ 1/sqrt(d) — e.g. d=6, sigma=0.8, s_o=2.0 gives sigma/s_o=0.4
    — and the linearised (1.12) already disagrees with the EXACT moment by
    ~38% there (verified: shrinks to <0.1% as sigma/s -> 0, confirming this
    is linearisation error, not an implementation bug). The paper's own
    prescribed scaling is NOT enough on its own to guarantee small
    linearisation error; this is flagged as an open stability question, not
    fixed here. The check below therefore uses a SMALL sigma/s ratio (deep
    in the provably-valid regime) to test CODE correctness in isolation
    from approximation accuracy.
    """
    rng = np.random.default_rng(0)
    d = 6
    m = rng.normal(size=d) * 2
    sigma = 0.05
    xi = rng.normal(size=d)
    u = rng.normal(size=d); u /= np.linalg.norm(u)
    s_j = 10.0
    s_o = 10.0
    kappa = d / (2 * s_o ** 2)
    kappa_j = kappa * (1 - s_o ** 2 / s_j ** 2)

    r = m - xi
    D = sigma ** 2 + s_j ** 2
    c_k = 0.3
    amp_exp = c_k + kappa_j * sigma ** 2
    g = 1.0 / (sigma ** 2 / s_j ** 2 + 1.0)
    E = np.exp(-np.dot(r, r) / (2 * D))
    A_closed = np.exp(amp_exp) * g * E * np.dot(r, u)

    n_mc = 3_000_000
    X = rng.normal(loc=m, scale=sigma, size=(n_mc, d))
    diff = X - xi[None, :]
    d2 = (diff ** 2).sum(1)
    kern = np.exp(-d2 / (2 * s_j ** 2))
    proj = diff @ u
    A_mc = np.exp(c_k) * (proj * kern).mean()
    rel_err = abs(A_closed - A_mc) / (abs(A_closed) + 1e-12)
    print(f"[moment-check] closed={A_closed:.6f} MC={A_mc:.6f} rel.err={rel_err:.4f}")
    assert rel_err < 0.03
    print("[moment-check] OK (code correct; see docstring re: linearisation accuracy at the paper's own suggested s^2≍d*sigma^2 working point).")


def _check_gradients():
    rng = np.random.default_rng(2)
    K, d, n, J = 3, 4, 300, 30
    X = rng.normal(size=(n, d))
    xi = X[rng.choice(n, J, replace=False)] + rng.normal(scale=0.2, size=(J, d))
    U = rng.normal(size=(J, d)); U /= np.linalg.norm(U, axis=1, keepdims=True)
    S = np.array([0.8, 1.5, 3.0])
    s_of_j = rng.choice(S, size=J)
    s_o = S.min()
    Z = empirical_moment(X, xi, U, s_of_j)

    m0 = rng.normal(size=(K, d)) * 0.4
    theta0 = _pack(rng.normal(size=(K, d)) * 0.4, np.full(K, 1.1), rng.normal(size=K) * 0.2)
    eps = 1e-6

    def num_grad_of(args, idx=None):
        idx = range(len(theta0)) if idx is None else idx
        g = np.zeros(len(idx)) if idx is not range(len(theta0)) else np.zeros_like(theta0)
        for pos, i in enumerate(idx):
            tp, tm = theta0.copy(), theta0.copy()
            tp[i] += eps; tm[i] -= eps
            lp, _ = _loss_and_grad(tp, *args)
            lm, _ = _loss_and_grad(tm, *args)
            g[pos] = (lp - lm) / (2 * eps)
        return g

    for link_mode in ('kappa', 'exact'):
        # base check (lambda_overlap=lambda_repel=0): full gradient must match exactly
        args = (K, d, xi, U, s_of_j, Z, s_o, 0.4, 0.07, m0, link_mode, 0.0, 0.0)
        loss0, grad0 = _loss_and_grad(theta0, *args)
        num_grad = num_grad_of(args)
        max_abs_err = np.max(np.abs(grad0 - num_grad))
        max_rel_err = np.max(np.abs(grad0 - num_grad) / (np.abs(num_grad) + 1e-8))
        print(f"[grad-check:{link_mode}] max abs err = {max_abs_err:.3e}, max rel err = {max_rel_err:.3e}")
        assert max_abs_err < 1e-4

        # overlap check (lambda_overlap=0.3): grad_c is INTENTIONALLY the
        # true gradient (stop-gradient design, see _loss_and_grad docstring);
        # grad_m/grad_sigma are DELIBERATELY not the true gradient of
        # total_loss w.r.t. those blocks, so we only verify the c-block here.
        args_ov = (K, d, xi, U, s_of_j, Z, s_o, 0.4, 0.07, m0, link_mode, 0.3, 0.0)
        loss_ov, grad_ov = _loss_and_grad(theta0, *args_ov)
        c_start = K * d + K
        num_grad_c = num_grad_of(args_ov, idx=range(c_start, c_start + K))
        max_abs_err_c = np.max(np.abs(grad_ov[c_start:] - num_grad_c))
        print(f"[grad-check:{link_mode}, lambda_overlap=0.3, c-block only] max abs err = {max_abs_err_c:.3e}")
        assert max_abs_err_c < 1e-4

        # repulsion check (lambda_repel=0.5): this one is NOT stop-gradient —
        # it's a genuine, full gradient of an added term, so the FULL vector
        # must match finite differences exactly.
        args_rep = (K, d, xi, U, s_of_j, Z, s_o, 0.0, 0.07, m0, link_mode, 0.0, 0.5, 1.3)
        loss_rep, grad_rep = _loss_and_grad(theta0, *args_rep)
        num_grad_rep = num_grad_of(args_rep)
        max_abs_err_rep = np.max(np.abs(grad_rep - num_grad_rep))
        print(f"[grad-check:{link_mode}, lambda_repel=0.5] max abs err = {max_abs_err_rep:.3e}")
        assert max_abs_err_rep < 1e-4
    print("[grad-check] OK: base gradients exact for both link_modes; overlap-penalty "
          "c-block exact (m/sigma blocks are an intentional stop-gradient, not the true "
          "total-loss gradient); repulsion penalty gradient exact in full.")


def _check_predict_proba_stability():
    """
    Regression guard for a real bug found by review: predict_proba used to
    compute norm = (2pi)^(-d/2) * sigma^(-d) in LINEAR space, which overflows
    to inf around d~200 at sigma_floor=1e-2 -- BEFORE the compensating
    exp(-0.5*dist2/sigma^2) term gets applied, producing inf (d~200-500) or
    nan (d~1000, from inf*0) even where the true density is finite. Fixed by
    summing in log-space (logsumexp) first, exponentiating once at the end.
    This exercises exactly the regime the fix targets: a component pinned at
    sigma_floor, evaluated at (and near) its own mean, at growing d.
    """
    for d in (100, 200, 500, 1000):
        model = GMMDimensionFree3(K=2, sigma_floor=1e-2)
        model.d, model.S_ = d, np.array([1.0, 2.0, 3.0])
        model.m = np.zeros((2, d))
        model.sigma = np.array([0.01, 1.0])
        model.c = np.array([0.0, 0.0])

        X_at_mean = np.zeros((1, d))
        rng = np.random.default_rng(0)
        X_nearby = rng.normal(scale=0.01, size=(5, d))   # near, not exactly at, the mean

        for X in (X_at_mean, X_nearby):
            p = model.predict_proba(X)
            assert np.all(np.isfinite(p)), f"non-finite predict_proba at d={d}: {p}"
            assert np.all(p > 0), f"non-positive predict_proba at d={d}: {p}"
    print("[predict_proba-stability] OK: finite and positive for d up to 1000 "
          "at sigma_floor, at and near a collapsed component's mean.")


def _check_history_resets_across_fits():
    """
    Regression guard for a real bug fixed by this merge: history_ used to
    NOT be reset at the start of fit(), so calling .fit() twice on the SAME
    model instance (e.g. multi-restart re-using one object) would silently
    ACCUMULATE history_ across calls instead of reflecting just the latest
    fit.
    """
    rng = np.random.default_rng(0)
    X = rng.normal(size=(200, 2))
    model = GMMDimensionFree3(K=2, n_outer=3, max_J=50)
    model.fit(X, seed=0)
    len_after_first = len(model.history_)
    model.fit(X, seed=1)
    len_after_second = len(model.history_)
    assert len_after_first == len_after_second == 3, (
        f"history_ did not reset: {len_after_first} then {len_after_second} (expected 3, 3)")
    print("[history-resets-across-fits] OK: history_ reflects only the most recent fit() call.")


def _check_entropy_annealing_default():
    """
    Sanity check for the merged annealing schedule: with the default
    lambda_ent_start_outer, entropy is 0 until the last outer iteration and
    ramps to full strength exactly there.
    """
    n_outer = 6
    model = GMMDimensionFree3(K=3, n_outer=n_outer, lambda_ent=0.5)
    assert model.lambda_ent_start_outer == n_outer - 1, model.lambda_ent_start_outer
    # replicate the in-fit schedule computation directly
    schedule = []
    for outer in range(n_outer):
        if outer < model.lambda_ent_start_outer:
            schedule.append(0.0)
        else:
            span = max(n_outer - model.lambda_ent_start_outer, 1)
            frac = (outer - model.lambda_ent_start_outer + 1) / span
            schedule.append(model.lambda_ent * min(frac, 1.0))
    assert schedule == [0.0, 0.0, 0.0, 0.0, 0.0, 0.5], schedule
    print(f"[entropy-annealing-default] OK: schedule across {n_outer} outer iters = {schedule}")


if __name__ == '__main__':
    _check_moment_formula()
    _check_gradients()
    _check_predict_proba_stability()
    _check_history_resets_across_fits()
    _check_entropy_annealing_default()
