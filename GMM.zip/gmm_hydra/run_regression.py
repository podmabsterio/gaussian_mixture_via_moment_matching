"""
run_regression.py — "did I break anything" baseline suite.

Runs every case in conf/regression.yaml over a fixed set of seeds,
averages the metrics, and compares against refs/regression_baseline.json.
Exit code is non-zero if any case regressed beyond its tolerance, so this
also works as a CI gate.

Each (case, seed) runs as a SEPARATE SUBPROCESS (via run.py), not in-process
via Hydra's Compose API. This was changed after a real memory issue found
on Windows: a long-lived single Python process running many fits back to
back (10 cases x 3 seeds) hit a numpy _ArrayMemoryError on a modest ~130MB
allocation, even though the exact same case in total isolation (a fresh
`python run_regression.py --cases <name>` process) passed cleanly with
identical metrics. Root cause: Windows' allocator doesn't return freed
memory to the OS as eagerly as Linux's does, so virtual-address-space
fragmentation accumulates over many large numpy allocate/free cycles within
one process. Subprocess-per-run costs ~0.1-0.3s of startup overhead per
call (negligible next to a multi-second fit) and sidesteps the problem
entirely -- the OS fully reclaims each process's memory on exit.

Usage
─────
    python run_regression.py                    # check against baseline
    python run_regression.py --update-baseline   # (re)write the baseline
    python run_regression.py --cases low_d_overlap d100_boundary
                                                  # run/check a subset only
    python run_regression.py --cases high_d_overlap --override model.max_J=100
                                                  # ad-hoc overrides for quick diagnosis
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from omegaconf import OmegaConf

BASELINE_PATH = Path("refs/regression_baseline.json")


def load_regression_spec() -> dict:
    return OmegaConf.to_container(OmegaConf.load("conf/regression.yaml"), resolve=True)


def run_case(case: dict, seeds: list[int], fit_cfg: dict, eval_cfg: dict,
             extra_overrides: list[str] = ()) -> dict:
    overrides = [f"data={case['data']}", f"model={case['model']}"]
    for k, v in case.get("overrides", {}).items():
        v_str = str(v).replace(" ", "")
        overrides.append(f"++{k}={v_str}")
    overrides += list(extra_overrides)   # applied last, so they win over case overrides

    per_seed = []
    for seed in seeds:
        tmpdir = Path(tempfile.mkdtemp(prefix="gmm_regression_"))
        try:
            run_dir = tmpdir.as_posix()   # forward slashes: safe in a Hydra override on any OS
            cmd = [sys.executable, "run.py"] + overrides + [
                f"seed={seed}",
                f"fit.maxiter_inner={fit_cfg['maxiter_inner']}",
                f"eval.n_test={eval_cfg['n_test']}",
                f"eval.n_js={eval_cfg['n_js']}",
                f"hydra.run.dir={run_dir}",
            ]
            result = subprocess.run(cmd, capture_output=True, text=True)
            metrics_path = tmpdir / "metrics.json"
            if result.returncode != 0 or not metrics_path.exists():
                raise RuntimeError(
                    f"run.py failed for case='{case['name']}' seed={seed} "
                    f"(exit code {result.returncode}):\n"
                    f"--- stderr (tail) ---\n{result.stderr[-3000:]}"
                )
            with open(metrics_path) as f:
                per_seed.append(json.load(f))
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    agg = {}
    for key in ("JS", "PD", "CRR", "WeightErr", "TestLL", "fit_time_s"):
        vals = [r[key] for r in per_seed]
        agg[key] = float(np.mean(vals))
        agg[key + "_var"] = float(np.var(vals))   # variance BETWEEN seeds, not min/max
    agg["K_active"] = float(np.mean([r["K_active"] for r in per_seed]))
    agg["n_seeds"] = len(seeds)
    return agg


def check_tolerance(metric: str, new: float, base: float, tol: dict, new_var: float = None) -> tuple[bool, str]:
    """Returns (ok, message). 'ok' False means regression detected."""
    if np.isnan(new) or np.isnan(base):
        return True, f"{metric}: NaN (skipped -- no real component was matched, e.g. total collapse)"
    var_str = f" ({new_var:.2g})" if new_var is not None else ""
    if metric in ("JS", "PD", "WeightErr"):   # lower is better
        limit = base * (1 + tol.get("rel_tol", 0.0)) + tol.get("abs_tol", 0.0)
        ok = new <= limit
        msg = f"{metric}: {new:.5f}{var_str} (baseline {base:.5f}, limit {limit:.5f})"
    elif metric == "K_active":   # symmetric: over- AND under-pruning are bad
        limit = tol.get("abs_tol", 1.0)
        ok = abs(new - base) <= limit
        msg = f"{metric}: {new:.2f} (baseline {base:.2f}, +/-{limit})"
    else:                          # CRR, TestLL: higher is better
        limit = base - tol.get("abs_tol", 0.0)
        ok = new >= limit
        msg = f"{metric}: {new:.5f}{var_str} (baseline {base:.5f}, limit {limit:.5f})"
    return ok, msg


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--update-baseline", action="store_true",
                         help="overwrite refs/regression_baseline.json with current results")
    parser.add_argument("--cases", nargs="+", default=None,
                         help="run/check only these case names (default: all)")
    parser.add_argument("--override", nargs="+", default=[],
                         help="extra Hydra overrides applied to every case run this "
                              "invocation, e.g. --override model.max_J=100 model.n_outer=3 "
                              "-- handy for quick diagnosis without editing conf/regression.yaml")
    args = parser.parse_args()

    spec = load_regression_spec()
    seeds = spec["seeds"]
    fit_cfg, eval_cfg, tolerances = spec["fit"], spec["eval"], spec["tolerances"]
    cases = spec["cases"]
    if args.cases:
        cases = [c for c in cases if c["name"] in args.cases]
        missing = set(args.cases) - {c["name"] for c in cases}
        if missing:
            sys.exit(f"Unknown case name(s): {missing}")

    results = {}
    for case in cases:
        print(f"[running] {case['name']} ({case['data']} / {case['model']}, "
              f"seeds={seeds}) ...", flush=True)
        results[case["name"]] = run_case(case, seeds, fit_cfg, eval_cfg, args.override)

    if args.update_baseline:
        # BUG FIX (caught in the act, running --cases subsets sequentially):
        # this used to overwrite the ENTIRE baseline file with only the
        # cases just run, silently wiping out every other case's baseline
        # if --cases restricted the run to a subset. Now merges into
        # whatever's already on disk instead.
        existing = {}
        if BASELINE_PATH.exists():
            with open(BASELINE_PATH) as f:
                existing = json.load(f)
        existing.update(results)
        BASELINE_PATH.parent.mkdir(exist_ok=True)
        with open(BASELINE_PATH, "w") as f:
            json.dump(existing, f, indent=2)
        print(f"\n[baseline written] {BASELINE_PATH} ({len(results)} case(s) updated, "
              f"{len(existing)} total)")
        return

    if not BASELINE_PATH.exists():
        sys.exit(f"No baseline at {BASELINE_PATH} yet. Run with --update-baseline first.")
    with open(BASELINE_PATH) as f:
        baseline = json.load(f)

    print(f"\n{'CASE':<28} {'STATUS':<8} DETAILS")
    print("-" * 100)
    any_fail = False
    for name, new in results.items():
        if name not in baseline:
            print(f"{name:<28} {'NEW':<8} no baseline entry — run --update-baseline to add it")
            continue
        base = baseline[name]
        case_ok = True
        details = []
        for metric in ("JS", "PD", "CRR", "WeightErr", "TestLL", "K_active"):
            new_var = new.get(f"{metric}_var")   # None for K_active, which has no _var
            ok, msg = check_tolerance(metric, new[metric], base[metric], tolerances[metric], new_var)
            case_ok &= ok
            details.append(msg if ok else f"**{msg} REGRESSED**")
        status = "PASS" if case_ok else "FAIL"
        any_fail |= not case_ok
        print(f"{name:<28} {status:<8} " + " | ".join(details))

    print("-" * 100)
    if any_fail:
        print("REGRESSION DETECTED — see FAIL rows above.")
        sys.exit(1)
    print("All cases within tolerance.")


if __name__ == "__main__":
    main()
