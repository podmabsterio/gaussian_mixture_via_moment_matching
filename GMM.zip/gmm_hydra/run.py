"""
run.py — Hydra entry point for GMMDimensionFree3 experiments.

Replaces the hand-rolled nested loops in exp_n_outer_ablation.py with
Hydra config groups + multirun.

Examples
────────
Single run, defaults (model=kappa, data=R100_2comp):
    python run.py

Switch model variant / a couple of hyperparameters:
    python run.py model=exact model.n_outer=10 model.lambda_ent=0.1

Reproduce exp_n_outer_ablation.py's sweep (d in {5,20,50,100} x
n_outer in {4,6,8,10,12,16}, 6 seeds) as a single Hydra multirun,
results land one JSON per run under multirun/<date>/<time>/<overrides>/:
    python run.py -m \\
        data=dsweep_d5,dsweep_d20,dsweep_d50,dsweep_d100 \\
        model=exact \\
        model.n_outer=4,6,8,10,12,16 \\
        seed=0,1,2,3,4,5

Quick smoke test:
    python run.py model=exact_fast data=2d_3comp
"""
from __future__ import annotations

import sys

# ── Python 3.14 compat shim ──────────────────────────────────────────────
# hydra-core 1.3.4 (latest PyPI release as of writing) crashes on Python
# 3.14+ with:
#   TypeError: argument of type 'LazyCompletionHelp' is not a container
#   ValueError: badly formed help string
# Cause: Python 3.14 added stricter argparse help-string validation
# (ArgumentParser._check_help) that assumes `help=` is always a plain
# string; Hydra's --shell-completion flag uses a lazy help object instead.
# This is a known upstream bug (facebookresearch/hydra#3121) already fixed
# on Hydra's main branch (they disable the check right before registering
# that one flag) but not yet in a PyPI release. Same fix, applied here so
# this doesn't require the person running it to build Hydra from source.
# Safe to remove once hydra-core ships a release containing the upstream
# fix -- check https://github.com/facebookresearch/hydra/issues/3121.
if sys.version_info >= (3, 14):
    import argparse
    argparse.ArgumentParser._check_help = lambda self, action: None  # type: ignore[method-assign]

import json

import hydra
from omegaconf import DictConfig, OmegaConf

from pipeline import fit_and_evaluate


@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig) -> float:
    print(OmegaConf.to_yaml(cfg))

    metrics = fit_and_evaluate(cfg)

    print(json.dumps(metrics, indent=2))
    with open("metrics.json", "w") as f:   # lands in Hydra's per-run output dir
        json.dump(metrics, f, indent=2)

    # return value usable as an Optuna/Ax sweeper objective later if wanted
    return metrics["JS"]


if __name__ == "__main__":
    main()
