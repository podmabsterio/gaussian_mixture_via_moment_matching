# GMM Dimension-Free — Hydra harness

Hydra-based experiment harness for `model_df3.py` (the dimension-free GMM
estimator, Sections 1.2-1.4 of Spokoiny's paper), plus a synthetic-data
generator (`data.py`) covering isotropic and §2.3-anisotropic ground truth.

## Documentation (`docs/`)

| File | Contents |
|---|---|
| `docs/01_ENGINEERING_DECISIONS.md` | Every bug found/fixed and design decision made, by file |
| `docs/02_OPEN_PROBLEMS.md` | Unsolved problems, current hypotheses, and which tests touch each |
| `docs/03_RESULTS_REPORT.md` | Results report slice — what's confirmed vs. pending re-run |

## Files

| File | Purpose |
|---|---|
| `model_df3.py` | The estimator itself (`GMMDimensionFree3`). Self-checks: `python model_df3.py` |
| `model_sklearn.py` | Classic EM baseline (`sklearn.mixture.GaussianMixture`), wrapped to the same interface for direct comparison. Self-checks: `python model_sklearn.py` |
| `data.py` | Synthetic GMM data generation, entry point `make_gmm_data`. Self-checks: `python data.py` |
| `metrics.py` | `TestLL`/`JS`/`PD`/`CRR` evaluation. Self-checks: `python metrics.py` |
| `pipeline.py` | `fit_and_evaluate(cfg)` — the actual data→fit→eval logic, shared by `run.py` and `run_regression.py` |
| `run.py` | Hydra CLI entry point: single runs and multirun sweeps |
| `run_regression.py` | "did I break anything" baseline suite (10 curated cases vs. `refs/regression_baseline.json`) |
| `collect_results.py` | Aggregates a multirun sweep dir into a summary table |
| `conf/` | Hydra configs: `model/`, `data/`, `battery/` (pre-built multirun grids), `regression.yaml` |

## Quickstart

```bash
pip install hydra-core pandas

# sanity check: did I break anything?
python run_regression.py

# single run
python run.py model=exact data=2d_3comp seed=0

# multirun sweep
python run.py -m data=dsweep_d5,dsweep_d20 model.n_outer=4,6,8 seed=0,1,2

# pre-built battery (one flag = whole grid)
python run.py --multirun +battery=n_outer_ablation
python collect_results.py multirun/<date>/<time> --group_by d n_outer
```

## Data generation (`data.py`)

`make_gmm_data(K, d, n, ...)` returns `(X, true_params)` in one call.

- **`separation_sigma_units_range=(lo, hi)`**: separation between
  neighbouring centres, in multiples of `max(sigma_range)`, drawn
  independently **per pair**. This is d-INDEPENDENT by construction — the
  realized `separation/sigma` ratio does not depend on `d` (verified by
  self-check across d=2..100). Do not confuse this with the `s >~
  sigma*sqrt(d)` bandwidth requirement from Conjecture 2 — that's a
  different quantity (the method's own test-kernel bandwidth vs sigma, not
  separation between true components).
- **`weight_ratio`**: ratio of the largest to smallest true mixture weight.
  Default `1.0` = uniform (unchanged default behaviour).
- **`M` / `nu_ratio_range`**: the §2.3 anisotropic structure,
  `V_k² = σ_k²·Π + ν_k²·(Id-Π)`, with a shared random M-dimensional
  subspace Π across all components. `M=None` (default) = isotropic.

## `model_df3.py` — merged mechanisms

Merged in from a parallel development branch (2026-07-26):

- **`lambda_ent_start_outer`** (entropy-penalty annealing): by default,
  entropy is 0 until the LAST outer iteration, then ramps to full
  strength. **This substantially softens the weight-collapse cliff found
  in Experiment D** — with a constant `lambda_ent` from `outer=0`, `K=8`
  vs `K_true=3` jumped straight from no pruning (`lambda_ent=0.0`) to
  total collapse (`lambda_ent=0.02`, `K_active=1`) with no usable window
  in between. With annealing, there's now a real graceful-pruning window
  (`lambda_ent≈0.008-0.015` lands exactly on `K_active=3=K_true`,
  `CRR≈0.67`), and full collapse only starts around `lambda_ent≈0.1` — a
  5x wider, actually usable range. The `weight_collapse`/`weight_collapse_fine`
  batteries should be re-run under this to see the new (much less
  pathological) picture.
- **`sigma_ceil`**: optional upper bound on sigma, guards against a
  component "dying" by inflating sigma to near-zero density instead of
  shrinking its weight. `None` (default) = unbounded, unchanged behaviour.
- **`lambda_overlap` / `lambda_repel`**: experimental alternative
  identifiability penalties (Bhattacharyya-coefficient overlap, geometric
  repulsion). Both documented as NOT fully solving component-pruning on
  their own (symmetry-breaking / doesn't reliably work respectively) —
  kept available (default `0.0`, off) for reference, gradient-checked.
- **`init_m`/`init_sigma`**: optional overrides bypassing KMeans
  initialization, for robustness-to-bad-starting-point experiments.

Deferred on purpose (per explicit request): Section 2.2's effective
dimension `M` for anisotropic amplitude correction — planned as a
separate follow-up once this isotropic merge is confirmed solid.

## Model config groups (`conf/model/`)

`kappa` (paper's linearised default, eq. 1.12), `exact` (no linearisation),
`exact_fast` (cheap smoke-test variant), `sklearn_em` (classic EM,
spherical covariance -- the fair, same-assumptions comparison point),
`sklearn_em_full` (full covariance -- the correctly-specified comparison
point for anisotropic ground truth, `data=aniso_d20_M5`). `model.K`
defaults to `null` (matches the data's true K) — set explicitly
(`model.K=8`) to test over-specification / entropy-penalty pruning.

```bash
python run.py model=sklearn_em data=2d_3comp seed=0
python run.py --multirun +battery=vs_sklearn   # head-to-head, 72 jobs
```

Note: `CRR`/`PD` assume isotropic ground truth for parameter matching --
they're not well-suited for judging `sklearn_em_full`'s recovery quality
on anisotropic data (a correct full-covariance fit still gets `CRR≈0`
there, because its true covariance isn't reducible to a single sigma).
Read `JS`/`TestLL` for that comparison, not `CRR`/`PD`.

## Batteries (`conf/battery/`)

| Preset | Tests |
|---|---|
| `n_outer_ablation` | How many outer iterations are actually needed, across `d` |
| `separation` | **NEW** — clean separation-only identifiability curve (CRR/JS/WeightErr vs `separation_sigma_units`), safe fixed bandwidth, across `d` |
| `bandwidth_calibration` | **NEW** — optimality of Spokoiny's N1/N2/N3 scale calibration: fine `bandwidth_mult` sweep around 1.0 at well-specified K |
| `weight_recovery` | **NEW** — consistency of weight recovery under genuine weight imbalance (`weight_ratio` sweep), measured via `WeightErr` |
| `separation_bandwidth` / `_extended` | Experiment B: separation × bandwidth_mult phase diagram |
| `weight_collapse` / `_fine` | Experiment D: entropy-penalty weight-collapse threshold (fine grid recalibrated for the post-annealing-merge dynamics) |
| `vs_sklearn` | Head-to-head: our method (both link_modes) vs classic EM, across `d` |

## Metrics (`metrics.py`)

`TestLL` / `JS` / `PD` / `CRR` / **`WeightErr`** (new) / `K_active`.
`WeightErr` isolates PURE weight-recovery quality (mean abs error over
matched pairs) — unlike `PD`, which bundles position + sigma + weight
error into one scalar, and unlike `CRR`'s weight check (pass/fail only,
not magnitude). Directly answers whether the simplex → free-parameter
`c` reparametrisation, and the `(1+σ²/s_o²)^(d/2)` correction back to
`mu`, distorts recovered class proportions.

Run with `python run.py --multirun +battery=<name>`.

## Known open questions (for Spokoiny)

- Weight collapse under entropy regularisation is a sharp, seed-dependent
  cliff (not a smooth function of `lambda_ent`), and may not be orthogonal
  to bandwidth violations (`separation_bandwidth` shows degradation even
  at `lambda_ent=0`).
- `CRR`/`PD` are strict, one-to-one-matching metrics: they read as "bad"
  under `K > K_true` even when the density fit (`JS`/`TestLL`) is fine,
  because excess components split real mass across several small
  estimates that individually fail matching tolerances. Read `JS`/`TestLL`
  alongside `CRR`/`PD`, not `CRR`/`PD` alone, when `model.K != K_true`.
