"""
pipeline.py — the actual "build data -> fit model -> evaluate" logic,
factored out of run.py so run_regression.py can reuse it without going
through the Hydra CLI/multirun machinery.

Rewritten for the new data.py API: cfg.data.gmm now instantiates
data.make_gmm_data directly, which does data generation AND sampling in
one call, returning (X, true_params) -- no separate sample_gmm/n_samples
step needed anymore.
"""
from __future__ import annotations

import time

import hydra
from omegaconf import DictConfig, OmegaConf

from data import make_true_fns
from metrics import evaluate_all_metrics


def fit_and_evaluate(cfg: DictConfig) -> dict:
    X, true_params = hydra.utils.instantiate(cfg.data.gmm, seed=cfg.seed)
    true_sample_fn, true_predict_fn = make_true_fns(true_params, seed_offset=cfg.seed)

    # model.K defaults to null (= match the data's true K); explicit
    # model.K=N overrides this to test over-specification (see the
    # earlier pipeline fix: K used to be unconditionally forced to K_true,
    # which made testing entropy-penalty pruning impossible).
    model_cfg = OmegaConf.to_container(cfg.model, resolve=True)
    if model_cfg.get("K") is None:
        model_cfg["K"] = true_params["K"]
    model = hydra.utils.instantiate(model_cfg)

    t0 = time.time()
    model.fit(X, maxiter_inner=cfg.fit.maxiter_inner, seed=cfg.seed)
    fit_time = time.time() - t0

    metrics = evaluate_all_metrics(
        model,
        true_params={"mu": true_params["mu"], "m": true_params["m"], "sigma": true_params["sigma"]},
        true_sample_fn=true_sample_fn,
        true_predict_fn=true_predict_fn,
        n_test=cfg.eval.n_test,
        n_js=cfg.eval.n_js,
        seed=cfg.seed,
    )
    metrics["fit_time_s"] = fit_time
    metrics["d"] = true_params["d"]
    metrics["K_true"] = true_params["K"]
    metrics["anisotropic"] = true_params["M"] is not None
    metrics["link_mode"] = cfg.model.get("link_mode", "n/a")
    metrics["n_outer"] = cfg.model.get("n_outer", None)   # not every model has this concept (e.g. sklearn EM)
    metrics["seed"] = cfg.seed
    return metrics
