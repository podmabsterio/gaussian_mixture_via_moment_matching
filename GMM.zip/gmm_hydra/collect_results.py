"""
collect_results.py — aggregate a Hydra multirun sweep into the same
summary table exp_n_outer_ablation.py used to print by hand (mean/var of
sigma/mu/JS error per (d, n_outer), grouped over seeds), but generically
for ANY multirun directory and ANY group-by keys.

Usage
─────
Point it at the sweep dir Hydra printed at the top of the run
("Launching N jobs locally" / multirun.dir):

    python collect_results.py multirun/2026-07-23/01-02-19

Custom grouping -- any key from metrics.json (d, n_outer, link_mode, seed,
...) OR any swept Hydra override recovered from the job directory name
(bandwidth_mult, lambda_ent, separation, n_samples, K, data, model, ...):

    python collect_results.py multirun/.../separation_bandwidth_run --group_by separation bandwidth_mult
    python collect_results.py multirun/.../weight_collapse_run --group_by lambda_ent n_samples

Inspect per-seed detail for specific parameter values (e.g. to check
whether a bad mean hides 1-2 catastrophic seeds among otherwise-fine ones):
    python collect_results.py multirun/.../separation_bandwidth_extended_run \\
        --filter separation=10.0 bandwidth_mult=2.0 --show_raw

Dump the raw per-job table too (useful for finding specific outlier jobs,
e.g. by fit_time_s):
    python collect_results.py multirun/2026-07-23/01-02-19 --raw_csv raw.csv
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd


def _try_parse_scalar(s: str):
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s


def parse_job_dir(name: str) -> dict:
    """
    Recover swept hyperparameters from a Hydra multirun job directory name,
    e.g. 'data=dsweep_d20,model.bandwidth_mult=4.0,model.lambda_ent=0.3_seed5'
    -> {'data': 'dsweep_d20', 'model.bandwidth_mult': 4.0,
        'bandwidth_mult': 4.0, 'model.lambda_ent': 0.3, 'lambda_ent': 0.3,
        'seed_from_dirname': 5}.

    This exists because metrics.json only ever stores a fixed subset of
    fields (d, n_outer, link_mode, seed) -- any OTHER swept parameter
    (separation, bandwidth_mult, lambda_ent, n_samples, K, ...) only shows
    up in the directory name, via conf/config.yaml's
    hydra.sweep.subdir = ${hydra.job.override_dirname}_seed${seed}.
    Both the fully-qualified key (model.lambda_ent) and a short alias
    (lambda_ent) are added, so --group_by lambda_ent works without needing
    to know which config group it lives under.

    Caveat: assumes no override VALUE itself contains a comma. True for
    every battery/preset shipped here (separation, bandwidth_mult,
    lambda_ent, n_samples, K are all scalars) -- would break for a raw
    list-valued override (e.g. sigma_range=[0.5,2.5]) swept directly via
    Hydra multirun, which none of the shipped presets do.
    """
    m = re.search(r"_seed(\d+)$", name)
    body = name[: m.start()] if m else name
    out = {"seed_from_dirname": int(m.group(1))} if m else {}

    for token in body.split(","):
        if "=" not in token:
            continue
        key, _, val = token.partition("=")
        key = key.lstrip("+")   # +battery=name -> battery
        parsed = _try_parse_scalar(val)
        out[key] = parsed
        if "." in key:
            out.setdefault(key.rsplit(".", 1)[-1], parsed)
    return out


def load_multirun(sweep_dir: Path) -> pd.DataFrame:
    rows = []
    for metrics_file in sorted(sweep_dir.glob("*/metrics.json")):
        with open(metrics_file) as f:
            row = json.load(f)
        parsed = parse_job_dir(metrics_file.parent.name)
        parsed.update(row)   # metrics.json wins on any key collision
        parsed["_job_dir"] = metrics_file.parent.name
        rows.append(parsed)
    if not rows:
        raise FileNotFoundError(
            f"No metrics.json found under {sweep_dir}/*/. "
            f"Did you point this at the multirun sweep dir (the one "
            f"containing 'multirun.yaml' and one subfolder per job)?"
        )
    return pd.DataFrame(rows)


def summarize(df: pd.DataFrame, group_by: list[str], success_threshold: float | None = None) -> pd.DataFrame:
    """
    One column per metric, formatted as "mean (var)" -- mean across the
    matching jobs (usually seeds) and variance BETWEEN those jobs, not
    mean/min/max. Variance (not std) because that's what was asked for;
    note it's in squared units of the metric, so e.g. a JS varying by
    ~0.03 typically shows a var around ~0.001 -- expected, not a bug.

    success_threshold: if given, ALSO reports success_rate = fraction of
    seeds with CRR >= threshold. Use this for boundary/threshold-finding
    experiments -- mean(CRR) is misleading there, since failures tend to
    be bimodal (a seed either finds a good solution or collapses badly,
    not a smooth gradient), so the mean gets dragged around by a couple
    of catastrophic seeds rather than reflecting "how often does this
    configuration work".
    """
    missing = [g for g in group_by if g not in df.columns]
    if missing:
        raise KeyError(f"group_by key(s) {missing} not found; "
                        f"available keys: {list(df.columns)}")

    metric_cols = [c for c in ("JS", "PD", "CRR", "WeightErr", "TestLL", "fit_time_s") if c in df.columns]
    agg = {col: ["mean", "var"] for col in metric_cols}
    stats = df.groupby(group_by).agg(agg)
    stats.columns = ["_".join(c) for c in stats.columns]

    out = stats[[]].copy()   # empty frame with the right (grouped) index
    for col in metric_cols:
        mean, var = stats[f"{col}_mean"], stats[f"{col}_var"].fillna(0.0)
        out[col] = [f"{m:.4g} ({v:.2g})" for m, v in zip(mean, var)]
    if success_threshold is not None and "CRR" in df.columns:
        rate = df.groupby(group_by)["CRR"].apply(lambda s: (s >= success_threshold).mean())
        out["success_rate"] = [f"{r:.2f}" for r in rate]
    out["n_seeds"] = df.groupby(group_by).size()
    return out.reset_index()


def report_slow_outliers(df: pd.DataFrame, factor: float = 10.0) -> None:
    if "fit_time_s" not in df.columns or len(df) < 3:
        return
    med = df["fit_time_s"].median()
    outliers = df[df["fit_time_s"] > med * factor].sort_values("fit_time_s", ascending=False)
    if outliers.empty:
        return
    print(f"\n[!] {len(outliers)} job(s) with fit_time_s > {factor}x the median ({med:.2f}s) -- "
          f"likely a stuck/runaway optimizer, not just slow:")
    cols = [c for c in ("_job_dir", "fit_time_s", "d", "link_mode") if c in outliers.columns]
    print(outliers[cols].head(10).to_string(index=False))


def apply_filter(df: pd.DataFrame, filters: list[str]) -> pd.DataFrame:
    out = df
    for token in filters:
        if "=" not in token:
            raise ValueError(f"--filter entries must look like key=value, got: {token!r}")
        key, _, val = token.partition("=")
        if key not in out.columns:
            raise KeyError(f"--filter key {key!r} not found; available keys: {list(out.columns)}")
        target = _try_parse_scalar(val)
        col = out[key]
        if pd.api.types.is_numeric_dtype(col) and isinstance(target, (int, float)):
            out = out[np.isclose(col, target)]
        else:
            out = out[col.astype(str) == str(target)]
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("sweep_dir", type=Path,
                         help="Hydra multirun sweep dir, e.g. multirun/2026-07-23/01-02-19")
    parser.add_argument("--group_by", nargs="+", default=["d", "n_outer", "link_mode"],
                         help="metrics.json keys to group over (default: d n_outer link_mode)")
    parser.add_argument("--raw_csv", type=Path, default=None,
                         help="optional path to also dump the raw per-job table")
    parser.add_argument("--filter", nargs="+", default=None,
                         help="key=value pairs to filter rows before summarizing/showing raw, "
                              "e.g. --filter separation=10.0 bandwidth_mult=2.0")
    parser.add_argument("--show_raw", action="store_true",
                         help="print the (optionally filtered) per-job rows instead of the "
                              "grouped summary -- use with --filter to inspect individual seeds")
    parser.add_argument("--success_threshold", type=float, default=None,
                         help="report success_rate = fraction of seeds with CRR >= this value. "
                              "Use for boundary-finding experiments, where mean(CRR) is misleading "
                              "due to bimodal (not gradual) seed-level failures.")
    args = parser.parse_args()

    df = load_multirun(args.sweep_dir)
    if args.raw_csv:
        df.to_csv(args.raw_csv, index=False)
        print(f"[raw] {len(df)} jobs -> {args.raw_csv}")

    if args.filter:
        df = apply_filter(df, args.filter)
        print(f"[filter] {len(df)} job(s) matched {args.filter}\n")

    report_slow_outliers(df)

    pd.set_option("display.width", 160)
    pd.set_option("display.precision", 4)

    if args.show_raw:
        cols = [c for c in ("_job_dir", "seed", "JS", "PD", "CRR", "WeightErr", "TestLL", "K_active",
                             "fit_time_s") if c in df.columns]
        print(df[cols].sort_values("seed" if "seed" in df.columns else cols[0])
              .to_string(index=False))
        return

    summary = summarize(df, args.group_by, args.success_threshold)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
