"""
experiment_regime_search.py — search (d, contamination_scale,
contamination_fraction, K_mode) for the regime where DF's advantage over
sklearn / sklearn_full is genuine and CONSISTENT across seeds, rather than
picking one favorable-looking point.

IMPORTANT — how this is meant to be used
─────────────────────────────────────────
This is a SEARCH tool, not a results generator. It runs a coarse,
reduced-fidelity grid (fewer DF outer iterations, sklearn n_init=1, small
n_test/n_js — for speed) across many (d, scale, contamination_fraction,
K_mode) combinations, and ranks each combination by `min_win_rate`: the
worse of (fraction of seeds where DF beats sklearn) and (fraction of seeds
where DF beats sklearn_full). A combination only ranks well if DF wins
CONSISTENTLY against both, not on 1-2 lucky seeds.

Two-phase use:
  1. `--phase search`  -- coarse grid, few seeds, fast. Gives you a ranked
     table of candidate regimes.
  2. `--phase confirm` -- pick your top 2-3 candidates from that table and
     re-run THEM ONLY at full fidelity with more seeds (>=10) before
     reporting anything.

This mirrors what victory_contamination.yaml's own comments already
document: the first "victory" config (uniform contamination, scale=20) was
checked on a full 10-seed grid and turned out to be a narrow, weak effect
that didn't hold up; the real effect (gaussian, scale=3-5) was found by
widening the search and re-checking on the FULL grid, not by keeping a
3-seed spot check that happened to look good. When you write this up,
report the search itself (including regimes that did NOT show an effect),
not just the winning point — a regime picked by scanning many
configurations and keeping the best-looking one needs that context, or the
"win" is really just favorable sampling noise dressed up as a result.

Run
───
    python experiment_regime_search.py --phase search
    python experiment_regime_search.py --phase confirm --d 20 --scale 3.0 --frac 0.1 --k_mode K+1 --seeds 10
"""
from __future__ import annotations

import argparse
import itertools
import time

import numpy as np
import pandas as pd

from data import make_gmm_data, make_true_fns
from metrics import evaluate_all_metrics
from model_df3 import GMMDimensionFree3
from model_sklearn import SklearnGMMBaseline

K_TRUE = 3
N = 2000
SEP_RANGE = (3.0, 5.0)
SIGMA_RANGE = (0.5, 2.0)

# ─── search grid (coarse, phase='search') ──────────────────────────────────
D_VALUES = [5, 20, 50]
SCALE_VALUES = [2.0, 3.0, 5.0, 8.0]
FRACTION_VALUES = [0.05, 0.10, 0.15]
K_MODES = ['K', 'K+1']
SEEDS_SEARCH = list(range(6))

# reduced-fidelity settings for the search phase (speed, not for reporting)
DF_KWARGS_FAST = dict(p0=1.0, max_J=200, lambda_ent=0.0, lambda_m_init=1.0,
                       lambda_m_decay=0.5, sigma_floor=0.01, n_outer=4,
                       resample=True, link_mode='exact', bandwidth_mult=1.0)
MAXITER_INNER_FAST = 150
N_TEST_FAST, N_JS_FAST = 800, 1500

# full-fidelity settings for the confirm phase (matches conf/model/exact.yaml
# and conf/config.yaml's eval defaults — use these numbers when reporting)
DF_KWARGS_FULL = dict(p0=1.0, max_J=400, lambda_ent=0.0, lambda_m_init=1.0,
                       lambda_m_decay=0.5, sigma_floor=0.01, n_outer=6,
                       resample=True, link_mode='exact', bandwidth_mult=1.0)
MAXITER_INNER_FULL = 300
N_TEST_FULL, N_JS_FULL = 5000, 10000


def run_config(d, scale, frac, k_mode, seeds, df_kwargs, maxiter_inner, n_test, n_js):
    k = K_TRUE if k_mode == 'K' else K_TRUE + 1
    rows = []
    for seed in seeds:
        X, true_params = make_gmm_data(
            K=K_TRUE, d=d, n=N,
            separation_sigma_units_range=SEP_RANGE, sigma_range=SIGMA_RANGE,
            weight_ratio=1.0, M=None,
            contamination_fraction=frac, contamination_scale=scale,
            contamination_type='gaussian', seed=seed,
        )
        true_sample_fn, true_predict_fn = make_true_fns(true_params, seed_offset=seed)
        true_p = {'mu': true_params['mu'], 'm': true_params['m'], 'sigma': true_params['sigma']}

        models = {
            'DF': GMMDimensionFree3(K=k, **df_kwargs),
            'sklearn': SklearnGMMBaseline(K=k, covariance_type='spherical', n_init=1),
            'sklearn_full': SklearnGMMBaseline(K=k, covariance_type='full', n_init=1),
        }
        js = {}
        for name, model in models.items():
            try:
                model.fit(X, maxiter_inner=maxiter_inner, seed=seed)
                m = evaluate_all_metrics(model, true_p, true_sample_fn, true_predict_fn,
                                          n_test=n_test, n_js=n_js, seed=seed)
                js[name] = m['JS']
            except Exception:
                js[name] = np.nan
        rows.append(dict(d=d, scale=scale, frac=frac, k_mode=k_mode, seed=seed, **js))
    return rows


def search(d_values, scale_values, frac_values, k_modes, seeds,
           df_kwargs, maxiter_inner, n_test, n_js, verbose=True):
    all_rows = []
    configs = list(itertools.product(d_values, scale_values, frac_values, k_modes))
    for i, (d, scale, frac, k_mode) in enumerate(configs):
        t0 = time.time()
        rows = run_config(d, scale, frac, k_mode, seeds, df_kwargs, maxiter_inner, n_test, n_js)
        all_rows.extend(rows)
        if verbose:
            print(f"[{i + 1}/{len(configs)}] d={d} scale={scale} frac={frac} "
                  f"k_mode={k_mode}  ({time.time() - t0:.1f}s)")
    return pd.DataFrame(all_rows)


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    """
    Paired-by-seed comparison of DF vs sklearn / sklearn_full, per
    (d, scale, frac, k_mode). `win_rate_vs_X` = fraction of seeds where DF's
    JS < X's JS (lower JS = better fit). `mean_effect_vs_X` = mean(X's JS -
    DF's JS) (positive = DF better on average). Ranked by `min_win_rate`, the
    WORSE of the two win rates -- a config only ranks well if DF is
    consistently ahead of BOTH baselines, not just one.
    """
    out = []
    for keys, g in df.groupby(['d', 'scale', 'frac', 'k_mode']):
        d, scale, frac, k_mode = keys
        row = dict(d=d, scale=scale, frac=frac, k_mode=k_mode, n_seeds=len(g))
        for comp in ['sklearn', 'sklearn_full']:
            diff = g[comp] - g['DF']
            row[f'win_rate_vs_{comp}'] = float((diff > 0).mean())
            row[f'mean_effect_vs_{comp}'] = float(diff.mean())
            row[f'effect_std_vs_{comp}'] = float(diff.std())
        out.append(row)
    summary = pd.DataFrame(out)
    summary['min_win_rate'] = summary[['win_rate_vs_sklearn', 'win_rate_vs_sklearn_full']].min(axis=1)
    return summary.sort_values('min_win_rate', ascending=False)


def summarize_k_vs_kplus1(df: pd.DataFrame) -> pd.DataFrame:
    """
    Direct test of the "K+1 erases DF's advantage" hypothesis: for each
    (d, scale, frac), compare the DF-vs-baseline effect at k_mode='K'
    against the same effect at k_mode='K+1'. A large positive
    `advantage_drop_vs_X` means the DF edge over baseline X shrinks (or
    reverses) once every model gets an extra slot -- i.e. the hypothesis
    holds for that configuration.
    """
    piv = summarize(df).set_index(['d', 'scale', 'frac', 'k_mode'])
    rows = []
    for (d, scale, frac), _ in piv.groupby(level=['d', 'scale', 'frac']):
        try:
            k_row = piv.loc[(d, scale, frac, 'K')]
            k1_row = piv.loc[(d, scale, frac, 'K+1')]
        except KeyError:
            continue   # one of the two modes wasn't run for this config
        row = dict(d=d, scale=scale, frac=frac)
        for comp in ['sklearn', 'sklearn_full']:
            eff_k = k_row[f'mean_effect_vs_{comp}']
            eff_k1 = k1_row[f'mean_effect_vs_{comp}']
            row[f'effect_at_K_vs_{comp}'] = eff_k
            row[f'effect_at_Kplus1_vs_{comp}'] = eff_k1
            row[f'advantage_drop_vs_{comp}'] = eff_k - eff_k1   # positive = advantage shrinks at K+1
        rows.append(row)
    out = pd.DataFrame(rows)
    out['min_advantage_drop'] = out[['advantage_drop_vs_sklearn', 'advantage_drop_vs_sklearn_full']].min(axis=1)
    return out.sort_values('min_advantage_drop', ascending=False)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase', choices=['search', 'confirm'], default='search')
    p.add_argument('--d', type=int, nargs='*')
    p.add_argument('--scale', type=float, nargs='*')
    p.add_argument('--frac', type=float, nargs='*')
    p.add_argument('--k_mode', nargs='*', choices=['K', 'K+1'])
    p.add_argument('--seeds', type=int, default=None)
    p.add_argument('--k_vs_kplus1', action='store_true',
                    help='also print the direct "does K+1 erase DF\'s advantage" comparison '
                         '(requires both K and K+1 to have been run for each config)')
    args = p.parse_args()

    if args.phase == 'search':
        seeds = list(range(args.seeds)) if args.seeds else SEEDS_SEARCH
        df = search(D_VALUES, SCALE_VALUES, FRACTION_VALUES, K_MODES, seeds,
                    DF_KWARGS_FAST, MAXITER_INNER_FAST, N_TEST_FAST, N_JS_FAST)
        df.to_csv('regime_search_raw.csv', index=False)
        summary = summarize(df)
        summary.to_csv('regime_search_summary.csv', index=False)
        print("\nTop candidates (fast search, few seeds — CONFIRM before reporting):")
        print(summary.head(15).to_string(index=False))
    else:
        d_values = args.d or D_VALUES
        scale_values = args.scale or SCALE_VALUES
        frac_values = args.frac or FRACTION_VALUES
        k_modes = args.k_mode or K_MODES
        seeds = list(range(args.seeds or 10))
        df = search(d_values, scale_values, frac_values, k_modes, seeds,
                    DF_KWARGS_FULL, MAXITER_INNER_FULL, N_TEST_FULL, N_JS_FULL)
        df.to_csv('regime_confirm_raw.csv', index=False)
        summary = summarize(df)
        summary.to_csv('regime_confirm_summary.csv', index=False)
        print("\nConfirmed (full fidelity):")
        print(summary.to_string(index=False))

    if args.k_vs_kplus1:
        kvk1 = summarize_k_vs_kplus1(df)
        kvk1.to_csv(f'{args.phase}_K_vs_Kplus1.csv', index=False)
        print("\nDoes K+1 erase DF's advantage? (positive = yes, advantage shrinks at K+1):")
        print(kvk1.to_string(index=False))


if __name__ == '__main__':
    main()