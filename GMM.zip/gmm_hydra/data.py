"""
data.py  —  Synthetic data generation for Gaussian mixture models.

Public API
──────────
``density_gmm``       Evaluate the true density at given points (isotropic
                       or the §2.3 anisotropic manifold structure).
``sample_gmm``        Draw n points from a given GMM (same two structures).
``make_gmm_data``      THE entry point: K, d, n -> (X, true_params). Handles
                       weights, separation, sigma, and optionally the §2.3
                       anisotropic structure in one call.
``make_gmm_params_grid`` Centres on a regular grid (d = 1 or 2 only) --
                       deterministic, independent utility, unrelated to the
                       random generator below.
``make_true_fns``      Closures (sample_fn, predict_fn) from a true_params
                       dict, for repeated fresh sampling during evaluation.

Anisotropic structure (§2.3 of the paper)
──────────────────────────────────────────
V_k² = σ_k²·Π + ν_k²·(Id − Π), where Π is a RANDOM but SHARED M-dimensional
projector (same subspace for every component -- this is the paper's
"informative subspace" I). All means live in the subspace (Π m_k = m_k).
σ_k is the in-subspace spread, ν_k the (typically small) orthogonal noise.
M=None means isotropic (Π is not constructed at all; this is the default
and exactly recovers the previous, simpler behaviour).
"""

from __future__ import annotations

import numpy as np


# ─── Density and sampling ─────────────────────────────────────────────────────

def density_gmm(
    X: np.ndarray,
    mu: np.ndarray,
    m: np.ndarray,
    sigma: np.ndarray,
    B: np.ndarray | None = None,
    nu: np.ndarray | None = None,
) -> np.ndarray:
    """
    Evaluate the GMM density at each row of X.

    Isotropic (B=None, the default):
        f(x) = Σ_k µ_k · (2π)^(-d/2) · σ_k^(-d) · exp(-||x - m_k||² / 2σ_k²)

    Anisotropic (§2.3 structure, B given -- d x M orthonormal basis of the
    shared informative subspace, nu given -- (K,) orthogonal-noise std):
        V_k² = σ_k²·Π + ν_k²·(Id − Π),  Π = B Bᵀ
        f(x) = Σ_k µ_k · (2π)^(-d/2) · σ_k^(-M) · ν_k^(-(d-M))
                       · exp(-0.5·[‖Π(x-m_k)‖²/σ_k² + ‖(Id-Π)(x-m_k)‖²/ν_k²])
    The ‖(Id-Π)(x-m_k)‖² term is obtained as ‖x-m_k‖² − ‖Π(x-m_k)‖²
    (Pythagoras, since Π is an orthogonal projector) -- avoids ever having
    to build the (d-M)-dimensional orthogonal-complement basis just to
    evaluate a density.

    Parameters
    ----------
    X     : (n, d)  query points
    mu    : (K,)    mixture weights
    m     : (K, d)  component centres
    sigma : (K,)    in-subspace (or, if isotropic, full) standard deviations
    B     : (d, M) or None   shared informative-subspace basis (orthonormal columns)
    nu    : (K,) or None     orthogonal-noise std per component (isotropic if None)

    Returns
    -------
    density : (n,)
    """
    if X.ndim == 1:
        X = X[None, :]
    n, d = X.shape
    density = np.zeros(n)

    if B is not None:
        M_dim = B.shape[1]

    for k in range(len(mu)):
        diff = X - m[k][None, :]                                  # (n, d)
        if B is None:
            norm_const = (2.0 * np.pi) ** (-d / 2.0) * sigma[k] ** (-d)
            exponent   = -0.5 * np.sum(diff ** 2, axis=1) / sigma[k] ** 2
        else:
            full_sq = np.sum(diff ** 2, axis=1)
            in_sq   = np.sum((diff @ B) ** 2, axis=1)
            orth_sq = np.clip(full_sq - in_sq, 0.0, None)          # Pythagoras; clip fp noise
            norm_const = ((2.0 * np.pi) ** (-d / 2.0)
                          * sigma[k] ** (-M_dim) * nu[k] ** (-(d - M_dim)))
            exponent   = -0.5 * (in_sq / sigma[k] ** 2 + orth_sq / nu[k] ** 2)
        density += mu[k] * norm_const * np.exp(exponent)

    return density


def sample_gmm(
    n: int,
    mu: np.ndarray,
    m: np.ndarray,
    sigma: np.ndarray,
    seed=None,
    B: np.ndarray | None = None,
    B_perp: np.ndarray | None = None,
    nu: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Draw n samples from a GMM (isotropic, or the §2.3 anisotropic structure).

    Isotropic (B=None): X | k ~ N(m_k, σ_k² I_d).
    Anisotropic (B, B_perp, nu all given): X | k = m_k + B·z_in·σ_k + B_perp·z_out·ν_k,
    z_in ~ N(0, I_M), z_out ~ N(0, I_{d-M}) -- i.e. N(m_k, σ_k²Π + ν_k²(Id-Π)).

    Parameters
    ----------
    n      : number of samples
    mu     : (K,)   mixture weights
    m      : (K, d) component centres
    sigma  : (K,)   in-subspace (or full, if isotropic) standard deviations
    seed   : reproducibility
    B      : (d, M) or None  informative-subspace basis
    B_perp : (d, d-M) or None  orthogonal-complement basis (needed for sampling,
             unlike density_gmm which avoids it via Pythagoras)
    nu     : (K,) or None  orthogonal-noise std per component

    Returns
    -------
    X      : (n, d)   sampled points
    labels : (n,)     component indices (for diagnostics)
    """
    rng    = np.random.default_rng(seed)
    K, d   = m.shape
    labels = rng.choice(K, size=n, p=mu)
    X      = np.zeros((n, d))

    for k in range(K):
        mask = (labels == k)
        nk   = int(mask.sum())
        if nk == 0:
            continue
        if B is None:
            X[mask] = rng.normal(loc=m[k], scale=sigma[k], size=(nk, d))
        else:
            z_in  = rng.normal(scale=sigma[k], size=(nk, B.shape[1]))
            z_out = rng.normal(scale=nu[k],    size=(nk, B_perp.shape[1]))
            X[mask] = m[k][None, :] + z_in @ B.T + z_out @ B_perp.T

    return X, labels


# ─── Centre placement (shared by isotropic and anisotropic paths) ────────────

def _place_centers(
    K: int,
    dim: int,
    separation_sigma_units_range: tuple[float, float],
    sigma_range: tuple[float, float],
    rng: np.random.Generator,
) -> np.ndarray:
    """
    Place K centres in R^dim with pairwise distances honouring
    `separation_sigma_units_range` (multiples of max(sigma_range)).

    Each new centre is attached to a uniformly random EXISTING centre, at a
    distance drawn independently PER PAIR from
    [lo*max(sigma_range), hi*max(sigma_range)], along a random direction in
    R^dim -- then re-drawn if it happens to violate the separation floor
    (lo*max(sigma_range)) against any OTHER already-placed centre. The
    floor is a hard guarantee; the upper end of the range is a typical
    scale, not a guarantee (adaptive widening kicks in if placement is
    struggling to find room, same as the floor-only version before it).

    Note: this is an isometry-preserving operation when later embedded into
    R^d via an orthonormal basis (‖B(x-y)‖ = ‖x-y‖ for x,y in R^dim), so
    placing in R^M and embedding gives EXACTLY the same realized separation
    as placing directly in R^d would.
    """
    lo, hi = separation_sigma_units_range
    if not (0 < lo <= hi):
        raise ValueError(f"separation_sigma_units_range must satisfy 0 < lo <= hi, got {(lo, hi)}")
    ref = max(sigma_range)
    sep_floor, sep_hi = lo * ref, hi * ref

    m = np.zeros((K, dim))
    for k in range(1, K):
        placed = False
        cur_hi = sep_hi
        for attempt in range(2000):
            if attempt > 0 and attempt % 200 == 0:
                cur_hi *= 1.5   # widen if struggling to find room
            base = m[rng.integers(0, k)]
            direction = rng.normal(size=dim)
            direction /= np.linalg.norm(direction)
            dist = rng.uniform(sep_floor, cur_hi)
            candidate = base + direction * dist
            if np.linalg.norm(m[:k] - candidate[None, :], axis=1).min() >= sep_floor:
                m[k] = candidate
                placed = True
                break
        if not placed:
            raise RuntimeError(
                f"_place_centers: could not place component {k}/{K} with "
                f"separation range [{sep_floor:.3g}, {sep_hi:.3g}] in dim={dim} "
                f"after 2000 attempts (even with adaptive widening). Try a "
                f"smaller K, a narrower/lower separation range, or a higher dim."
            )
    return m


# ─── Main entry point ─────────────────────────────────────────────────────────

def make_gmm_data(
    K: int,
    d: int,
    n: int,
    separation_sigma_units_range: tuple[float, float] = (3.0, 5.0),
    sigma_range: tuple[float, float] = (0.3, 1.0),
    weight_ratio: float = 1.0,
    M: int | None = None,
    nu_ratio_range: tuple[float, float] = (0.05, 0.2),
    contamination_fraction: float = 0.0,
    contamination_scale: float = 20.0,
    contamination_type: str = 'uniform',
    seed=None,
) -> tuple[np.ndarray, dict]:
    """
    Generate a random GMM and sample n points from it, in one call.

    Parameters
    ----------
    K                            : number of components                          [required]
    d                            : ambient dimensionality                        [required]
    n                            : number of observations to sample               [required]
    separation_sigma_units_range: (lo, hi), the range (in multiples of
                                   max(sigma_range)) from which each new
                                   centre's distance to its attachment point
                                   is drawn independently, PER PAIR (not one
                                   value for the whole configuration). The
                                   realized minimum pairwise distance is
                                   guaranteed >= lo*max(sigma_range).
    sigma_range                  : (min_σ, max_σ) -- in-subspace (or full,
                                   if isotropic) standard deviation range,
                                   one value drawn per component.
    weight_ratio                 : ratio of largest to smallest true mixture
                                   weight (>= 1.0). Default 1.0 = uniform
                                   weights (unchanged default behaviour).
    M                            : informative-subspace dimension for the
                                   §2.3 anisotropic structure
                                   V_k² = σ_k²Π + ν_k²(Id-Π). None (default)
                                   = isotropic (no Π constructed at all).
                                   Must satisfy 0 < M < d if given.
    nu_ratio_range               : (lo, hi) range for ν_k/σ_k -- the
                                   orthogonal-noise std as a fraction of the
                                   in-subspace std. Only used if M is given.
                                   Default (0.05, 0.2) means genuinely small
                                   orthogonal noise ("ν small", per the
                                   paper), i.e. a strong manifold structure.
    contamination_fraction      : fraction of the n TOTAL points that are
                                   gross outliers (Uniform(-scale,scale)^d)
                                   instead of genuine draws from the true
                                   mixture -- classical Huber contamination
                                   convention (n stays fixed; contamination
                                   REPLACES, not adds to, clean draws).
                                   Default 0.0 = no contamination, unchanged
                                   behaviour. true_params always describes
                                   only the K clean components.
    contamination_scale         : contamination spread, in multiples of
                                   max(sigma_range). Default 20.0 --
                                   comfortably outside the clean components'
                                   natural spread. Only used if
                                   contamination_fraction > 0.
    contamination_type          : 'uniform' (default, Uniform(-scale,scale)^d
                                   gross outliers) or 'gaussian'
                                   (N(0,scale^2 I_d), softer/heavier-tailed
                                   contamination -- most points land at
                                   moderate distance with a real tail out
                                   further, rather than all near the box edge).
    seed                         : reproducibility

    Returns
    -------
    X : (n, d) sampled observations
    true_params : dict with keys:
        'mu'     (K,)    mixture weights
        'm'      (K, d)  component centres (Π m_k = m_k if anisotropic)
        'sigma'  (K,)    in-subspace (or full) standard deviations
        'M'      int or None   informative-subspace dimension
        'B'      (d, M) or None   informative-subspace basis
        'B_perp' (d, d-M) or None orthogonal-complement basis
        'nu'     (K,) or None   orthogonal-noise std per component
        'K', 'd' int, int
    """
    if M is not None and not (0 < M < d):
        raise ValueError(f"M must satisfy 0 < M < d (got M={M}, d={d}); "
                          f"use M=None for isotropic (equivalent to M=d).")
    if weight_ratio < 1.0:
        raise ValueError(f"weight_ratio must be >= 1.0, got {weight_ratio}")

    rng = np.random.default_rng(seed)

    # ── weights ──
    if weight_ratio == 1.0:
        mu = np.ones(K) / K
    else:
        raw = weight_ratio ** np.linspace(0.0, 1.0, K)
        rng.shuffle(raw)
        mu = raw / raw.sum()

    # ── in-subspace (or full) sigma ──
    sigma = rng.uniform(sigma_range[0], sigma_range[1], K)

    # ── anisotropic subspace + orthogonal noise, if requested ──
    if M is not None:
        Q, _   = np.linalg.qr(rng.normal(size=(d, d)))
        B      = Q[:, :M]
        B_perp = Q[:, M:]
        nu     = rng.uniform(nu_ratio_range[0], nu_ratio_range[1], K) * sigma
        gen_dim = M
    else:
        B = B_perp = nu = None
        gen_dim = d

    # ── place centres (in R^gen_dim; embed into R^d if anisotropic) ──
    m_local = _place_centers(K, gen_dim, separation_sigma_units_range, sigma_range, rng)
    m = m_local @ B.T if B is not None else m_local

    # Huber-style contamination -- a fraction of the n total points are
    # replaced by outliers instead of genuine draws from the true mixture.
    # n stays the TOTAL sample size (classical contamination-model
    # convention): n_contam = round(contamination_fraction*n) REPLACE, not
    # add to, n_clean = n - n_contam genuine draws. true_params always
    # describes only the K CLEAN components -- contamination is a nuisance
    # the estimator has to cope with, not part of the ground truth it's
    # scored against.
    #
    # Two contamination shapes:
    #   'uniform'  -- gross outliers, Uniform(-scale,scale)^d. Every
    #                 contamination point is roughly equally far, all the
    #                 way out near the box edge (an unusually extreme,
    #                 not-very-"natural" single outlier per point).
    #   'gaussian' -- N(0, scale^2 I_d), a genuinely heavy-tailed-in-effect
    #                 but softer contamination: most contaminating points
    #                 land at moderate distances, with a real tail
    #                 extending further out, closer to a "some measurements
    #                 just have extra noise" story than a hard box.
    if not (0.0 <= contamination_fraction < 1.0):
        raise ValueError(f"contamination_fraction must be in [0, 1), got {contamination_fraction}")
    if contamination_type not in ('uniform', 'gaussian'):
        raise ValueError(f"contamination_type must be 'uniform' or 'gaussian', got {contamination_type!r}")
    n_contam = round(n * contamination_fraction)
    n_clean = n - n_contam

    X_clean, _ = sample_gmm(n_clean, mu, m, sigma, seed=int(rng.integers(0, 2**31 - 1)),
                             B=B, B_perp=B_perp, nu=nu)
    if n_contam > 0:
        scale = contamination_scale * max(sigma_range)
        if contamination_type == 'uniform':
            X_contam = rng.uniform(-scale, scale, size=(n_contam, d))
        else:
            X_contam = rng.normal(0.0, scale, size=(n_contam, d))
        X = np.concatenate([X_clean, X_contam], axis=0)
        rng.shuffle(X)
    else:
        X = X_clean

    true_params = dict(mu=mu, m=m, sigma=sigma, M=M, B=B, B_perp=B_perp, nu=nu, K=K, d=d)
    return X, true_params


# ─── Deterministic grid layout (independent utility, unrelated to the above) ──

def make_gmm_params_grid(
    K: int,
    d: int,
    grid_spacing: float = 3.0,
    sigma: float = 0.5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Place K component centres on a regular grid (d = 1 or 2 only).

    Parameters
    ----------
    K            : number of components
    d            : dimensionality (1 or 2)
    grid_spacing : distance between adjacent centres
    sigma        : shared standard deviation for all components

    Returns
    -------
    mu    : (K,)   uniform weights
    m     : (K, d) grid centres
    sigma : (K,)   constant sigma_arr
    """
    mu = np.ones(K) / K

    if d == 1:
        m = np.linspace(0.0, grid_spacing * (K - 1), K)[:, None]
    elif d == 2:
        n_side = int(np.ceil(np.sqrt(K)))
        xx, yy = np.meshgrid(
            np.arange(n_side) * grid_spacing,
            np.arange(n_side) * grid_spacing,
        )
        m = np.stack([xx.ravel(), yy.ravel()], axis=1)[:K]
    else:
        raise NotImplementedError("Grid layout is only implemented for d = 1 and d = 2.")

    return mu, m, np.full(K, sigma)


# ─── Closures for the true distribution ──────────────────────────────────────

def make_true_fns(true_params: dict, seed_offset: int = 0):
    """
    Create (sample_fn, predict_fn) closures from a make_gmm_data true_params
    dict. Each call to sample_fn(n) uses a different seed (auto-incremented)
    so repeated calls produce independent fresh samples (e.g. for TestLL
    evaluation, which needs samples independent of the training set).

    Returns
    -------
    true_sample_fn  : n → X of shape (n, d)
    true_predict_fn : X → p(X) of shape (n,)
    """
    mu, m, sigma = true_params['mu'], true_params['m'], true_params['sigma']
    B, B_perp, nu = true_params['B'], true_params['B_perp'], true_params['nu']
    _counter = [seed_offset]

    def true_sample_fn(n):
        _counter[0] += 1
        X, _ = sample_gmm(n, mu, m, sigma, seed=_counter[0], B=B, B_perp=B_perp, nu=nu)
        return X

    def true_predict_fn(X):
        return density_gmm(X, mu, m, sigma, B=B, nu=nu)

    return true_sample_fn, true_predict_fn


# ─── Self-checks ───────────────────────────────────────────────────────────────

def _check_isotropic_matches_scipy():
    """density_gmm (isotropic path) must match scipy's reference exactly."""
    from scipy.stats import multivariate_normal
    rng = np.random.default_rng(0)
    mu = np.array([0.3, 0.7])
    m = rng.normal(size=(2, 4))
    sigma = np.array([0.7, 1.3])
    X = rng.normal(size=(20, 4))

    ref = sum(mu[k] * multivariate_normal(mean=m[k], cov=sigma[k] ** 2 * np.eye(4)).pdf(X)
              for k in range(2))
    got = density_gmm(X, mu, m, sigma)
    max_err = np.max(np.abs(ref - got))
    assert max_err < 1e-10, f"isotropic density_gmm mismatch vs scipy: {max_err}"
    print(f"[isotropic-density-vs-scipy] OK: max abs diff = {max_err:.2e}")


def _check_sample_gmm_moments():
    """sample_gmm (isotropic) empirical per-component mean/std must match the truth."""
    mu = np.array([0.5, 0.5])
    m = np.array([[0.0, 0.0], [10.0, 10.0]])
    sigma = np.array([1.0, 2.0])
    X, labels = sample_gmm(200_000, mu, m, sigma, seed=1)
    for k in (0, 1):
        pts = X[labels == k]
        assert np.allclose(pts.mean(axis=0), m[k], atol=0.05)
        assert np.allclose(pts.std(axis=0), sigma[k], atol=0.05)
    print("[sample-gmm-moments] OK: empirical per-component mean/std match ground truth.")


def _check_separation_guarantee():
    """
    Regression guard: make_gmm_data's centre placement must honour the
    separation floor (lo*max(sigma_range)) even in regimes that used to
    force a broken, unchecked fallback in an earlier version of this
    generator (K=30, d=1) -- that version violated separation in 30/30
    forced trials, down to min pairwise distances of ~0.02 when 5.0 was
    requested. Now: adaptive widening + a loud RuntimeError if genuinely
    unmeetable, never a silent violation.
    """
    for seed in range(20):
        _, tp = make_gmm_data(K=5, d=2, n=10, separation_sigma_units_range=(3.0, 5.0), seed=seed)
        m = tp['m']; K = tp['K']
        min_dist = min(np.linalg.norm(m[i] - m[j]) for i in range(K) for j in range(i + 1, K))
        floor = 3.0 * max((0.3, 1.0))  # default sigma_range
        assert min_dist >= floor - 1e-6, f"separation floor violated: {min_dist} < {floor}"

    for seed in range(20):  # regime that used to force the broken fallback
        _, tp = make_gmm_data(K=30, d=1, n=10, separation_sigma_units_range=(5.0, 7.5), seed=seed)
        m = tp['m']; K = tp['K']
        min_dist = min(np.linalg.norm(m[i] - m[j]) for i in range(K) for j in range(i + 1, K))
        floor = 5.0 * max((0.3, 1.0))
        assert min_dist >= floor - 1e-6, f"separation floor violated (K=30,d=1): {min_dist} < {floor}"

    print("[separation-guarantee] OK: separation floor honoured in both the normal regime "
          "and the regime that used to trigger a broken fallback (K=30, d=1).")


def _check_separation_range_d_independence():
    """
    The realized min_dist/max(sigma) ratio must stay within the requested
    [lo, hi] range and be independent of d -- the whole point of expressing
    separation in sigma units instead of raw feature units (a previous
    version of this generator accidentally scaled realized separation with
    sqrt(d), which this sidesteps entirely by construction).
    """
    lo, hi = 3.0, 5.0
    sigma_range = (0.5, 2.0)
    ratios_by_d = {}
    for d in (2, 20, 100):
        ratios = []
        for seed in range(10):
            _, tp = make_gmm_data(K=4, d=d, n=10, separation_sigma_units_range=(lo, hi),
                                   sigma_range=sigma_range, seed=seed)
            m = tp['m']; K = tp['K']
            min_dist = min(np.linalg.norm(m[i] - m[j]) for i in range(K) for j in range(i + 1, K))
            ratios.append(min_dist / max(sigma_range))
        ratios_by_d[d] = np.mean(ratios)

    for d, r in ratios_by_d.items():
        assert lo - 0.3 <= r <= hi * 1.6, f"ratio at d={d} ({r:.2f}) far outside [{lo},{hi}]"
    spread = max(ratios_by_d.values()) - min(ratios_by_d.values())
    assert spread < 1.5, f"ratio spreads too much across d: {ratios_by_d}"
    print(f"[separation-range-d-independence] OK: min_dist/max(sigma) ratios across "
          f"d=2..100 stay within range, spread={spread:.2f}: {ratios_by_d}")


def _check_weight_ratio():
    """Default (1.0) must stay EXACTLY uniform; an explicit ratio must be honoured exactly."""
    _, tp = make_gmm_data(K=5, d=10, n=10, seed=0)
    assert np.allclose(tp['mu'], 1.0 / 5), f"default weight_ratio=1.0 is not uniform: {tp['mu']}"

    for seed in range(10):
        _, tp = make_gmm_data(K=4, d=10, n=10, weight_ratio=8.0, seed=seed)
        mu = tp['mu']
        assert np.isclose(mu.sum(), 1.0)
        assert np.isclose(mu.max() / mu.min(), 8.0), f"weight_ratio not honoured: {mu}"
    print("[weight-ratio] OK: default stays uniform, explicit weight_ratio honoured exactly.")


def _check_anisotropic_structure():
    """
    The §2.3 anisotropic structure V_k² = σ_k²Π + ν_k²(Id-Π) must:
      (1) match scipy's reference density using an EXPLICITLY constructed
          full (d,d) covariance matrix (independent check of the closed-form
          density_gmm formula, not just internal self-consistency),
      (2) produce samples whose empirical in-subspace / orthogonal std
          match sigma / nu respectively,
      (3) keep every mean exactly IN the informative subspace (Pi @ m_k == m_k).
    """
    from scipy.stats import multivariate_normal
    d, M = 6, 2
    X_data, tp = make_gmm_data(K=2, d=d, n=100_000, M=M,
                                separation_sigma_units_range=(4.0, 6.0),
                                sigma_range=(1.0, 1.0), nu_ratio_range=(0.1, 0.1), seed=0)
    mu, m, sigma, B, B_perp, nu = tp['mu'], tp['m'], tp['sigma'], tp['B'], tp['B_perp'], tp['nu']
    Pi = B @ B.T

    # (1) density formula vs explicit scipy reference
    Xq = np.random.default_rng(1).normal(size=(10, d))
    for k in range(2):
        V = sigma[k] ** 2 * Pi + nu[k] ** 2 * (np.eye(d) - Pi)
        ref = multivariate_normal(mean=m[k], cov=V).pdf(Xq)
        # isolate component k's density contribution (without mu weighting) for a fair check
        got = density_gmm(Xq, np.array([1.0]), m[k][None, :], np.array([sigma[k]]),
                           B=B, nu=np.array([nu[k]]))
        max_err = np.max(np.abs(ref - got))
        assert max_err < 1e-6, f"anisotropic density_gmm mismatch vs scipy for component {k}: {max_err}"

    # (2) empirical in-subspace / orthogonal std from actual samples
    X, labels = sample_gmm(200_000, mu, m, sigma, seed=2, B=B, B_perp=B_perp, nu=nu)
    for k in range(2):
        diff = X[labels == k] - m[k]
        in_std = (diff @ B).std()
        orth_std = (diff @ B_perp).std()
        assert abs(in_std - sigma[k]) < 0.02, f"in-subspace std off: {in_std} vs {sigma[k]}"
        assert abs(orth_std - nu[k]) < 0.02, f"orthogonal std off: {orth_std} vs {nu[k]}"

    # (3) means live exactly in the subspace
    assert np.allclose(Pi @ m.T, m.T, atol=1e-8), "component means are not exactly in the subspace"

    print("[anisotropic-structure] OK: density matches scipy reference, empirical "
          "in-subspace/orthogonal std match sigma/nu, means lie exactly in the subspace.")


def _check_anisotropic_isometry():
    """
    Placing centres in R^M and embedding via an orthonormal basis into R^d
    must preserve the EXACT realized separation (isometry) -- i.e. an
    anisotropic config's realized separation should match an isotropic
    config's just as well, not be inflated/deflated by the embedding.
    """
    lo, hi = 3.0, 5.0
    ratios = []
    for seed in range(15):
        _, tp = make_gmm_data(K=4, d=50, n=10, M=5, separation_sigma_units_range=(lo, hi),
                               sigma_range=(0.5, 2.0), seed=seed)
        m = tp['m']; K = tp['K']
        min_dist = min(np.linalg.norm(m[i] - m[j]) for i in range(K) for j in range(i + 1, K))
        ratios.append(min_dist / 2.0)   # max(sigma_range)=2.0
    assert min(ratios) >= lo - 0.3, f"anisotropic embedding broke the separation floor: {ratios}"
    print(f"[anisotropic-isometry] OK: separation preserved through the M=5 -> d=50 "
          f"embedding, ratios in [{min(ratios):.2f}, {max(ratios):.2f}] (requested [{lo},{hi}]).")


def _check_contamination():
    """
    Guard for contamination_fraction/scale/type: default (0.0) must be
    unchanged behaviour (n clean points, exactly as before); a requested
    fraction must be honoured for BOTH shapes (n stays fixed total, that
    fraction of it replaced by outliers), and true_params must always
    describe only the K clean components (not shifted/altered by
    contamination).
    """
    X0, tp0 = make_gmm_data(K=3, d=10, n=1000, seed=0)
    assert X0.shape == (1000, 10)

    for ctype in ('uniform', 'gaussian'):
        X, tp = make_gmm_data(K=3, d=10, n=1000, sigma_range=(0.5, 1.0),
                               contamination_fraction=0.1, contamination_scale=20.0,
                               contamination_type=ctype, seed=0)
        assert X.shape == (1000, 10), f"[{ctype}] contamination must not change total n: {X.shape}"
        dist_to_nearest = np.min([np.linalg.norm(X - tp['m'][k], axis=1) for k in range(3)], axis=0)
        frac_far = (dist_to_nearest > 10).mean()
        assert abs(frac_far - 0.1) < 0.03, f"[{ctype}] contamination fraction not honoured: got {frac_far}"
        assert np.isclose(tp['mu'].sum(), 1.0), f"[{ctype}] true_params mu must describe only the clean mixture"

    print("[contamination] OK: default unchanged, both 'uniform' and 'gaussian' honour the "
          "requested fraction, true_params describes only clean components.")


if __name__ == '__main__':
    _check_isotropic_matches_scipy()
    _check_sample_gmm_moments()
    _check_separation_guarantee()
    _check_separation_range_d_independence()
    _check_weight_ratio()
    _check_anisotropic_structure()
    _check_anisotropic_isometry()
    _check_contamination()
