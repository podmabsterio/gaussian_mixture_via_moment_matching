# Results report (paper-draft slice)

Status legend: **CONFIRMED** = run under the current codebase (post data-
generator rewrite, post `model_df3.py` merge), numbers below are trustworthy
as-is. **STALE** = data in hand was produced before one or both of those
changes and describes a *different* configuration than its label now
implies; needs re-running before use in a final report.

---

## 1. Setup

Isotropic GMM ground truth via `make_gmm_data(K, d, n, ...)`.
`separation_sigma_units_range=(lo, hi)`: per-pair centre separation, in
multiples of `max(sigma_range)`, independent of `d` by construction
(verified: realized ratio stable across `d=2..100`, see engineering doc).
Four metrics: `TestLL`, `JS`, `PD`, `CRR`, plus the new `WeightErr`
(isolates weight-recovery accuracy). **Caveat carried throughout:**
`CRR`/`PD` read as "bad" under `K≠K_true` or anisotropic ground truth even
when the fit is actually good — always read alongside `JS`/`TestLL`/
`WeightErr` in those regimes (see open-problems doc #6).

All results below: `model=exact`, well-specified `K=K_true` unless noted,
6 seeds per configuration, mean (variance-between-seeds) format.

---

## 2. Separation identifiability — CONFIRMED

**Battery:** `separation.yaml` (240 jobs; `d∈{5,20,50,100}`,
`sep_lo∈{0.5,...,15.0}` sigma-units, `bandwidth_mult=1.0`).

`CRR=1.0` across the entire grid — no identifiability failures once
`K=K_true` and bandwidth is at its default. `JS`/`PD` improve
monotonically with separation and plateau by roughly `sep_lo≈4-6` sigma
units, consistently across every tested `d`:

| `d` | `JS` at `sep_lo=0.5` | `JS` at `sep_lo=15` (plateau) |
|---|---|---|
| 5 | 0.00145 | 0.00138 |
| 20 | 0.00524 | 0.00380 |
| 50 | 0.0168 | 0.0105 |
| 100 | 0.0324 | 0.0238 |

`WeightErr` shows the same shape (mild improvement, plateaus early) and
stays small throughout (`0.006-0.016` range) — weight recovery is not the
limiting factor here even at the most overlapping end of the sweep.

**Anomaly noted, not yet explained:** at `d=100, sep_lo∈{10,15}`,
`fit_time_s` drops sharply (13.4s, 8.8s vs a stable ~25s elsewhere) with
large between-seed variance (`var=59`, `var=4.1`) — a bimodal
fast/slow-convergence split on specific seeds, consistent with open
problem #1 (basin-dependent behaviour) rather than a `sep_lo`-driven
trend. Not investigated further; flagged for anyone reading fit-time
numbers from this table.

---

## 3. Bandwidth calibration (N1, N2, N3) optimality — CONFIRMED

**Battery:** `bandwidth_calibration.yaml` (264 jobs;
`d∈{5,20,50,100}`, `bandwidth_mult∈{0.5,...,2.0}`, well-specified `K`).

At `d∈{5,20,50}`, the paper's default `bandwidth_mult=1.0` sits close to
the empirical `JS`-minimum — the calibration is well-chosen there. At
`d=100` it is **not**:

| `bandwidth_mult` | `JS` (`d=100`) | `CRR` (`d=100`) |
|---|---|---|
| 0.50 | 0.0812 | **0.889** |
| 0.70 | 0.0493 | 1.0 |
| 1.00 (paper default) | 0.0385 | 1.0 |
| 1.50 | **0.0366** (minimum) | 1.0 |
| 2.00 | 0.0375 | 1.0 |

The empirical optimum shifts from `1.0` to roughly `1.5` at `d=100`, and —
more importantly — an under-sized bandwidth at high `d` costs more than
accuracy: `bandwidth_mult=0.5` is the only point in this entire battery
where `CRR<1`, i.e. a component is outright lost, not just poorly fit.
Consistent with Conjecture 2 (`s ≳ σ√d`): a flat `bandwidth_mult` doesn't
keep pace with the dimension-dependent bandwidth requirement.

**Scope note:** this battery varies the *overall scale* of the N1/N2/N3
targets only; their relative spacing is fixed in code and was not tested
here (would need a code change to `init_test_points`).

---

## 4. Weight recovery: accurate when detected, but detectability is not simply an `n` effect — CONFIRMED

**Batteries:** `weight_recovery.yaml` (144 jobs; `weight_ratio∈{1,2,4,8,16,32}`,
`d∈{5,20,50,100}`, `n=2000` fixed) and `weight_recovery_n_boundary.yaml`
(180 jobs; `weight_ratio∈{8,16,32}`, `n∈{1000,...,16000}`, `d∈{20,100}`),
plus a targeted diagnostic (`maxiter_inner=300` vs `1000`, same 6 seeds).

**(i) Weight-recovery formula is accurate when the component is detected.**
`WeightErr` stays in a narrow `0.006-0.02` band across `d` and
`weight_ratio`, as long as `CRR=1` — i.e. the `c`-reparametrisation and
its `(1+σ²/s_o²)^(d/2)` correction back to `mu` do not meaningfully
distort recovered class proportions.

**(ii) Detectability of the smallest component degrades with `weight_ratio`
and `d`, but is *not* a simple function of `n`.** From `weight_recovery`:

| `d` | `weight_ratio` | `CRR` | `PD` |
|---|---|---|---|
| 20 | 8 | 1.0 | 0.103 |
| 20 | 16 | 0.778 | 0.892 |
| 20 | 32 | 0.333 | 5.3e4 |
| 100 | 4 | 0.889 | 1.89 |
| 100 | 32 | 0.167 | 8.77 |

A natural hypothesis — "just needs more data" — was tested directly and
**does not hold** in the range tested. At `d=20, weight_ratio=16`, `CRR`
across `n=1000→2000→4000→8000→16000` is `0.722→0.778→0.778→0.444→0.5`: a
clear **drop** at 8x more data, not an improvement. `PD` shows the same
non-monotonic, huge-variance pattern (e.g. `d=20, weight_ratio=32,
n=2000`: `PD=53090, var=5.3e9`) that does not shrink with `n`.

A follow-up diagnostic ruled out optimizer budget as the cause: rerunning
the exact 6 seeds at the worst point (`d=20, weight_ratio=16, n=8000`)
with `maxiter_inner=1000` instead of `300` produced **bit-identical**
per-seed results (`CRR`, `JS`, `PD` unchanged to the last digit on every
seed). The outcome is determined by *something other than* iteration
budget or sample size — most likely which basin of attraction the
KMeans/test-point initialization lands in for that seed (open problem #1).
Per-seed pattern at the worst point: seeds 1,2 recover perfectly
(`CRR=1.0`) at *both* iteration budgets; seeds 0,4,5 fail identically
(`CRR=0.0`) at *both* — a discrete, seed-determined split, not a
convergence-time or data-quantity effect.

**Conclusion for the report:** split this into two claims — (i) the
weight-recovery formula itself is validated (confirmed, clean), and (ii)
detectability of severely underweighted components is limited by
optimizer/initialization dynamics, not sample size or iteration budget, in
the tested range — an open problem (see open-problems doc #1), not a
defect of the weight-recovery mechanism.

---

## 5. Pending — needs re-running before use in a final report

The following battery results currently in hand were produced **before**
the data-generator rewrite (`separation` used to silently scale with
`√d`) and/or **before** the `model_df3.py` merge (entropy-penalty
annealing, KMeans-reorder). Numbers under these old labels describe
different underlying configurations than they now would, and are not
safe to cite as final:

- **`separation_bandwidth` / `separation_bandwidth_extended`**
  (Experiment B — separation × bandwidth phase diagram): all data in hand
  used the pre-fix generator, where nominal "separation" values did not
  mean what they mean now. The qualitative finding that the apparent
  "collision zone" at intermediate separation was later *falsified* by
  direct measurement (bandwidth/separation ratio is constant across the
  sweep) likely still holds structurally, but exact numbers need a
  fresh run.
- **`weight_collapse` / `weight_collapse_fine`** (Experiment D): all data
  in hand predates the entropy-annealing merge and describes the *old*,
  sharper collapse-cliff dynamics. `weight_collapse_fine`'s grid has
  already been recalibrated to the new (post-annealing) transition zone
  but has not yet been run.
- **`n_outer_ablation`**: run after the data-generator fix but before the
  `model_df3.py` merge; `lambda_ent=0` throughout so the annealing change
  shouldn't matter functionally, but the KMeans-reorder shifts exact RNG
  draws — numbers are "close" but not strictly current.

## 6. Anisotropic ground truth (§2's central question) — preliminary only

`aniso_d20_M5` (single-seed spot check, not a battery): our isotropic
method (`TestLL=-14.6, JS=0.69`) vs correctly-specified `sklearn_em_full`
(`TestLL=-0.33, JS=0.043`) on the same strongly anisotropic (thin
5-of-20-dim manifold) ground truth. Confirms the isotropic procedure does
not currently adapt to this structure — expected, since `model_df3.py`'s
`effective_dim`/`M` support is explicitly deferred (see open-problems
doc #7). Not yet a battery-scale result; single seed only.

---

## 7. Robustness to contamination — a "victory" result, found honestly (including a false start)

**Motivation:** method-of-moments estimators with bounded/windowed test
functions are theoretically expected to be more robust to gross outliers
than EM (which maximises full likelihood over every point). Tested
directly, honestly, twice.

**First attempt (uniform-box contamination, scale=20x max(sigma_range),
i.e. outliers spread ~uniformly out to a very extreme distance)** — a
3-seed spot-check looked like a clean win (`CRR=1.0` for us at 5-10%
contamination vs `sklearn_em` collapsing already at 5%). **The full
10-seed battery did not confirm this**: `success_rate` (fraction of seeds
with `CRR≥0.99`) was only 0.50 at 2% contamination, 0.10 at 5%, and 0 for
both methods by 8%+. Worse, at points where our `CRR` still held,
`sklearn_em`'s `JS` was *better* than ours — a different, not obviously
superior, failure profile, not a win. Root cause of the misleading 3-seed
result: the same bimodal, seed-dependent-outcome phenomenon documented
elsewhere in this project (open-problems doc #1) — 3 seeds is not enough
to distinguish a real effect from favourable sampling. **Lesson
applied: this project does not report small-seed spot-checks as
findings any more** without a full-size confirmation.

**Second attempt (Gaussian contamination, moderate scale=3-5x
max(sigma_range), i.e. softer, more "extra measurement noise"-like
contamination than a hard box)** — properly probed at full seed count
(10) *before* drawing any conclusion this time. Confirmed, wide, and
consistent:

| `contamination_fraction` | `exact` success_rate | `sklearn_em` success_rate |
|---|---|---|
| 0.05 | 1.00 | 0.00 |
| 0.10 | 0.90-0.93 | 0.00 |
| 0.15 | 0.90-0.97 | 0.00 |
| 0.20 | 0.70-0.83 | 0.00 |

Consistent across both tested scales (3.0 and 5.0), across the entire
5-20% contamination range, over 10 seeds per point: our method holds
70-100% success while `sklearn_em`'s success rate was **0% at every
single point tested**. **Full battery now complete (560/560 jobs,
`conf/battery/victory_contamination.yaml`)** — confirms and sharpens the
probe:

| `contamination_fraction` | `exact` | `kappa` | `sklearn_em` | `sklearn_em_full` |
|---|---|---|---|---|
| 0% (baseline) | 1.00 | 1.00 | 1.00 | 1.00 |
| 2% | 1.00 | 1.00 | **0.00** | 0.00-0.10 |
| 5% | 1.00 | 1.00 | **0.00** | **0.00** |
| 8% | 0.90-1.00 | 0.90-1.00 | **0.00** | **0.00** |
| 10% | 0.90 | 0.90 | **0.00** | **0.00** |
| 15% | 0.40-0.90 | 0.40-0.90 | **0.00** | **0.00** |
| 20% | 0.00-0.70 | 0.00-0.70 | **0.00** | **0.00** |

Both sklearn variants hit `success_rate=0.00` at essentially *every*
tested contamination level from 2% up — not a gradual degradation, an
immediate near-total failure. Our method (`exact` and `kappa` behave
near-identically — the effect doesn't depend on the linearisation
choice) holds 100% success up to 8-10% contamination and degrades only
gradually beyond that, faster at `contamination_scale=5.0` (drops to 0 by
20%) than at `scale=3.0` (still 0.70 at 20%) — consistent with the
"more compact contamination is less harmful" mechanism hypothesis below.
This is now a fully confirmed, battery-scale (10 seeds, both scales, all
4 models, complete grid) result.

**Mechanism — now directly confirmed by instrumentation, not just plausible:**
instrumented `model_df3.py`'s exact KMeans+`sigma_init` init code path
(not a reimplementation) across 8 seeds at two points:

- **`contamination_fraction=0.10, scale=5.0`** (a point where the full
  battery shows `CRR=1.0` on 9/10 seeds): contamination points are spread
  across *all* clusters by KMeans (not concentrated in one), inflating
  `sigma_init` moderately (e.g. one seed: true `σ_max=1.96`, `sigma_init`
  reaches `3.0`, ~1.5x) — but **all 8 instrumented seeds still reach
  final `CRR=1.0`**, confirming the outer-iteration optimisation
  successfully self-corrects moderate initial inflation.
- **`contamination_fraction=0.20, scale=5.0`** (a point where the full
  battery shows `success_rate=0.00`, mean `CRR≈0.47`): the *same*
  mechanism fires much harder — `sigma_init` reaches `9.4-9.6` against a
  true max of `1.3-1.7` (5-7x inflation), with every cluster absorbing
  100-240 contamination points. Final `CRR` across the 8 instrumented
  seeds (`0.33,0.33,0.67,0.67,0.33,0.33,0.33,0.67`, mean `0.458`) closely
  matches the full battery's reported `0.4667` on this exact
  configuration, confirming the instrumentation reproduces the real
  phenomenon, not an artefact of the simplified diagnostic.

**Conclusion: there is a threshold effect.** Contamination inflates
`sigma_init` roughly in proportion to `contamination_fraction` (KMeans
spreads contamination across clusters fairly evenly regardless of
fraction); the outer-iteration optimisation can fully correct *moderate*
inflation (still resolves cleanly at 10%) but not *severe* inflation
(consistently fails to fully recover at 20%). This is now a directly
confirmed, not merely hypothesised, mechanism.

**Methodology note:** the first instrumentation attempt used the wrong
`contamination_type` default (`'uniform'` instead of `'gaussian'`,
forgotten in the diagnostic script, not the actual battery config) and
produced numbers that didn't match the real battery at all (`CRR` mostly
`1.0` instead of the expected `~0.47` mean at this configuration) —
caught immediately by cross-checking against the already-known aggregate
battery numbers for that exact point, before drawing any conclusion from
it. Re-run correctly, the numbers matched closely. Recorded here as a
reminder to always sanity-check a new diagnostic against a known result
before trusting what it says about something new.

**Not yet tested:** whether this generalises beyond `d=20`; whether the
effect holds under simultaneous weight imbalance or anisotropic ground
truth (both already separately shown to be hard regimes); whether
`sklearn_em`'s failure mode under contamination is mechanistically
similar (likely, since it also defaults to KMeans initialisation, but
not instrumented) or genuinely different (e.g. driven by the M-step's
full-likelihood weighting rather than initialisation alone).

---



Every battery referenced above has its raw per-job `metrics.json` under
`multirun/<date>/<time>/` on whichever machine ran it, and can be
regrouped or filtered further via `collect_results.py` (see `README.md`
for the exact `--group_by` keys per battery).
