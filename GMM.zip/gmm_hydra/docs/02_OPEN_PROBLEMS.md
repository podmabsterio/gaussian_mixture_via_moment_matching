# Open problems and hypotheses

Unsolved, in rough order of how well-characterised they currently are.
Each entry lists what's actually been measured, the live hypothesis, what
would falsify/confirm it, and which battery/test produced the evidence.

---

## 1. Discrete, seed-dependent catastrophic failures ("basin of attraction", not statistics or optimizer budget)

**What's measured:** Across several unrelated batteries, the same pattern
recurs: most seeds at a given configuration converge to a good fit
(`CRR≈1`, small `PD`/`JS`), while 1-2 out of 6 seeds catastrophically fail
(`CRR` near 0, `PD` in the thousands-to-millions), producing huge
between-seed variance and a misleading-looking mean. This shows up in:
- `separation_bandwidth_extended` (`bandwidth_mult=2.0`, `separation≥10`):
  `CRR` plateaus around 0.78 while `TestLL` drops an order of magnitude —
  1-2 seeds fail on density fit even though component *matching* still
  passes.
- `weight_recovery_n_boundary`: `CRR` is **non-monotonic in `n`** at fixed
  `weight_ratio` (e.g. `d=20, weight_ratio=16`: `0.722→0.778→0.778→
  0.444→0.5` as `n` goes `1000→2000→4000→8000→16000` — a clear *drop* at
  8x more data, not an improvement).
- A direct diagnostic (`maxiter_inner=300` vs `1000`, same 6 seeds,
  `d=20, weight_ratio=16, n=8000`) produced **bit-identical** per-seed
  results at both budgets — ruling out "optimizer needs more iterations"
  as the explanation.

**Live hypothesis:** the outcome is determined early, by which basin of
attraction the KMeans initialization + test-point sampling lands in for
that specific seed — not by statistical identifiability (some seeds *do*
recover perfectly on the identical data-generating configuration) and not
by optimization budget (proven above). This reframes several earlier,
more "geometric" hypotheses (a bandwidth/separation collision zone, a pure
sample-size effect) as likely just noise from this same underlying
phenomenon at low seed counts.

**What would confirm it:** multi-restart (several random inits per
config, keep the best by loss) should recover the good basin with high
probability even on configs where a *specific* seed fails. **Not yet
tested** — this is the immediate next diagnostic (proposed, not run: the
6 originally-problematic seeds from `weight_recovery_n_boundary`'s worst
point, each retried with several random restarts).

**What would falsify it:** if multi-restart does *not* reliably recover
the good basin, the failure is more fundamental than initialization
(e.g. a genuine narrow/flat region of the loss surface that's hard to
escape from *any* nearby start).

**Relevant code:** the `resample_seed` fix (engineering doc #2) already
ensures genuine restart diversity when `seed=None`; no `n_restarts`
orchestration exists yet in `model_df3.py` or the harness.

---

## 2. Weight collapse under entropy regularisation (Experiment D)

**What's measured (pre-merge, i.e. constant `lambda_ent` from `outer=0`):**
a sharp cliff — `K=8` vs `K_true=3`, `lambda_ent=0.0` gave no pruning
(`K_active=8`), `lambda_ent=0.02` already gave total collapse
(`K_active=1`), with no graceful window in between across the tested
grid.

**What's measured (post-merge, entropy-penalty annealing —
`lambda_ent_start_outer`, ramps in only on the last outer iteration):** a
much wider, genuinely graceful window — `lambda_ent≈0.008–0.015` lands
exactly on `K_active=3=K_true` with `CRR≈0.67`; full collapse only starts
around `lambda_ent≈0.1`, a 5x wider usable range (single-seed probe,
`2d_3comp`, `K=8`).

**Live hypothesis:** annealing substantially — but likely not
completely — resolves the collapse-cliff problem; the underlying
mechanism is still a discrete, seed-dependent phenomenon (see #1), just
with the *transition zone* now much wider in `lambda_ent`.

**What would confirm/refine it:** the `weight_collapse`/`weight_collapse_fine`
batteries need to be **re-run under the merged model** — all prior
`weight_collapse*` results in hand are from *before* the annealing merge
and describe the old, more pathological dynamics. `weight_collapse_fine`'s
grid has already been recalibrated to the new transition zone
(`lambda_ent∈[0.002,0.3]`, denser in `[0.005,0.05]`) but **not yet run**.

**Relevant tests:** `conf/battery/weight_collapse.yaml`,
`weight_collapse_fine.yaml` — need re-running; not yet done post-merge.

---

## 3. Bandwidth calibration (N1, N2, N3) is not uniformly optimal across `d`

**What's measured:** fine `bandwidth_mult` sweep (0.5-2.0) at well-specified
`K` (no over-specification confound), across `d∈{5,20,50,100}`:
- At `d=5,20,50`: `bandwidth_mult=1.0` (the paper's literal default) is
  close to the empirical `JS`-minimum.
- At `d=100`: `JS` decreases monotonically from `bandwidth_mult=0.5`
  (`JS=0.081`) to a minimum around `1.5` (`JS≈0.0366`), only rising
  slightly by `2.0` — i.e. the empirical optimum has shifted *above* the
  paper's flat default at high `d`. Worse: at `bandwidth_mult=0.5, d=100`,
  `CRR` drops below 1 for the first time in this sweep (`0.889`) — an
  under-sized bandwidth at high `d` risks losing a component outright,
  not just accuracy.

**Live hypothesis:** this is directly consistent with Conjecture 2
(`s ≳ σ√d`) — a flat `bandwidth_mult=1.0` doesn't keep pace with the
`√d` requirement, so the *relatively* correct bandwidth needs to grow
with `d`, and the paper's fixed-ratio N1:N2:N3 calibration (this battery
only tested the overall scale, not the ratio itself) may need to be
`d`-dependent to stay optimal at high dimension.

**What's NOT been tested:** whether the *relative spacing* between the
three levels (currently hardcoded as `1/(2K) : 1/(√2·K) : 1/K`) is itself
suboptimal, independent of the overall scale — that requires a code
change (`bandwidth_mult` only scales all three together, preserving
their ratio) not made here.

**Relevant tests:** `conf/battery/bandwidth_calibration.yaml`
(240+ jobs run, see analysis above); a follow-up varying the *ratio*
between levels would need new code in `init_test_points`.

---

## 4. Weight-recovery formula is accurate when detected; detectability is not simply an `n` problem

**What's measured:** `WeightErr` (new metric, isolates weight-recovery
accuracy from position/sigma error) stays in a narrow, reasonable band
(`0.006-0.02`) across `d` and `weight_ratio`, *as long as* the component
is actually detected (`CRR=1`) — confirming the simplex↔`c`
reparametrisation itself doesn't distort recovered proportions
(`weight_recovery` battery). But detectability (`CRR`) at high
`weight_ratio` (8-32) does **not** improve monotonically with `n`
(see #1 above, `weight_recovery_n_boundary`) — ruling out "just needs
more data" as a complete explanation, even though a naive sample-size
argument would predict monotonic improvement.

**Live hypothesis:** subsumed by #1 — this looks like the same
discrete/basin-dependent phenomenon rather than a distinct weight-recovery
defect.

**Relevant tests:** `weight_recovery.yaml`, `weight_recovery_n_boundary.yaml`.

---

## 5. (D)/(W) may not be orthogonal — bandwidth violations can provoke weight-like collapse even at `lambda_ent=0`

**What's measured:** `separation_bandwidth` battery, `bandwidth_mult=4.0`:
`CRR` degrades as `separation` increases from 1.0 to 6-9 (counter-
intuitive — more separated true components should be *easier*, not
harder, to recover), even with **zero** entropy penalty. A follow-up
direct measurement found the calibrated-bandwidth-to-realized-separation
ratio is **constant** across the whole `separation` sweep at fixed
`bandwidth_mult` (~2.6x for `bandwidth_mult=4.0`) — this falsified the
original "collision zone" geometric hypothesis (bandwidth crossing into a
danger zone at some specific separation value). The residual dip/recovery
pattern is more likely explained by #1 (seed-level stochastic basin
selection, with only 6 seeds per point) than a genuine geometric trend.

**Live hypothesis:** `bandwidth_mult=4.0` is uniformly (not locally) in a
worse regime than `bandwidth_mult≤2.0` (consistent with its constantly-high
bandwidth/separation ratio), and the apparent localized "dip" is sampling
noise from #1, not a distinct mechanism. Still open: *why* does
`bandwidth_mult=2.0` also start failing (via #1-style bimodal seed
failures) at `separation≥10`, if the ratio argument alone predicted safety
there too?

**Relevant tests:** `separation_bandwidth.yaml`, `_extended.yaml` — both
run **pre-merge** (before the annealing/KMeans-reorder changes); results
in hand describe the *old* dynamics and should be treated as provisional
until re-run.

---

## 6. `CRR`/`PD` are unreliable diagnostics under `K≠K_true` or anisotropic ground truth

**What's measured:** repeatedly, across `weight_recovery` (high
`weight_ratio`), `aniso_d20_M5` (both our isotropic method and even the
*correctly-specified* `sklearn_em_full` baseline), `CRR`/`PD` read as
"bad" in scenarios where `JS`/`TestLL`/`WeightErr` say the fit is actually
fine or excellent. This is a metric-design limitation (documented in
`metrics.py`, engineering doc), not a model defect — but it means any
report using `CRR`/`PD` alone under those two regimes will misread
quality.

**Not really "open"** in the sense of needing more experiments — this is
a settled methodological caveat to carry into the report, listed here so
it isn't forgotten when interpreting #2/#4/#7's numbers.

---

## 7. Isotropic estimator does not adapt automatically to anisotropic (§2.3) ground truth — this is the paper's own open question

**What's measured:** `aniso_d20_M5` (M=5-dim informative subspace in
`d=20`, small orthogonal noise, i.e. a strongly "thin" manifold): our
isotropic method gets `TestLL=-14.6, JS=0.69` (near-total density-fit
failure); the correctly-specified `sklearn_em_full` baseline gets
`TestLL=-0.33, JS=0.043` (excellent) on the *same* data. `CRR≈0` for both
(metric limitation, see #6, not informative here).

**Live hypothesis:** none yet, beyond the paper's own framing (Section 2)
— does the isotropic procedure adapt to anisotropic structure under the
right conditions, and if not, does adding the `effective_dim`/`M`
shape-adaptive correction (Section 2.2, explicitly deferred from the
merge — see engineering doc) resolve it? **This is the natural next major
piece of work**, not yet started in `model_df3.py` itself.

**Relevant tests:** `conf/data/aniso_d20_M5.yaml`,
`conf/model/sklearn_em_full.yaml`, `regression.yaml`'s
`sklearn_full_anisotropic` case (baseline only, not our method).

---

## 8. Linearisation accuracy of `link_mode='kappa'` at the paper's own suggested working point

**What's measured (in-code self-check, `_check_moment_formula`):** at
`s² ≍ d·σ²` (Section 1.3's own suggested scaling), the linearised formula
(1.12) already disagrees with the exact moment by **~38%** in a concrete
test case (shrinks to <0.1% as `σ/s → 0`, confirming this is
linearisation error, not an implementation bug). Flagged in the code as
an open stability question since this file was first built, not
resolved by anything done since.

**Live hypothesis:** none proposed yet. `link_mode='exact'` sidesteps this
by construction (no Taylor expansion at all) but at unknown extra cost
elsewhere (not characterised). This is the most theoretical/least-explored
open item on this list.

**Relevant tests:** none dedicated; `d100_boundary_kappa_mode` regression
case exercises `kappa` mode at one point but doesn't probe this
specifically.
