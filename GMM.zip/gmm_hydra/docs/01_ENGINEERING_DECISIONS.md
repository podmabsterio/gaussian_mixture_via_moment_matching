# Engineering decisions and fixed problems

Everything below was found, fixed, and verified (self-check + before/after
reproduction) during this project's review pass. Organized by file.

---

## `model_df3.py`

### Fixed bugs

1. **`predict_proba` overflow/nan at high `d`.** `norm = (2π)^(-d/2)·σ^(-d)`
   was computed in linear space before multiplying by the compensating
   `exp(-0.5·dist²/σ²)` term. At `sigma_floor=1e-2` this overflowed to
   `inf` around `d≈200`, and to `nan` (from `inf·0`) around `d≈1000` — even
   though the true density was finite. Fixed by summing in log-space
   (`logsumexp`) and exponentiating once at the end, with a safety clip at
   `exp(700)`. Verified bit-identical to the old formula in the safe
   regime, finite everywhere up to `d=1000` in the pathological regime.
   Guarded by `_check_predict_proba_stability`.

2. **Non-deterministic resample seed.** `seed=(seed or 0) + outer + 1`
   collapsed to a fixed sequence (`1,2,3,...`) whenever `seed=None` (the
   normal "give me a random run" case, e.g. for multi-restart), because
   `None or 0 == 0` regardless of true randomness elsewhere. This meant
   every "random" restart's resample-phase test points were byte-identical
   from `outer=1` onward — only the very first KMeans/init differed.
   Fixed by drawing from the already-correctly-seeded `rng` instead
   (`int(rng.integers(...))`), which preserves full reproducibility under
   an explicit seed while restoring genuine diversity under `seed=None`.
   Verified: same explicit seed twice → identical `S_`/`m`; `seed=None`
   twice → different `S_`/`m`.

3. **`sigma_init` / `sigma0` fallback used `X.std()`.** For an empty or
   singleton KMeans cluster, the fallback used the std of the *entire
   flattened* data array (all dimensions and points pooled), which
   contaminates the estimate with cross-dimension mean differences
   (isolated example: ×56 inflation from features living at different
   offsets, nothing to do with real spread). Empirically this fallback
   fires in ~88% of trials under the paper's own recommended usage
   (`K` deliberately over-specified relative to `n`). Fixed to use
   `sqrt(mean(var(X, axis=0)))` — the same per-dimension-variance scale
   the main branch uses, just computed over the whole dataset.

4. **`mu` property missing a correction factor.** `mu` was computed as
   `softmax(c)` directly, but the correct closed form is
   `mu_k ∝ exp(c_k)·(1+σ_k²/s_o²)^(d/2)`. The missing factor is invisible
   when all components share one `σ` (a common constant cancels on
   normalisation) — true of every experiment run before this was found —
   but biases `mu` by up to ~30% under heterogeneous `σ`. Fixed.

5. **Unhelpful error on degenerate data.** `bisect_bandwidth` raised
   scipy's generic `"f(a) and f(b) must have different signs"` on
   (near-)zero-variance input, because `h(s)` is constant at `n` for every
   `s>0` when all points are identical — no bracket can exist. Not a
   correctness bug (correctly refuses to proceed on garbage input), but
   the message didn't say why. Now raises a clear, specific error instead.

6. **`history_` not reset across repeated `.fit()` calls** (merged from a
   parallel development branch). Calling `.fit()` twice on the same model
   instance — e.g. multi-restart re-using one object — silently
   *accumulated* `history_` across calls instead of reflecting only the
   latest fit. Fixed: reset at the top of `fit()`. Guarded by
   `_check_history_resets_across_fits`.

### Merged from a parallel development branch (2026-07-26)

7. **Entropy-penalty annealing (`lambda_ent_start_outer`).** By default,
   entropy is `0` until the *last* outer iteration, then ramps to full
   strength, instead of applying `lambda_ent` at constant strength from
   `outer=0`. **This substantially widened the graceful-pruning window**
   for `K > K_true` (see problem #1 in the open-problems doc) — see the
   `weight_collapse_fine` battery discussion.
8. **`sigma_ceil`** — optional upper bound on `σ`, guards against a
   component "dying" by inflating `σ` to near-zero density instead of
   shrinking its weight. `None` (default) = unbounded, unchanged
   behaviour.
9. **`lambda_overlap` / `lambda_repel`** — experimental alternative
   identifiability penalties (Bhattacharyya-coefficient pairwise overlap;
   geometric repulsion on centres). Both honestly documented as *not*
   fully solving component-pruning on their own (overlap: correct
   direction but stalls on a symmetry-breaking problem where duplicate
   components shrink together instead of one collapsing; repel:
   empirically found not to reliably work). Kept available (default
   `0.0`, off), gradient-checked, for future reference/attempts — not
   claimed as solved mechanisms.
10. **`init_m` / `init_sigma`** — optional overrides bypassing KMeans
    initialization entirely, for testing robustness to deliberately
    corrupted starting points.
11. **Redundant `kappa` argument removed.** `kappa = d/(2·s_o²)` is now
    computed inside `_loss_and_grad` from `d` and `s_o` (both already
    required arguments) instead of being passed in separately, removing a
    latent out-of-sync risk.
12. **Redundant KMeans call removed.** `fit()` used to run KMeans twice —
    once for `m0`/`sigma_init`, and again *inside* `init_test_points`
    (when `sigma0` wasn't given) just to estimate a jitter scale.
    Reordered so the first KMeans's estimate is reused for both purposes.

### Explicitly deferred (not yet done, on purpose)

- **Section 2.2's "effective dimension" `M`** for the anisotropic
  amplitude correction is **not implemented in `model_df3.py`**. The data
  generator (`data.py`) *can* produce anisotropic §2.3 ground truth
  (`make_gmm_data(..., M=...)`), but the estimator itself is isotropic-only
  throughout. This is intentional, planned as a separate follow-up once
  the isotropic story is confirmed solid — see open problem #7.

---

## `metrics.py`

### Fixed bugs

1. **`parametric_distance` silently dropped its own stated penalty.**
   The final sum required both `i < K_true` *and* `j < K_est`, which
   excluded exactly the dummy-matched pairs that the `_LARGE = 1e6`
   sentinel (per the code's own comment, "penalty for unmatched (dummy)
   assignments") was meant to penalise. Concretely: a fit that collapsed
   to 1 of 3 true components reported `PD=0.59` (looks nearly perfect)
   instead of a value reflecting near-total failure. This directly risked
   **masking the severity of exactly the weight-collapse failures this
   project investigates**. Fixed by removing the `j < K_est` condition
   (the dummy-column cost is already correctly `_LARGE`; only rows with
   no corresponding true component, `i >= K_true`, should still be
   excluded). Verified: same collapsed-fit example now reports
   `PD≈666667`; well-matched cases unchanged. Guarded by
   `_check_parametric_distance_collapse_guard`.

### Added (new)

2. **`WeightErr` metric** (`weight_recovery_error`) — mean absolute error
   in recovered mixture weights over Hungarian-matched pairs, isolating
   *pure* weight-recovery quality. Unlike `PD` (bundles position + sigma +
   weight into one scalar) or `CRR`'s weight check (pass/fail against
   `tau_w`, not magnitude), this directly answers whether the
   simplex → free-parameter (`c`) reparametrisation and the
   `(1+σ²/s_o²)^(d/2)` correction distort recovered class proportions.
   Returns `NaN` (not a misleading number) when no real component was
   matched at all. Guarded by `_check_weight_recovery_error`.

### Known limitation (not a bug, but easy to misread)

3. **`CRR`/`PD` assume isotropic, well-specified ground truth for
   matching.** Under `K > K_true` (excess components split real mass
   across several small estimates that individually fail the strict
   Hungarian-matching tolerances) or anisotropic ground truth (a correct
   full-covariance fit reduced to one scalar `σ` for comparison purposes
   doesn't match well even when the actual density fit is excellent),
   `CRR`/`PD` read as "bad" even when `JS`/`TestLL`/`WeightErr` are fine.
   Always read `JS`/`TestLL`/`WeightErr` alongside `CRR`/`PD`, not
   `CRR`/`PD` alone, in either of those two regimes.

---

## `data.py`

### Fixed bugs

1. **`make_gmm_params_random`'s separation guarantee was silently
   violated by its own fallback** (now-removed function, see rewrite
   below). After 1000 failed rejection-sampling attempts, the fallback
   drew an *unchecked* candidate and returned it regardless — forced to
   fire (`K=30, d=1, separation=5.0`), it violated the requested
   separation in 30/30 forced trials, down to pairwise distances of
   ~0.02 when 5.0 was requested. None of the 9 named configs used at the
   time happened to trigger this (checked empirically), so it was latent.
   Superseded by the full rewrite below (adaptive widening + a loud
   `RuntimeError` if genuinely unmeetable, never a silent violation).

### Major rewrite: unified `make_gmm_data` entry point

2. **`separation` used to silently scale with `√d`.** The old generator
   drew candidate centres from `N(0, separation·√d)`, so the *realized*
   inter-component distance was inflated by a factor that itself grew
   with `d` (measured **~22x** at `d=20`, roughly constant-in-`separation`
   but NOT constant across `d`). This meant `separation` was silently
   **not comparable across different `d`** — e.g. two `d`-sweep configs
   using the same nominal `separation=4.0` at `d=5` vs `d=100` differed in
   real geometric difficulty by a large, uncontrolled factor. This
   confounded any "how does the method scale with `d`" conclusion drawn
   under the old generator. Fixed by attaching each new centre to a random
   *existing* centre at a controlled offset distance (in a fixed range,
   not scaled by `d`), rather than drawing an absolute position from a
   `d`-dependent-scale distribution. Verified: realized `separation/σ`
   ratio stays within a narrow band across `d=2..100` (was: ~5x at `d=2`
   vs ~22x at `d=20` — a `~4x` ratio-of-ratios; now stable to `~1.2x`).
3. **`separation_sigma_units_range=(lo, hi)`** replaces the old point
   value: separation between neighbouring centres, in multiples of
   `max(sigma_range)`, drawn independently **per pair** (not one value for
   the whole configuration). This is the transparent, recommended
   interface — `separation` alone (without knowing `σ`) doesn't tell you
   whether components look overlapping or separated.
4. **`weight_ratio`** — optional, default `1.0` (uniform, unchanged
   default behaviour). Ratio of the largest to smallest TRUE mixture
   weight, for testing recovery under genuine class imbalance (distinct
   from the `K > K_true` + entropy-penalty pruning scenario).
5. **`M` / `nu_ratio_range`** — the §2.3 anisotropic manifold structure,
   `V_k² = σ_k²·Π + ν_k²·(Id-Π)`, with a shared random `M`-dimensional
   subspace `Π` across all components. `M=None` (default) = isotropic,
   exactly recovering all prior behaviour. **Only the data generator
   supports this** — `model_df3.py` remains isotropic-only (see above).
6. `make_experiment_setup` (named-config dict) and the old
   `make_gmm_params_random` were removed entirely (real cleanup, not kept
   as parallel/deprecated interfaces) — all named configs and the whole
   Hydra harness now go through `make_gmm_data` uniformly.

---

## Infrastructure / Hydra harness (not `model_df3.py`/`data.py`/`metrics.py`)

1. **`hydra.job.chdir` defaults to `False` in Hydra 1.3+** — every job in
   a multirun sweep was writing `metrics.json` to the same file in the
   project root, overwriting each other. Fixed: `hydra.job.chdir: true`.
2. **Multirun subdir collision.** `seed` was excluded from
   `override_dirname` (for readable folder names) but not reintroduced
   anywhere else, so different seeds with otherwise-identical overrides
   collapsed to the same subfolder and overwrote each other. Fixed:
   subdir now includes `_seed${seed}` explicitly.
3. **`pipeline.py` unconditionally forced `model.K = K_true`,** making it
   impossible to test the paper's own primary recommended usage
   ("fix `K` by a rough upper bound, let the entropy penalty prune the
   rest"). Fixed: `model.K` defaults to `null` (= match `K_true`,
   preserves old behaviour) but can be overridden (`model.K=8`).
4. **`run_regression.py --update-baseline` overwrote the entire baseline
   file** instead of merging, silently wiping out every other case's
   baseline whenever `--cases` restricted a run to a subset. Fixed to
   merge into whatever's already on disk.
5. **Python 3.14 compatibility.** `hydra-core` 1.3.4 (latest PyPI release)
   crashes on Python 3.14 due to a stricter `argparse` help-string check
   colliding with Hydra's `--shell-completion` flag (upstream bug,
   `facebookresearch/hydra#3121`, fixed on Hydra's `main` branch but not
   yet released). Patched locally in `run.py`, gated to `sys.version_info
   >= (3, 14)` only.
6. **`collect_results.py` enhancements:** parses swept Hydra overrides out
   of the job-directory name (so `--group_by` works on any swept
   parameter, not just the fixed subset stored in `metrics.json`);
   automatic slow-job outlier detection (`fit_time_s > 10x median`);
   `--filter`/`--show_raw` for per-seed inspection without re-running
   anything.
7. **Metrics reporting format** changed from mean/min/max to
   mean (variance-between-seeds), per explicit request — variance, not
   std (squared units — noted so it isn't misread as std at a glance).

---

## Added: classic-EM baseline (`model_sklearn.py`)

`SklearnGMMBaseline` wraps `sklearn.mixture.GaussianMixture` to the exact
same interface `GMMDimensionFree3` exposes (`fit`/`predict_proba`/
`sample`/`.mu`/`.m`/`.sigma`/`.K`/`.d`), so it drops into the same Hydra
harness and `metrics.py` evaluation unchanged. Notably reimplements
`.sample()` from the fitted parameters directly rather than delegating to
sklearn's own `.sample()`, which reuses a fixed `random_state` from
construction time and would silently return identical samples on every
call regardless of the `seed` argument — exactly the kind of bug this
project has been hunting elsewhere, caught before it shipped.
