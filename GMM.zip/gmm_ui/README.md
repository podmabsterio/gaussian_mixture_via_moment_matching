# GMM Dimension-Free — Experiment Dashboard

Веб-интерфейс для запуска экспериментов и визуализации метрик GMM Dimension-Free (Spokoiny, 2026).

## Быстрый старт

```bash
cd gmm_ui
bash start.sh
```

Откройте в браузере: **http://localhost:8080**

## Возможности

### 1. Single Run (Одиночный запуск)
- Выбор пресета данных или ручная настройка параметров (K, d, n, separation, σ, weight ratio, contamination)
- Выбор модели: Kappa (формула 1.12), Exact (без линеаризации), Sklearn EM (baseline)
- Настройка гиперпараметров: n_outer, λ_ent, λ_m, bandwidth_mult, max_J, σ_floor
- Визуализация сходимости loss по outer-итерациям в реальном времени
- 2D scatter-plot данных с истинными и найденными центрами (для d=2)
- Карточки метрик: TestLL, JS, PD, CRR, WeightErr, K_active

### 2. Battery Test (Батарейные тесты)
- Предустановленные батареи из статьи:
  - **vs_sklearn** — сравнение с EM по размерностям
  - **n_outer_ablation** — сколько outer-итераций нужно
  - **separation** — кривая идентифицируемости
  - **weight_collapse** — порог коллапса весов при entropy penalty
  - **bandwidth_calibration** — калибровка bandwidth
  - **weight_recovery** — восстановление весов при дисбалансе
- Запуск до 20 экспериментов параллельно
- Отслеживание прогресса в реальном времени

### 3. Results (Результаты)
- Таблица всех запусков с метриками
- Фильтрация и сортировка
- Просмотр деталей каждого эксперимента

### 4. Compare (Сравнение)
- Столбчатые диаграммы JS и CRR по всем завершённым экспериментам
- Группировка по типу модели (цветовая кодировка)

## Архитектура

```
gmm_ui/
├── backend/
│   └── app.py          # Flask API (порт 5000)
├── frontend/
│   └── index.html      # SPA с Chart.js + Tailwind CSS (порт 8080)
├── requirements.txt
├── start.sh            # Скрипт запуска
└── README.md
```

**Backend** — Flask-сервер, который:
- Импортирует код из `gmm_hydra/gmm_hydra/` напрямую
- Запускает эксперименты в фоновых потоках
- Предоставляет REST API для конфигурации, запуска и получения результатов

**Frontend** — одностраничное приложение:
- Tailwind CSS для стилизации (dark theme)
- Chart.js для графиков (loss convergence, scatter, bar charts)
- Polling API каждую секунду для live-обновлений

## API Endpoints

| Метод | URL | Описание |
|-------|-----|----------|
| GET | `/api/configs` | Доступные пресеты данных/моделей/батарей |
| POST | `/api/run` | Запуск одного эксперимента |
| GET | `/api/experiment/<id>` | Статус и результаты эксперимента |
| GET | `/api/experiments` | Список всех экспериментов |
| POST | `/api/run_battery` | Запуск батареи тестов |
| POST | `/api/clear` | Очистить все эксперименты |

## Требования

- Python 3.10+
- Flask, NumPy, SciPy, scikit-learn, Hydra
- Современный браузер (Chrome/Firefox/Safari)
