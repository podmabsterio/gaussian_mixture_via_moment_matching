"""
Flask backend for GMM Experiment UI.
Provides API endpoints to:
- List available configurations (models, data presets, batteries)
- Run experiments with custom parameters
- Report per-outer-iteration progress LIVE (not just at the end)
- Retrieve results and metrics
"""
import sys
import os
import json
import time
import threading
import uuid
from pathlib import Path

# Add the GMM code to path
# Expected layout:
#   project_root/
#     gmm_hydra/       <-- your original code (unzipped gmm_hydra.zip)
#       conf/
#       data.py
#       model_df3.py
#       ...
#     gmm_ui/          <-- this dashboard
#       backend/
#         app.py       <-- this file
#       frontend/
#         index.html
#       start.sh
#
# We look for gmm_hydra in several possible locations:
_this_dir = Path(__file__).resolve().parent
_candidates = [
    _this_dir.parent.parent / "gmm_hydra" / "gmm_hydra",  # project_root/gmm_hydra/gmm_hydra/
    _this_dir.parent.parent / "gmm_hydra",                 # project_root/gmm_hydra/ (flat)
    _this_dir.parent / "gmm_hydra" / "gmm_hydra",         # gmm_ui/gmm_hydra/gmm_hydra/
    _this_dir.parent / "gmm_hydra",                        # gmm_ui/gmm_hydra/
]
GMM_CODE_DIR = None
for _c in _candidates:
    if (_c / "model_df3.py").exists():
        GMM_CODE_DIR = _c
        break
if GMM_CODE_DIR is None:
    print("ERROR: Cannot find GMM code (model_df3.py).")
    print("Expected directory structure:")
    print("  project_root/")
    print("    gmm_hydra/        <-- unzipped gmm_hydra.zip contents")
    print("      model_df3.py")
    print("      data.py")
    print("      ...")
    print("    gmm_ui/           <-- this dashboard")
    print("      backend/app.py")
    print("      frontend/index.html")
    print("      start.sh")
    print(f"\nSearched in: {[str(c) for c in _candidates]}")
    sys.exit(1)
print(f"[GMM UI] Using GMM code from: {GMM_CODE_DIR}")
sys.path.insert(0, str(GMM_CODE_DIR))

from flask import Flask, jsonify, request, Response
from flask_cors import CORS
import numpy as np

app = Flask(__name__)
CORS(app)

# In-memory store for experiment runs
experiments = {}
experiments_lock = threading.Lock()


def numpy_to_python(obj):
    """Convert numpy types to Python native types for JSON serialization."""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: numpy_to_python(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [numpy_to_python(x) for x in obj]
    return obj


# ─── Available configurations ────────────────────────────────────────────────

DATA_PRESETS = {
    "2d_3comp": {"K": 3, "d": 2, "n": 2000, "sep_lo": 2.5, "sep_hi": 4.0,
                 "sigma_range": [0.4, 0.8], "weight_ratio": 1.0},
    "2d_5comp": {"K": 5, "d": 2, "n": 3000, "sep_lo": 2.5, "sep_hi": 4.0,
                 "sigma_range": [0.4, 0.8], "weight_ratio": 1.0},
    "2d_10comp": {"K": 10, "d": 2, "n": 5000, "sep_lo": 2.5, "sep_hi": 4.0,
                  "sigma_range": [0.4, 0.8], "weight_ratio": 1.0},
    "R2_2comp": {"K": 2, "d": 2, "n": 2000, "sep_lo": 5.0, "sep_hi": 7.0,
                 "sigma_range": [0.5, 0.5], "weight_ratio": 1.0},
    "R10_10comp_sep": {"K": 10, "d": 10, "n": 5000, "sep_lo": 4.0, "sep_hi": 6.0,
                       "sigma_range": [0.5, 1.5], "weight_ratio": 1.0},
    "R100_2comp": {"K": 2, "d": 100, "n": 2000, "sep_lo": 5.0, "sep_hi": 7.0,
                   "sigma_range": [0.5, 0.5], "weight_ratio": 1.0},
    "dsweep_d5": {"K": 3, "d": 5, "n": 2000, "sep_lo": 3.0, "sep_hi": 5.0,
                  "sigma_range": [0.5, 2.0], "weight_ratio": 1.0},
    "dsweep_d20": {"K": 3, "d": 20, "n": 2000, "sep_lo": 3.0, "sep_hi": 5.0,
                   "sigma_range": [0.5, 2.0], "weight_ratio": 1.0},
    "dsweep_d50": {"K": 3, "d": 50, "n": 2000, "sep_lo": 3.0, "sep_hi": 5.0,
                   "sigma_range": [0.5, 2.0], "weight_ratio": 1.0},
    "dsweep_d100": {"K": 3, "d": 100, "n": 2000, "sep_lo": 3.0, "sep_hi": 5.0,
                    "sigma_range": [0.5, 2.0], "weight_ratio": 1.0},
    "aniso_d20_M5": {"K": 5, "d": 20, "n": 3000, "sep_lo": 3.0, "sep_hi": 5.0,
                     "sigma_range": [0.5, 2.0], "weight_ratio": 1.0, "M": 5},
}

MODEL_PRESETS = {
    "kappa": {
        "link_mode": "kappa", "K": None, "n_outer": 6, "lambda_ent": 0.0,
        "lambda_m_init": 1.0, "lambda_m_decay": 0.5, "sigma_floor": 0.01,
        "max_J": 400, "bandwidth_mult": 1.0, "resample": True
    },
    "exact": {
        "link_mode": "exact", "K": None, "n_outer": 6, "lambda_ent": 0.0,
        "lambda_m_init": 1.0, "lambda_m_decay": 0.5, "sigma_floor": 0.01,
        "max_J": 400, "bandwidth_mult": 1.0, "resample": True
    },
    "sklearn_em": {
        "type": "sklearn", "covariance_type": "spherical", "K": None,
        "n_init": 10, "max_iter": 300
    },
    "sklearn_em_full": {
        "type": "sklearn", "covariance_type": "full", "K": None,
        "n_init": 10, "max_iter": 300
    },
}

BATTERY_PRESETS = {
    "vs_sklearn": {
        "description": "Head-to-head: our method vs classic EM across dimensions",
        "data": ["dsweep_d5", "dsweep_d20", "dsweep_d50", "dsweep_d100"],
        "model": ["exact", "kappa", "sklearn_em"],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
    "n_outer_ablation": {
        "description": "How many outer iterations are needed across d",
        "data": ["dsweep_d5", "dsweep_d20", "dsweep_d50", "dsweep_d100"],
        "model": ["exact"],
        "n_outer_values": [4, 6, 8, 10, 12, 16],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
    "separation": {
        "description": "Separation-only identifiability curve (CRR/JS vs separation)",
        "data": ["dsweep_d5", "dsweep_d20", "dsweep_d50", "dsweep_d100"],
        "model": ["exact"],
        "sep_lo_values": [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 10.0, 15.0],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
    "weight_collapse": {
        "description": "Entropy-penalty weight-collapse threshold (K=8 vs K_true=3)",
        "data": ["dsweep_d20"],
        "model": ["exact"],
        "model_K": 8,
        "lambda_ent_values": [0.0, 0.002, 0.005, 0.008, 0.01, 0.012, 0.015, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
    "bandwidth_calibration": {
        "description": "Optimality of bandwidth scale calibration",
        "data": ["dsweep_d20"],
        "model": ["exact"],
        "bandwidth_mult_values": [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
    "weight_recovery": {
        "description": "Weight recovery under genuine weight imbalance",
        "data": ["dsweep_d20"],
        "model": ["exact"],
        "weight_ratio_values": [1.0, 1.5, 2.0, 3.0, 5.0, 8.0, 10.0],
        "seeds": [0, 1, 2, 3, 4, 5]
    },
}


@app.route('/api/configs', methods=['GET'])
def get_configs():
    """Return available data presets, model presets, and battery presets."""
    return jsonify({
        "data_presets": DATA_PRESETS,
        "model_presets": MODEL_PRESETS,
        "battery_presets": BATTERY_PRESETS,
    })


@app.route('/api/run', methods=['POST'])
def run_experiment():
    """
    Launch a single experiment run.
    Body: {data_params, model_params, seed, maxiter_inner}
    Returns: {experiment_id}
    """
    body = request.json
    exp_id = str(uuid.uuid4())[:8]

    with experiments_lock:
        experiments[exp_id] = {
            "id": exp_id,
            "status": "running",
            "config": body,
            "progress": [],
            "metrics": None,
            "data_info": None,
            "fitted_params": None,
            "start_time": time.time(),
            "end_time": None,
            "error": None,
        }

    thread = threading.Thread(target=_run_experiment, args=(exp_id, body), daemon=True)
    thread.start()

    return jsonify({"experiment_id": exp_id})


def _fit_with_live_progress(model, X, maxiter_inner, seed, exp_id):
    """
    Fit the model one outer iteration at a time, reporting progress live.
    This monkey-patches the model's n_outer to 1 and calls fit repeatedly,
    simulating the outer loop manually so we can report after each step.
    """
    from model_df3 import (GMMDimensionFree3, init_test_points, empirical_moment,
                           _loss_and_grad, _pack, _unpack)
    from scipy.optimize import minimize
    from sklearn.cluster import KMeans

    rng = np.random.default_rng(seed)
    n, d = X.shape
    model.d = d
    K = model.K
    model.history_ = []

    # Initialize
    km = KMeans(n_clusters=K, n_init=4, random_state=seed).fit(X)
    labels = km.labels_
    m0 = km.cluster_centers_ + rng.normal(scale=0.05, size=(K, d))
    _whole_data_scale = float(np.sqrt(np.var(X, axis=0).mean()))
    sigma_init = np.array([
        max(np.sqrt(np.var(X[labels == k], axis=0).mean()), model.sigma_floor * 2)
        if (labels == k).sum() > 1 else max(_whole_data_scale, model.sigma_floor * 2)
        for k in range(K)
    ])
    c_init = np.zeros(K)

    xi, U, s_of_j, S = init_test_points(X, K, p0=model.p0, sigma0=float(np.median(sigma_init)),
                                         seed=seed, max_J=model.max_J,
                                         bandwidth_mult=model.bandwidth_mult)
    s_o = float(S.min())
    model.S_ = S

    theta = _pack(m0.copy(), sigma_init, c_init)
    lambda_m = model.lambda_m_init

    bounds = ([(None, None)] * (K * d) + [(model.sigma_floor, model.sigma_ceil)] * K
              + [(None, None)] * K)

    t0 = time.time()

    for outer in range(model.n_outer):
        Z = empirical_moment(X, xi, U, s_of_j)

        if outer < model.lambda_ent_start_outer:
            lambda_ent_eff = 0.0
        else:
            span = max(model.n_outer - model.lambda_ent_start_outer, 1)
            frac = (outer - model.lambda_ent_start_outer + 1) / span
            lambda_ent_eff = model.lambda_ent * min(frac, 1.0)

        res = minimize(
            _loss_and_grad, theta,
            args=(K, d, xi, U, s_of_j, Z, s_o, lambda_ent_eff, lambda_m, m0,
                  model.link_mode, 0.0, 0.0, s_o),
            jac=True, method='L-BFGS-B', bounds=bounds,
            options={'maxiter': maxiter_inner},
        )
        theta = res.x
        m_hat, sigma_hat, c_hat = _unpack(theta, K, d)
        model.history_.append(float(res.fun))

        # LIVE progress update
        elapsed = time.time() - t0
        with experiments_lock:
            experiments[exp_id]["progress"].append({
                "outer": outer,
                "loss": float(res.fun),
                "time": elapsed,
                "n_iter_inner": res.nit,
            })
            # Also store intermediate fitted params for live 2D viz
            model.m, model.sigma, model.c = m_hat, sigma_hat, c_hat
            model.S_ = S
            experiments[exp_id]["fitted_params"] = {
                "mu": model.mu.tolist(),
                "m": m_hat.tolist(),
                "sigma": sigma_hat.tolist(),
                "K_active": int((model.mu > 1e-3).sum()),
            }

        m0 = m_hat.copy()
        lambda_m *= model.lambda_m_decay

        if model.resample and outer < model.n_outer - 1:
            resample_seed = int(rng.integers(0, 2**31 - 1))
            xi, U, s_of_j, S = init_test_points(
                X, K, p0=model.p0, sigma0=float(np.median(sigma_hat)),
                seed=resample_seed, max_J=model.max_J,
                bandwidth_mult=model.bandwidth_mult)
            s_o = float(S.min())
            model.S_ = S

    model.m, model.sigma, model.c = m_hat, sigma_hat, c_hat
    return time.time() - t0


def _run_experiment(exp_id, config):
    """Run a single experiment in a background thread."""
    try:
        from data import make_gmm_data, make_true_fns
        from model_df3 import GMMDimensionFree3
        from model_sklearn import SklearnGMMBaseline as GMMSklearn
        from metrics import evaluate_all_metrics

        # Parse data parameters
        data_params = config.get("data_params", {})
        model_params = config.get("model_params", {})
        seed = config.get("seed", 0)
        maxiter_inner = config.get("maxiter_inner", 300)

        # Generate data
        K = data_params.get("K", 3)
        d = data_params.get("d", 2)
        n = data_params.get("n", 2000)
        sep_lo = data_params.get("sep_lo", 3.0)
        sep_hi = data_params.get("sep_hi", 5.0)
        sigma_range = tuple(data_params.get("sigma_range", [0.5, 2.0]))
        weight_ratio = data_params.get("weight_ratio", 1.0)
        M = data_params.get("M", None)
        contamination_fraction = data_params.get("contamination_fraction", 0.0)
        contamination_scale = data_params.get("contamination_scale", 20.0)
        contamination_type = data_params.get("contamination_type", "uniform")

        X, true_params = make_gmm_data(
            K=K, d=d, n=n,
            separation_sigma_units_range=(sep_lo, sep_hi),
            sigma_range=sigma_range,
            weight_ratio=weight_ratio,
            M=M,
            contamination_fraction=contamination_fraction,
            contamination_scale=contamination_scale,
            contamination_type=contamination_type,
            seed=seed,
        )

        true_sample_fn, true_predict_fn = make_true_fns(true_params, seed_offset=seed)

        # Store data info
        data_info = {
            "n": n, "d": d, "K": K,
            "true_mu": true_params["mu"].tolist(),
            "true_sigma": true_params["sigma"].tolist(),
            "true_m": true_params["m"].tolist(),
        }
        # For 2D data, store X for visualization
        if d == 2:
            data_info["X"] = X.tolist()

        with experiments_lock:
            experiments[exp_id]["data_info"] = data_info

        # Create and fit model
        model_type = model_params.get("type", "df3")
        model_K = model_params.get("K", None)
        if model_K is None:
            model_K = K

        if model_type == "sklearn":
            covariance_type = model_params.get("covariance_type", "spherical")
            model = GMMSklearn(K=model_K, covariance_type=covariance_type,
                               n_init=model_params.get("n_init", 10),
                               max_iter=model_params.get("max_iter", 300))
            t0 = time.time()
            model.fit(X, maxiter_inner=maxiter_inner, seed=seed)
            fit_time = time.time() - t0

            with experiments_lock:
                experiments[exp_id]["progress"].append({
                    "outer": 0, "loss": None, "time": fit_time
                })
        else:
            link_mode = model_params.get("link_mode", "kappa")
            n_outer = model_params.get("n_outer", 6)
            lambda_ent = model_params.get("lambda_ent", 0.0)
            lambda_m_init = model_params.get("lambda_m_init", 1.0)
            lambda_m_decay = model_params.get("lambda_m_decay", 0.5)
            sigma_floor = model_params.get("sigma_floor", 0.01)
            max_J = model_params.get("max_J", 400)
            bandwidth_mult = model_params.get("bandwidth_mult", 1.0)
            resample = model_params.get("resample", True)
            sigma_ceil = model_params.get("sigma_ceil", None)
            lambda_ent_start_outer = model_params.get("lambda_ent_start_outer", None)

            model = GMMDimensionFree3(
                K=model_K, link_mode=link_mode, n_outer=n_outer,
                lambda_ent=lambda_ent, lambda_m_init=lambda_m_init,
                lambda_m_decay=lambda_m_decay, sigma_floor=sigma_floor,
                max_J=max_J, bandwidth_mult=bandwidth_mult, resample=resample,
                sigma_ceil=sigma_ceil, lambda_ent_start_outer=lambda_ent_start_outer,
            )

            # Use live progress fitting
            fit_time = _fit_with_live_progress(model, X, maxiter_inner, seed, exp_id)

        # Evaluate metrics
        metrics = evaluate_all_metrics(
            model,
            true_params={"mu": true_params["mu"], "m": true_params["m"], "sigma": true_params["sigma"]},
            true_sample_fn=true_sample_fn,
            true_predict_fn=true_predict_fn,
            n_test=5000,
            n_js=10000,
            seed=seed,
        )
        metrics["fit_time_s"] = fit_time

        # Store final fitted parameters
        fitted_params = {
            "mu": model.mu.tolist() if model.mu is not None else None,
            "m": model.m.tolist() if model.m is not None else None,
            "sigma": model.sigma.tolist() if model.sigma is not None else None,
            "K_active": int(metrics["K_active"]),
        }

        with experiments_lock:
            experiments[exp_id]["status"] = "completed"
            experiments[exp_id]["metrics"] = numpy_to_python(metrics)
            experiments[exp_id]["fitted_params"] = fitted_params
            experiments[exp_id]["end_time"] = time.time()

    except Exception as e:
        import traceback
        with experiments_lock:
            experiments[exp_id]["status"] = "error"
            experiments[exp_id]["error"] = str(e) + "\n" + traceback.format_exc()
            experiments[exp_id]["end_time"] = time.time()


@app.route('/api/experiment/<exp_id>', methods=['GET'])
def get_experiment(exp_id):
    """Get the current state of an experiment."""
    with experiments_lock:
        exp = experiments.get(exp_id)
    if exp is None:
        return jsonify({"error": "Experiment not found"}), 404
    return jsonify(numpy_to_python(exp))


@app.route('/api/experiments', methods=['GET'])
def list_experiments():
    """List all experiments (summary)."""
    with experiments_lock:
        result = []
        for exp_id, exp in experiments.items():
            result.append({
                "id": exp["id"],
                "status": exp["status"],
                "config": exp["config"],
                "metrics": exp["metrics"],
                "start_time": exp["start_time"],
                "end_time": exp["end_time"],
                "battery_id": exp.get("battery_id"),
                "battery_name": exp.get("battery_name"),
            })
    return jsonify(result)


@app.route('/api/run_battery', methods=['POST'])
def run_battery():
    """
    Launch a battery of experiments.
    Body: {battery_name} or {custom_configs: [{data_params, model_params, seed}...]}
    Returns: {battery_id, experiment_ids: [...]}
    """
    body = request.json
    battery_id = "bat_" + str(uuid.uuid4())[:6]
    battery_name = body.get("battery_name", "custom")
    exp_ids = []

    if "battery_name" in body:
        battery = BATTERY_PRESETS.get(body["battery_name"])
        if battery is None:
            return jsonify({"error": "Battery not found"}), 404
        configs = _expand_battery(battery, body.get("overrides", {}))
    elif "custom_configs" in body:
        configs = body["custom_configs"]
    else:
        return jsonify({"error": "Must provide battery_name or custom_configs"}), 400

    # Limit concurrent experiments
    max_concurrent = min(len(configs), 20)
    configs = configs[:max_concurrent]

    for cfg in configs:
        exp_id = str(uuid.uuid4())[:8]
        exp_ids.append(exp_id)
        with experiments_lock:
            experiments[exp_id] = {
                "id": exp_id,
                "status": "running",
                "config": cfg,
                "progress": [],
                "metrics": None,
                "data_info": None,
                "fitted_params": None,
                "start_time": time.time(),
                "end_time": None,
                "error": None,
                "battery_id": battery_id,
                "battery_name": battery_name,
            }
        thread = threading.Thread(target=_run_experiment, args=(exp_id, cfg), daemon=True)
        thread.start()

    return jsonify({"battery_id": battery_id, "experiment_ids": exp_ids, "total_jobs": len(configs)})


def _expand_battery(battery, overrides):
    """Expand a battery preset into individual experiment configs."""
    configs = []
    seeds = overrides.get("seeds", battery.get("seeds", [0]))
    data_list = battery.get("data", ["dsweep_d20"])
    model_list = battery.get("model", ["exact"])

    for data_name in data_list:
        data_params = DATA_PRESETS.get(data_name, DATA_PRESETS["dsweep_d20"]).copy()
        for model_name in model_list:
            model_params = MODEL_PRESETS.get(model_name, MODEL_PRESETS["kappa"]).copy()
            for seed in seeds:
                cfg = {
                    "data_params": data_params.copy(),
                    "model_params": model_params.copy(),
                    "seed": seed,
                    "maxiter_inner": 300,
                    "data_preset": data_name,
                    "model_preset": model_name,
                }
                configs.append(cfg)
    return configs


@app.route('/api/clear', methods=['POST'])
def clear_experiments():
    """Clear all experiments."""
    with experiments_lock:
        experiments.clear()
    return jsonify({"status": "cleared"})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
