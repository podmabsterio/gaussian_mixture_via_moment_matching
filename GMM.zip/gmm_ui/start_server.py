"""
GMM Experiment Dashboard — Cross-platform launcher.
Works on Windows, macOS, and Linux without bash/WSL.

Usage:
    python start_server.py

Then open http://localhost:8080 in your browser.
"""
import subprocess
import sys
import os
import time
import signal
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

def main():
    print("═" * 63)
    print("  GMM Dimension-Free — Experiment Dashboard")
    print("═" * 63)
    print()

    # Check GMM code is findable
    candidates = [
        SCRIPT_DIR.parent / "gmm_hydra" / "gmm_hydra",
        SCRIPT_DIR.parent / "gmm_hydra",
        SCRIPT_DIR / "gmm_hydra" / "gmm_hydra",
        SCRIPT_DIR / "gmm_hydra",
    ]
    found = None
    for c in candidates:
        if (c / "model_df3.py").exists():
            found = c
            break

    if found is None:
        print("  ERROR: Cannot find GMM code (model_df3.py)")
        print()
        print("  Your folder structure should look like:")
        print()
        print("    GMM_UI/                  <- your root folder")
        print("      gmm_hydra/            <- unzipped gmm_hydra.zip")
        print("        model_df3.py")
        print("        data.py")
        print("        metrics.py")
        print("        conf/")
        print("        ...")
        print("      gmm_ui/               <- this dashboard")
        print("        start_server.py     <- run THIS file")
        print("        backend/")
        print("        frontend/")
        print()
        print(f"  Searched in: {[str(c) for c in candidates]}")
        sys.exit(1)

    print(f"  ✓ Found GMM code at: {found}")
    print()

    # Install dependencies
    print("[1/3] Installing dependencies...")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-q",
         "flask", "flask-cors", "numpy", "scipy", "scikit-learn",
         "hydra-core", "omegaconf"],
        capture_output=True
    )

    print("[2/3] Starting backend (port 5000)...")
    backend_proc = subprocess.Popen(
        [sys.executable, str(SCRIPT_DIR / "backend" / "app.py")],
        cwd=str(SCRIPT_DIR / "backend"),
    )

    print("[3/3] Starting frontend (port 8080)...")
    frontend_proc = subprocess.Popen(
        [sys.executable, "-m", "http.server", "8080",
         "--directory", str(SCRIPT_DIR / "frontend")],
    )

    time.sleep(2)
    print()
    print("═" * 63)
    print("  Dashboard ready at: http://localhost:8080")
    print("  API endpoint at:    http://localhost:5000/api")
    print("═" * 63)
    print()
    print("  Press Ctrl+C to stop.")
    print()

    try:
        # Keep running until Ctrl+C
        while True:
            time.sleep(1)
            # Check if processes are still alive
            if backend_proc.poll() is not None:
                print("  Backend stopped unexpectedly!")
                break
            if frontend_proc.poll() is not None:
                print("  Frontend stopped unexpectedly!")
                break
    except KeyboardInterrupt:
        print("\n  Stopping...")
    finally:
        backend_proc.terminate()
        frontend_proc.terminate()
        try:
            backend_proc.wait(timeout=3)
            frontend_proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            backend_proc.kill()
            frontend_proc.kill()
        print("  Stopped.")


if __name__ == "__main__":
    main()
