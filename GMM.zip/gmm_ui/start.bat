@echo off
chcp 65001 >nul
echo ═══════════════════════════════════════════════════════════════
echo   GMM Dimension-Free — Experiment Dashboard
echo ═══════════════════════════════════════════════════════════════
echo.

REM Install dependencies
echo [1/3] Installing dependencies...
pip install flask flask-cors numpy scipy scikit-learn hydra-core omegaconf >nul 2>&1

REM Kill old processes on ports
echo [2/3] Cleaning up...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5000 ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8080 ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>&1
timeout /t 1 /nobreak >nul

echo [3/3] Starting services...

REM Start backend
start "GMM Backend" /B python "%~dp0backend\app.py"
echo   → Backend starting on http://localhost:5000

REM Start frontend
start "GMM Frontend" /B python -m http.server 8080 --directory "%~dp0frontend"
echo   → Frontend starting on http://localhost:8080

echo.
echo ═══════════════════════════════════════════════════════════════
echo   Dashboard ready at: http://localhost:8080
echo ═══════════════════════════════════════════════════════════════
echo.
echo Press any key to stop all services...
pause >nul

REM Cleanup
taskkill /F /FI "WINDOWTITLE eq GMM Backend" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq GMM Frontend" >nul 2>&1
echo Stopped.
