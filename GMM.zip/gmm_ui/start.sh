#!/bin/bash
# GMM Experiment Dashboard — Startup Script
# Launches Flask backend + serves frontend

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════════════════"
echo "  GMM Dimension-Free — Experiment Dashboard"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Check that GMM code is findable
GMM_FOUND=0
for candidate in \
    "$SCRIPT_DIR/../gmm_hydra/gmm_hydra/model_df3.py" \
    "$SCRIPT_DIR/../gmm_hydra/model_df3.py" \
    "$SCRIPT_DIR/gmm_hydra/gmm_hydra/model_df3.py" \
    "$SCRIPT_DIR/gmm_hydra/model_df3.py"; do
    if [ -f "$candidate" ]; then
        GMM_FOUND=1
        echo "  ✓ Found GMM code at: $(dirname "$candidate")"
        break
    fi
done

if [ "$GMM_FOUND" -eq 0 ]; then
    echo "  ✗ ERROR: Cannot find GMM code (model_df3.py)"
    echo ""
    echo "  Please arrange files like this:"
    echo ""
    echo "    some_folder/"
    echo "      ├── gmm_hydra/          ← unzip gmm_hydra.zip here"
    echo "      │     ├── model_df3.py"
    echo "      │     ├── data.py"
    echo "      │     ├── metrics.py"
    echo "      │     ├── pipeline.py"
    echo "      │     ├── conf/"
    echo "      │     └── ..."
    echo "      └── gmm_ui/             ← this folder"
    echo "            ├── start.sh"
    echo "            ├── backend/"
    echo "            └── frontend/"
    echo ""
    echo "  Then run:  cd some_folder/gmm_ui && bash start.sh"
    exit 1
fi

# Install dependencies if needed
echo ""
echo "[1/3] Checking dependencies..."
pip install flask flask-cors numpy scipy scikit-learn hydra-core omegaconf 2>&1 | grep -v "already satisfied" | head -5 || true

# Kill any existing processes on our ports
echo "[2/3] Cleaning up old processes..."
fuser -k 5000/tcp 2>/dev/null || true
fuser -k 8080/tcp 2>/dev/null || true
sleep 1

# Start backend
echo "[3/3] Starting services..."
cd "$SCRIPT_DIR/backend"
python app.py &
BACKEND_PID=$!
echo "  → Backend started (PID $BACKEND_PID) on http://localhost:5000"

# Start frontend (simple HTTP server)
cd "$SCRIPT_DIR/frontend"
python -m http.server 8080 &
FRONTEND_PID=$!
echo "  → Frontend started (PID $FRONTEND_PID) on http://localhost:8080"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Dashboard ready at: http://localhost:8080"
echo "  API endpoint at:    http://localhost:5000/api"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "Press Ctrl+C to stop all services."

# Wait and cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Stopped.'" EXIT
wait
